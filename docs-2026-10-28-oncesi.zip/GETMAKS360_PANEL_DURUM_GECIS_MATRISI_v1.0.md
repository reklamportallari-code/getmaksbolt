# GETMAKS360 — Panel Durum ve Geçiş Matrisi v1.0

Bu matris, `GETMAKS360_ROL_PANEL_EKRAN_ISLEM_KURGUSU_v1.1.md` belgesinin kısa karar özetidir.

| Olay | Standart Üye | Danışman | Ofis | Stratejik İş Ortağı | Bağlayıcı sonuç |
|---|---|---|---|---|---|
| İlk üyelik | Açık | Kapalı | Kapalı | Kapalı | Standart müşteri alanı ve dört ana müşteri ihtiyacı açılır. |
| Profesyonel başvurusu beklemede | Açık | Kapalı | Kapalı | Kendi bağımsız ilişkisine göre | Başvuru ekranı görülür; başvuru panel yetkisi değildir. |
| Danışmanlık onaylandı/aktive edildi | Açık | Açık | Kapalı | Kendi bağımsız ilişkisine göre | Standart Üye + Danışman panelleri birlikte kalır. |
| Sıradan danışman OfficeMembership ile ofise katıldı | Açık | Açık | Kapalı | Kendi bağımsız ilişkisine göre | Ofis üyeliği Broker yönetim yetkisi değildir. |
| MAXIMUM franchise Broker'ı aktif | Açık | Açık | İlgili MAXIMUM ofisi için açık | Kendi bağımsız ilişkisine göre | Franchise sahibi Broker ile atanmış Broker ayrı tutulur. |
| GETMAKS tarafından ALFA şubesine Broker atandı | Açık | Açık | Yalnız atandığı ALFA ofisi için açık | Kendi bağımsız ilişkisine göre | Franchise sahipliği verilmez; erişim atama kapsamına sınırlıdır. |
| Broker ofis görevinden alındı/atama sona erdi | Açık | Profesyonellik aktifse açık | Eski ofis için kapalı | Kendi bağımsız ilişkisine göre | Ofis verisi silinmez; yeni sorumluya devir ayrı yürütülür. |
| Profesyonel statü iptal edildi | Açık | Kapalı | Profesyonelliğe bağlı Broker/Ofis operasyonu kapalı | Kendi bağımsız ilişkisine göre | Standart Üye Paneli kalıcıdır; geçmiş müşteri dosyaları silinmez. |
| Stratejik ortaklık sona erdi | Açık | Yalnız bağımsız aktif danışmanlık varsa açık | Yalnız bağımsız aktif Broker ilişkisi varsa açık | Kapalı | Ortak görev erişimi kapanır; kişisel müşteri alanı kalır. |
| Kurumsal temsil yetkisi sona erdi | Açık | Diğer ilişkilerine göre | Diğer ilişkilerine göre | Diğer ilişkilerine göre | Yalnız ilgili kurumsal bağlam kapanır, kişisel hesap kalır. |
| Müşteri şirket adına işlem yapıyor | Açık | Diğer ilişkilerine göre | Diğer ilişkilerine göre | Diğer ilişkilerine göre | Kurumsal taraf ile gerçek kişi temsilci ayrı tutulur; şirket dosyası sadece yetkililere açık. |

## Değişmezler

1. Standart Üye Paneli her kullanıcıda kalır.
2. Aktif danışmanlık, Standart Üye Paneline Danışman Panelini ekler; onu değiştirmez.
3. Broker paneli, Standart Üye + Danışman + belirli ofisin Ofis Panelinden oluşur.
4. Franchise Broker ve atanmış Broker birbirine dönüştürülemez.
5. Ofis görevi kalkınca yalnız o ofisin panel ve operasyon yetkisi kapanır; profesyonellik sürüyorsa Standart Üye + Danışman kalır.
6. Profesyonellik iptalinde Standart Üye kalır; Danışman ve ona bağlı Broker/Ofis operasyonu kapanır.
7. Stratejik ortaklık, danışmanlık veya Broker statüsünün yerine geçmez; her bağımsız ilişki kendi durumuna göre panel ekler/kaldırır.
8. Bireysel ve kurumsal müşteri aynı dosya tarafı türü değildir. Kurumsal taraf, yetkili gerçek kişi temsilcisi üzerinden çalışır.
9. Menüde görünürlük tek başına güvenlik değildir; route/action ve kayıt kapsamı da aynı duruma uyar.

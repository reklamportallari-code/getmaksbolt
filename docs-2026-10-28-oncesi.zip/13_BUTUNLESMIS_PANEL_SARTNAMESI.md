# GETMAKS360 — Bütünleşmiş Panel Tasarım ve Uygulama Şartnamesi

**Durum:** Proje içi eşleme ve uygulama sınırı. Bu belge tek başına rota, migration, erişim veya finansal işlem uygulamaz.

**Ana kaynak ve öncelik:** Kullanıcının sağladığı `GETMAKS360_ANA_TASARIM_VE_UYGULAMA_SARTNAMESI.md` ve `GETMAKS360_CODEX_TEK_ANA_TALIMAT.txt` ana ürün şartnamesidir. Bu dosya, o şartnamenin mevcut Laravel uygulamasındaki veri sahipliği, C1–C4 koruma sınırları, açık kararları ve uygulanabilir iş sırasıyla eşlemesidir. Çelişkide ana kaynak önceliklidir; burada yeni ürün kuralı türetilmez.

**Amaç:** Üye/Müşteri, Broker, Danışman, Marka ve gelecekteki Yatırımcı çalışma alanlarını aynı veri sahipliği, yetkilendirme ve yaşam döngüsü kuralları üzerinde birleştirmek. C1–C4'teki uygulamalar korunacak, yeniden yazılmayacak; sonraki paketler ana şartnameyi bu belge ve güncel kodla karşılaştırarak uygulanacaktır.

## 1. Değişmez ilkeler

1. Her insan önce `User` / temel üyedir. Broker veya danışmanlık, temel üyeliği silmeyen scoped profesyonel bağlamdır.
2. `ProfessionalApplication` adaylık ve inceleme kaynağıdır. Başvuru onayı yalnız onboarding'e geçiştir; `Professional`, `OfficeMembership`, `BrokerEngagement`, sözleşme veya operasyon izni doğurmaz.
3. Ofis, broker ilişki, danışman üyeliği, sözleşme, ticari koşul ve panel erişimi ayrı kayıtlardır. Bir ekrandaki durum etiketi diğerini varsaymaz.
4. Broker, danışmanın sahibi değildir. Organizasyon `Brand → Office → {Broker yöneticisi, Consultant üyeleri}` şeklindedir; danışman ofise `OfficeMembership` ile bağlıdır.
5. Satıcı, alıcı, mülk sahibi, kiracı, kiraya veren, devreden ve devralan kişi hesabı rolleri değildir. Bunlar `FileParty` ve ilerideki işlem tarafı kayıtlarında dosya kapsamındadır.
6. Menü, çalışma alanı seçici ve gizlenmiş buton güvenlik kaynağı değildir. Her GET ve mutasyon; aktif kullanıcı, permission, kaynak kapsamı ve durum geçişini sunucuda kontrol eder.
7. Data Havuzu ile Kazanç Havuzu ayrı alanlardır. Tahakkuk, fatura, tahsilat ve ödeme birbirinin yerine geçmez.
8. C1 başvuru belge sürümleri ofis belgelerinden ayrıdır: `ProfessionalApplicationDocumentRequirementSet → ProfessionalApplicationDocument`; ofis tarafı `OfficeDocumentRequirementSet → OfficeDocument` olarak kalır.
9. C2 eksik bilgi talebi ve yeniden gönderim, C3 outbox/bildirim kaydı, C4 broker ilişki geçmişi ve audit kayıtları korunur. Gerçek teslim kanalı bulunmuyorsa bildirim teslim edildi gösterilmez.
10. G01–G14, D01–D05 ve açık finans kararları, ana yaşam döngüsü şartnamesindeki anlamlarıyla geçerlidir. Bu belge belirsiz finans, imza, temsil, tahakkuk veya yatırım kuralı üretmez.

## 2. Veri sahipliği ve ilişki haritası

```mermaid
flowchart TD
    U[User / temel üye] --> P[Professional: BROKER veya CONSULTANT]
    U --> PA[ProfessionalApplication]
    PA -->|onay sonrası yalnız onboarding| OB[Onboarding bağlamı]
    B[Brand] --> O[Office]
    P --> BM[BrandMembership]
    P --> OM[OfficeMembership]
    P --> BE[BrokerEngagement]
    O --> OM
    B --> BE
    O --> BE
    O --> C[Customer]
    C --> RF[RequestFile]
    RF --> SO[ServiceOffer]
    SO --> SF[ServiceFile]
    RF --> FP[FileParty]
    SF --> FP
    SF --> PR[Property → Portfolio → Listing]
```

| Kavram | Kaynak kayıt | Sahibi | Bu kayıt **değildir** |
|---|---|---|---|
| Temel giriş | `User` | kişi | profesyonel veya işlem tarafı yetkisi |
| Aday başvuru | `ProfessionalApplication` | başvuran ve inceleyici | aktif broker/danışman yetkisi |
| Profesyonel kimlik | `Professional` | kişi | ofis ataması |
| Marka kapsamı | `BrandMembership` | marka–profesyonel ilişkisi | ofis operasyon izni |
| Ofis kapsamı | `OfficeMembership` | ofis–profesyonel ilişkisi | broker ticari/ilişki durumu |
| Broker ilişkisi | `BrokerEngagement` | marka–ofis–broker bağlamı | danışman üyeliği veya global hesap kilidi |
| Ticari koşul | `CommercialAgreement`, plan/policy kayıtları | ilgili taraflar | imza, ödeme ya da operasyon hakkı |
| Başvuru belgesi | C1 belge seti ve sürümleri | aday başvuru | ofis belgesi |
| Müşteri işlem rolü | `FileParty` | Request/Service dosyası | `User.role` |

### MAXIMUM ve ALFA için geçiş kararı

Güncel ürün kararı MAXIMUM ve ALFA'yı **ofis türü** olarak ele alır. Mevcut kod ve ADR-003/037 bunları `ProfessionalWorkModel` içindeki danışman çalışma modeli olarak kullanır. Bu iki anlam aynı alanda tutulamaz.

`Office.office_type` yalnız `MAXIMUM | ALFA` ofis türünü taşır. Nullable, ekleyici migration 2026-10-24 tarihinde uygulanmıştır: yeni ofis başvurusu/kuruluşu ve düzenlemesinde seçim sunucu tarafında zorunludur; eski NULL kayıtlar topluca dönüştürülmez. Mevcut `ProfessionalWorkModel.MAXIMUM | ALFA` satırları danışmanın çalışma/capability geçmişi olarak kalır; otomatik dönüştürülmez ve ofis türü çıkarımı için kullanılmaz. Eski veri eşlemesi veya Data/Kazanç Havuzu yetki değişimi, örnek kayıtlar ve `WorkModelPolicy` bağımlılıklarıyla ayrı karar/taşıma paketi ister.

## 3. Ortak ekran sözleşmesi

Her panel aşağıdaki davranışları ortak kullanır:

- Üst alan: geçerli çalışma alanı, sadece gerçekten erişilebilir alanlara geçiş, bildirim merkezi ve profil/çıkış.
- Liste: arama, durum/marka/ofis/tarih filtresi, sayfalama, boş durumdaki izinli sonraki adım, kaynak kayda güvenli bağlantı.
- Detay: özet, durum zaman çizelgesi, ilgili belge/sözleşme/üyelik sekmeleri, audit geçmişi; kullanıcıya yetkisiz alanlar hiç gönderilmez.
- Aksiyon: görünürlük, permission, ön koşul ve sunucu doğrulaması ayrı tanımlanır. Başarı kalıcı kayda yönlendirir; alan hatası, 403/404, durum çakışması, tekrar istek ve dış kanal hatası anlaşılır biçimde gösterilir.
- Denetim: kritik aksiyon actor, zaman, önceki/yeni durum, gerekçe ve kaynak kimliğiyle kaydedilir. Düzeltme eski kaydı silmez.
- Dosya: özel depolama, kaynak sahipliği ve sunucu indirme kontrolü zorunludur. URL tahmini veya e-posta benzerliği erişim sağlamaz.

## 4. Rol ve yetki matrisi

| Alan / işlem | Üye/Müşteri | Broker | Danışman | Marka yöneticisi | Yatırımcı |
|---|---|---|---|---|---|
| Kendi profil/mesaj/belge görünümü | kendi kaydı | kendi kaydı | kendi kaydı | kendi kaydı | kendi kaydı | 
| Profesyonel başvuru | oluşturur ve kendi durumunu görür | kendi adaylık geçmişi | kendi adaylık geçmişi | inceler | yok |
| Broker ilişki | kendi yetkili özetini görür | yalnız kendi ilişki/izinli ofis kapsamı | yok | oluşturur, inceler, C4 geçişi yapar | yok |
| Ofis yönetimi | yok | yalnız yetkili ofis | yok | marka kapsamındaki ofisler | yalnız yatırım anlaşması kapsamındaki salt-okunur özet (gelecek) |
| Danışman yönetimi | yok | yetkili ofiste | kendi profili | marka kapsamı | yok |
| Müşteri/dosya | doğrulanmış kendi dosyaları | ofis kapsamı | atandığı/izinli dosyalar | marka kapsamı | anlaşma kapsamı henüz tanımlı değil |
| Ticari koşul/sözleşme | yalnız kendi hizmet belgesi | kendi ilişki kapsamındaki görünüm | kendi anlaşması | yönetir/doğrular | anlaşma yoksa yok |
| Finans/ödeme | kendi fatura/tahsilat yükümlülüğü gelecekte | yalnız gerçek yetkili özet | kendi hak görünümü gelecekte | marka kapsamı | yalnız gerçek yatırım anlaşması kapsamı | 
| Audit | kendi eylemi için sınırlandırılmış görünüm | kapsamlı kendi eylemi | kapsamlı kendi eylemi | yetkili denetim | kapsam tanımlanınca |

Yatırımcı sütunu hedef tasarımdır; mevcut yatırım anlaşması, kapsam filtresi ve finans modeli kanıtlanmadan route, veri veya çalışır finans ekranı üretilmez.

## 5. Panel şartnameleri

### 5.1 Üye ve müşteri paneli

**Menü:** Genel Bakış, Taleplerim, Mülklerim, Randevularım, Mesajlarım, Belgelerim; ikincil alan olarak Profesyonel Başvuru.

| Ekran | Liste/alanlar | Buton ve ön koşul | Kalıcı sonuç / hata |
|---|---|---|---|
| Genel Bakış | yalnız doğrulanmış bağlı dosyaların durum özeti, bekleyen belge ve görev | dosyayı aç | `CustomerAccountLink` veya `FileParty` olmadan görünmez; iç not/finans sızmaz |
| Talep oluştur | işlem niyeti, taraf rolü, arama/mülk bilgisi, iletişim | Mülkümü sat, kiraya ver, satın al, kiralık ara; taslak/gönder | `RequestFile` veya mevcut hizmet başlangıç bağlamı; taraf rolü User rolü olmaz |
| Dosyalarım / belgelerim | müşteriye yayımlanmış durum, kendisinden istenen belge | belge gönder, yanıtla | kaynak dosya ve istek sahipliği sunucuda doğrulanır |
| Profesyonel başvuru | başvuru durumu, C1 belge tamamlanması, C2 bilgi talebi | başvuru oluştur/güncelle, belge sürümü yükle, bilgi talebini yanıtla | C1/C2 kayıtları; başvuru onayı panel hakkı vermez |

Randevu ve mesaj ekranları hedef yüzeydir. Mevcut kalıcı model/route kanıtlanmadan tıklanabilir tamamlanmış işlev olarak sunulmaz.

### 5.2 Broker paneli

**Ofissiz broker:** Genel Bakış, Marka İlişkim, Onboarding, Ofis Oluştur, Sözleşme ve Belgeler.

**Yetkili ofisi bulunan broker:** buna ek olarak Ofislerim, Danışman Ekibim, Ofis İşlemleri, Ofis Talepleri, Performans, Ofis Ayarları.

| Ekran | Görünen veri | Buton/koşul | Sunucu etkisi |
|---|---|---|---|
| Genel Bakış | geçerli ilişki, üyelik ve yetkili ofis özeti | ofis seç, ilişki detayını aç | çalışma alanı yeni yetki vermez; kapsam kullanıcı/Professional/membership/engagement ile çözülür |
| Marka İlişkim | `BrokerEngagement` durum/geçmiş, marka/ofis, denetim kaydı | salt-okunur ilişki detayı; yetkili marka tarafından yönetilen değişiklikler görünür | C4 audit korunur; sözleşme mevcut değilse varmış gösterilmez |
| Onboarding | profesyonel/başvuru ilerlemesi ve eksikler | eksik bilgiyi/belgeyi tamamla | C1/C2 akışı; bu ekran operasyon izni sağlamaz |
| Ofis Oluştur | gerçek mevcut kuruluş akışının gerekli alanları | taslak oluştur/gönder | `Office` ve onay/readiness akışı; kaynak ve marka yetkisi sunucuda atanır |
| Sözleşme ve Belgeler | yalnız mevcut ilişki/ofis kapsamındaki kayıtlar | görüntüle, yetkisi varsa kanıt sun | belge/sözleşme/ilişki durumları ayrı gösterilir |
| Ofislerim | yetkili ofisler, durum, aktif broker, danışman sayısı | ofisi aç | geçerli ofis üyeliği ve ilişki kapsamı yoksa erişim yok |
| Danışman Ekibim | yalnız seçili yetkili ofisin consultant üyeleri | ekle, düzenle, askıya al, sonlandır | broker–consultant sahipliği kurulmaz; `OfficeMembership` ve mevcut authority kontrol edilir |
| Ofis Talepleri/İşlemleri | ofis kapsamındaki müşteri/talep/hizmet kayıtları | ata, havuza bırak, dosyayı aç | `OperationalAssignment` ve kaynak görünürlük servisleri ile GET/POST kapsamı kontrol edilir |
| Performans/Ayarlar | mevcut gerçek metrikler ve izinli ofis ayarları | filtrele / izinli değişiklik | finans veya yeni ayar varsayımı oluşturulmaz |

Broker ilişkisi askıya alındığında veya sonlandığında, ilgili ofis/marka kapsamındaki operasyonel veri ve aksiyonlar merkezi erişim katmanında reddedilmelidir; başka geçerli ilişki, temel üye alanı ve onboarding genel hesap kilidine dönüşmez. Bu C5 uygulama paketi bu şartname tamamlanana kadar beklemededir.

### 5.3 Danışman paneli

**Menü:** Genel Bakış, İşlerim, Müşterilerim, Portföylerim, Taleplerim, Randevularım, Görevlerim, İşlem Takibi, Belgelerim; ayrıca Profilim/Onboarding ve kendi ticari görünümü.

| Ekran | Kaynak | Aksiyon ve sınır |
|---|---|---|
| İşlerim / görevler | atanmış `RequestFile`, `ServiceFile`, görev kayıtları | yalnız aktif/izinli ofis kapsamındaki kaydı açar; atanmamış dosya URL'si reddedilir |
| Müşterilerim | `Customer` + dosya görünürlüğü | müşteri oluştur/ara/aktivite ekle; CRM bağı e-posta eşleşmesiyle açılmaz |
| Taleplerim / hizmetlerim | Request → ServiceOffer → ServiceFile zinciri | durum geçişi mevcut action ve permission ile; çift istek çift dosya oluşturmaz |
| Portföy/ilan | Property → Portfolio → Listing | yalnız kaynak ServiceFile koşulları sağlanınca oluşturur; yayın/işlem kapanışı kanıt yoksa hedef durumdur |
| Belgelerim | kendi onboarding ve dosya belgesi | yalnız talep edilen ve sahip olduğu belgeyi yükler |
| Profil/Onboarding | `Professional`, üyelik ve checklist | eksikleri tamamlar; aktiflik koşullarını kendiliğinden geçmez |

Danışmanın ofis değişimi tarihçeli üyelik ve mevcut transfer akışıyla yapılır. Eski ofis müşterileri ve dosyaları yeni ofise otomatik açılmaz.

### 5.4 Marka merkezi yönetim paneli

**Menü:** Marka Özeti, Broker Başvuruları, Brokerlar ve İlişkileri, Ofisler, Profesyoneller, Belge Gereklilikleri, Ticari Koşullar ve Sözleşmeler, Yetkiler, Denetim Geçmişi.

| Ekran | Zorunlu görünüm | Yetkili aksiyon | Kayıt/etki |
|---|---|---|---|
| Marka özeti | güvenilir kaynaklardan sayı/kuyruk/uyarı; gecikmiş projeksiyon zaman damgası | filtrele, kaynak listeye git | sahte finans/toplam yok |
| Broker başvuruları | tür, aday, durum, C1 belge durumu, C2 bekleyen yanıt | incele, eksik bilgi iste, onay/ret; provisioning yalnız mevcut akışla | başvuru/audit/outbox; aktif broker oluşturma ayrı |
| Brokerlar ve ilişkileri | profesyonel, marka/ofis, membership, engagement, sözleşme/belge durumu ayrı sütun/sekme | ilişki oluştur, C4 askıya al/yeniden etkinleştir/sonlandır | gerekçeli audit; engagement üyelik veya User durumunu değiştirmez |
| Ofisler | ofis türü (uygulandığında), kuruluş kaynağı, lifecycle, broker, readiness | oluştur, incele, atama/değişim, readiness/activation | `Office` operasyon kaynağı; başvuru geçmişi ayrı |
| Profesyoneller | broker/consultant, onboarding, marka/ofis üyelikleri | oluştur/davet/transfer/askı/sonlandırma | type, membership ve onboarding birbirine yazılmaz |
| Belge gereklilikleri | başvuru gereklilik seti ve ofis seti ayrı ekranlar | sürümlü set hazırla/aktifleştir | aktif set yokluğu eksik koşul olarak açık gösterilir |
| Ticari koşullar/sözleşmeler | taraf, sürüm, geçerlilik, imza kanıtı, anlaşma durumu | mevcut izinli teklif/inceleme aksiyonları | ticari kabul, imza ve yürürlük ayrı durumlar |
| Yetkiler | role-permission registry, kullanıcının etkin kapsamı | role düzeyindeki mevcut izin yönetimi | kullanıcı seçimi yeni yetki sağlamaz |
| Denetim geçmişi | actor, kaynak, tarih, önce/sonra, gerekçe | filtrele, kaynak kaydı aç | belge gövdesi ve gizli değerler audit'e kopyalanmaz |

### 5.5 Yatırımcı paneli (gelecek sınır)

**Hedef menü:** Yatırımlarım, Anlaşmalarım, Anlaşmaya Dahil Ofisler, İlerleme ve Raporlar, Belgeler, Hareket Geçmişi.

Bu panel ancak yatırım anlaşması, anlaşma–ofis kapsamı, veri alanı ve finansal görünürlük kararları mevcut olduğunda açılır. Her sorgu gerçek anlaşma kapsamından türemeli; yatırımcı, markanın veya ofisin tamamını varsayılan olarak görmemelidir. Şu an “çalışır finans” veya yatırım getirisi vaadi olarak gösterilemez.

## 6. Ortak durum ve aksiyon sözleşmesi

| Kaynak | Ayrı durumlar | Yasak kısa yol |
|---|---|---|
| Başvuru | taslak/gönderildi/incelendi/eksik bilgi/yeniden gönderildi/onboarding/ret/geri çekme | onaydan direkt operasyon hakkı |
| Başvuru belgesi | gereklilik seti, yüklenmiş sürüm, inceleme kararı | eski sürüm onayını yeni sürüme taşıma |
| Broker | `Professional`, marka üyeliği, ofis üyeliği, `BrokerEngagement` | yalnız role etiketiyle kapsam açma |
| Ofis | kuruluş kaynağı, lifecycle, readiness, sözleşme/plan | SETUP veya onayı doğrudan ACTIVE sayma |
| Danışman | profesyonel, ofis üyeliği, work model, onboarding, plan | brokerın alt kullanıcısı gibi kaydetme |
| Müşteri/dosya | müşteri, taraf rolü, talep/hizmet/işlem dosyası | User.role'a taraf rolü yazma |
| Finans | beklenen/tahakkuk/fatura/tahsilat/ödeme | süreç durumunu ödeme sayma |

Her değişiklikte: input doğrulama → permission ve kaynak scope → durum ön koşulu → transaction içinde kalıcı kayıt/audit → güvenilir outbox/yan etki → güncel kayda yönlendirme sırası uygulanır. Aynı idempotency anahtarı veya aynı geçiş tekrarında ikinci kayıt/yan etki oluşturulmaz.

## 7. Mevcut uygulama ile eşleme

| Alan | Mevcut kanıt | Tasarımın sonraki işi | Durum |
|---|---|---|---|
| Temel üye ve scoped profesyonel | `User`, `Professional`, ADR-059, member route'ları | üye panel menülerini gerçek müşteri yüzeyine genişletmek | Kısmi |
| Başvuru, belge, eksik bilgi, outbox | C1–C3 modelleri/controllers/tests | birleşik başvuru UX'i ve onboarding completion bridge | Kısmi |
| Broker ilişki geçmişi | `BrokerEngagement`, C4 action/audit | C5 merkezi operasyon kapsamı | Kısmi; C5 beklemede |
| Broker/ofis/danışman organizasyonu | `OfficeMembership`, ADR-051, `/admin`, `/broker` | broker menülerini ofissiz/ofisli duruma göre bölmek | Kısmi |
| Operasyon scope | `OperationalAssignment`, görünürlük servisleri, `/operations` | C5 ile engagement kapsamını bağlamak ve GET/POST regresyonu | Kısmi |
| Customer/dosya taraflığı | `CustomerAccountLink`, `FileParty`, Request/Service zinciri | üye ekranlarına güvenli sunum ve randevu/mesaj tasarımı | Kısmi |
| Portföy/ilan | Property/Portfolio/Listing mevcut | yayın, lead, işlem kapanış lifecycle'ı | Kısmi |
| Ticari/finans | agreement/plan/policy/charge hazırlığı | imza, fatura, tahsilat, hakediş ve yatırımcı kapsam kararları | Karar/uygulama bekliyor |
| Ofis türü | `Office.office_type` MAXIMUM/ALFA; eski `ProfessionalWorkModel` kullanımı korunur | eski NULL kayıtlar için kanıta dayalı sınıflandırma ve capability etkisi | Yeni ofisler uygulandı; veri eşlemesi bekliyor |

## 8. Uygulama sırası ve teslim kapıları

1. **Eski kayıt eşleme kararını kayda bağla.** MAXIMUM/ALFA ofis türü ile eski work-model kullanımı ayrı alanlarda tutulur. Migration uygulandı; mevcut NULL ofis türlerini kanıtsız doldurma.
2. **Çalışma alanı ve broker erişimi.** C5'i merkezi `OperationalAssignment`/middleware kapsamı üzerinden uygula; ofissiz broker onboarding ekranlarını koru, ilişki askısında yalnız ilgili operasyonu kapat.
3. **Üye/müşteri yüzeyi.** Mevcut doğrulanmış dosya bağlarını listele, talep girişlerini üye ekranında tamamla; randevu/mesaj için veri kaynağı yoksa yalnız tasarım/karar kaydı bırak.
4. **Broker/ofisli çalışma alanı.** Gerçek yetkili ofis varsa ekip, talep, operasyon ve performans menülerini aç; menü + route + veri scope'u birlikte test et.
5. **Danışman çalışma alanı.** Ofis üyeliği, atama ve dosya görünürlüğünü yeni ekranlarla eşleştir; transfer ve askı regresyonlarını koru.
6. **Marka merkezi.** Mevcut C1–C4, ofis, ticari ve audit ekranlarını tek merkezî menüde gerçek route'larla birleştir; placeholder üretme.
7. **Finans/yatırımcı.** D01–D05 ile yatırım anlaşması kararları tamamlanmadan hesaplama, ödeme ya da yatırımcı paneli uygulama.

Her paketin teslimi; gerçek URL/menü, rol bazlı GET ve POST testi, yetkisiz doğrudan URL testi, durum/audit kanıtı, boş/hata davranışı, Pint ve Blade cache sonucunu içerir. Feature/HTTP testi tarayıcı kabulü olarak sunulmaz.

## 9. Açık kararlar

| Karar | Neden gerekli | Bu karar gelmeden engellenen iş |
|---|---|---|
| Eski NULL ofis türü kayıtlarının kanıta dayalı eşlemesi | geçmiş veriyi yanlış anlamlandırmamak | eski kayıtların sınıflandırılması ve capability değişimi |
| Broker ilişkisinde sözleşme/temsil kanıtı minimumu | ACTIVE ilişkiyi varsayımla genişletmemek | yeni aktivasyon ön koşulu |
| Tarihsel broker ilişkisi olan kaydın salt-okunur erişimi | C5 için ayrı izin politikası gerekir | eski ofis/dosya ekranı görünümü |
| Randevu ve mesaj veri sahibi/retention kuralı | UI için kalıcı kaynak yok | üye/danışman randevu-mesaj modülü |
| İşlem kapanışı, hakediş, fatura/tahsilat/ödeme tetikleyicileri | finans durumlarını karıştırmamak | finans ve yatırımcı görünümü |
| Yatırım anlaşması ve ofis kapsamı | yatırımcıya fazla veri açmamak | yatırımcı paneli |

## 10. Kabul ölçütü

Bir panel satırı ancak şu zincir tamamsa “uygulandı” sayılır: **menü/route → sunucu yetkisi ve scope → doğrulanmış input → kalıcı kaynak kayıt → durum/audit → ilgili role doğru görünüm → hata/tekrar davranışı → test kanıtı.**

Bu belgedeki hedef ekranlar, mevcut route veya veri modeli yoksa “tasarım hedefi”dir; çalışıyor iddiası değildir.

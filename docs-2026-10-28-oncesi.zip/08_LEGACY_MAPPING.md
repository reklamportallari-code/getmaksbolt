# Legacy Eşleme Kaydı

Legacy GETMAKS360 projesinden hiçbir dosya otomatik taşınmamıştır. Her yeniden kullanım kararı bu dosyada ayrıca kayıt altına alınacaktır.

## Kayıt şablonu

```text
Legacy Source:
...

New Target:
...

Decision:
REUSED / REWRITTEN / REJECTED

Reason:
...
```

## Kayıtlar

Henüz yeniden kullanım kararı yoktur.

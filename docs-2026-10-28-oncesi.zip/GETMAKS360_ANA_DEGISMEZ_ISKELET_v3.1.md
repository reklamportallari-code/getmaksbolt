# GETMAKS360 — Ana Değişmez Sistem İskeleti v3.1

## 1. Yönetim kararı

GETMAKS360, birbirinden kopuk paneller toplamı değildir. Bütün ekranlar aynı kaynak kayıtları, aynı durum geçişlerini ve aynı yetki kurallarını kullanır. Paneller, kullanıcının gerçek ilişkilerine göre aynı operasyonun farklı görünümleridir.

**Sabit iş omurgası:**

**Kimlik kuralı:** Her hesap Standart Üye olarak başlar ve GETMAKS açısından potansiyel müşteri havuzunun parçasıdır. Gayrimenkul profesyoneli mesleki sürece kabul edildiğinde Gayrimenkul Danışmanı unvanıyla başlar; MAXIMUM franchise/ofis kuruluşu veya GETMAKS tarafından açık Broker/şube yöneticisi ataması ve gerekli aktivasyon koşullarıyla Broker unvanına geçer. Bu geçişler kullanıcı hesabı, işlem içi müşteri rolü ve ofis erişimiyle karıştırılmaz.

**GETMAKS Markası → Ofis → Broker ilişkisi/yönetimi → Ofis üyeliğiyle Danışman → Nihai müşteri tarafı → Talep Dosyası / Hizmet Dosyası → Portföy ve İlan → Eşleşme ve Gösterim → İşlem Dosyası → Finans**

Bu omurga değişmez. Ekranlar, menüler, bildirimler, görevler ve pazar yeri zamanla geliştirilebilir; fakat kaynak kayıt sahipliği ve işlem yaşam döngüsü birbirinden koparılamaz.

## 2. Panel sayısı: 5 operasyonel çalışma alanı + daha sonra 1 pazar yeri vitrini

“Panel” ile kullanıcı türünü birbirine karıştırmayın. Kullanıcı/profil türleri ile o profilin erişebildiği çalışma alanları farklıdır.

### 2.1 Marka yönetim paneli — GETMAKS

**Kim kullanır:** Yetkili ana sistem/marka yöneticileri.

**Sorumluluklar:**
- Ofis kayıtları, ofis türü ve ofis açılış/atanma süreçleri.
- Broker başvurusu, davet, onboarding ve marka-broker ilişkisi.
- Ofislerin yetkili yöneticileri ve ofis üyelikleri üzerinde yetkili yönetim.
- Marka tarafından yapılandırılan hizmet kapsamı ve belge/sözleşme gereklilikleri.
- Denetim geçmişi, operasyon görünürlüğü ve sistem ayarları.
- Marka tarafından tahsis edilen ofislerde brokerın çalışma/ücret ilişkisinin yönetimi.

**Yapmamalı:** Müşteri rolünü global kullanıcı rolüne çevirmek, ofis ve danışman kayıtlarını kopyalamak, doğrulanmamış finansal sonuç üretmek.

### 2.2 Broker çalışma alanı

Gayrimenkul profesyonelinin başlangıç unvanı Gayrimenkul Danışmanıdır. Broker unvanı, onaylı MAXIMUM franchise/ofis kuruluşu veya GETMAKS tarafından açık Broker/ALFA şube yöneticisi ataması ve ilgili aktivasyon koşullarıyla kazanılır. Broker profesyonel profilidir; tek başına ofis sahipliği veya danışman yönetim yetkisi anlamına gelmez.

Normal bir ofise danışman olarak bağlanmak, `OfficeMembership` kazanmak veya e-posta/e-Devlet doğrulaması Broker unvanı üretmez. Broker unvanı ile belirli bir ofise erişim hakkı da ayrı değerlendirilir; ofis işlemleri için aktif ilişki ve sunucu tarafı yetki kontrolü gerekir.

**Görünür işlevler:**
- Broker profili ve marka ile ilişkisi.
- Başvuru/onboarding, davetler, kendi sözleşme ve yükümlülüklerinin durumu.
- Franchise/ofis açılış süreci veya marka tarafından ofise atanma durumu.
- Varsa erişebildiği ofis çalışma alanına geçiş.

**Ofissiz broker:** Ofis oluşturma/kurulum veya atanma sürecini görebilir. Danışman listesi, danışman ekleme ve ofis operasyonlarına erişemez.

### 2.3 Ofis çalışma alanı

**Ofis bir kullanıcı tipi değildir.** Ofis çalışma alanı, gerçek ve aktif ofis ilişkisiyle profile eklenen bir yetki alanıdır.

Erişim koşulları:
- Franchise/ofis sahibi veya marka tarafından yetkili atanmış broker için ilgili ofis ilişkisi ve yetkiler doğrulanır.
- Danışman için geçerli `OfficeMembership` ve bu üyeliğin kapsadığı izinler doğrulanır.
- Menü seçimi, URL parametresi veya istemciden gönderilen ofis kimliği tek başına yetki vermez.

**Ofis işlevleri:**
- Ofis genel bakış ve iş kuyruğu.
- Ofise bağlı Talep Dosyaları ve Hizmet Dosyaları.
- Danışman üyelikleri, atamalar ve görevler.
- Mülk/portföy/ilan yönetimi.
- Eşleşmeler, gösterimler, teklifler ve İşlem Dosyaları.
- Ofis kapsamındaki belgeler, zaman çizelgeleri ve performans.

Broker ve danışman aynı ofis kayıtlarını farklı izinlerle görür; biri diğerinin yerine geçen bir rol değildir.

### 2.4 Danışman çalışma alanı

Gayrimenkul profesyoneli yaşam döngüsündeki başlangıç mesleki unvanı Gayrimenkul Danışmanıdır. Danışman, profesyonel kabul/aktivasyon koşullarını karşılamadan sırf standart üye olduğu için profesyonel sayılmaz. Unvanı Broker olarak değişen kişinin geçmiş danışmanlık ve ofis ilişkileri denetim izinde korunur; unvan, ofis türü ve erişim yetkileri tek bir alan olarak birleştirilmez.

**Sorumluluklar:**
- Kendisine atanmış ofis(ler) ve yetkili operasyon kapsamı.
- Kendisine atanmış müşteri, Talep Dosyası, Hizmet Dosyası ve görevler.
- Portföy, ilan, eşleşme, gösterim ve işlem dosyası adımları.
- Kendi iş kuyruğu, randevular, belgeler ve iletişim.

Danışman, brokerın alt kullanıcısı değildir. Ofisin profesyonel üyesidir. Bir ofis üyeliği veya ilişki kapandığında geçmiş kayıtlar korunur; başka geçerli ilişkiler varsayımla kapatılmaz.

### 2.5 Üye / Nihai müşteri çalışma alanı

Bütün standart üyeler bu alanı kullanır. Standart üyeliğin iş modeli karşılığı, GETMAKS’ın hizmet ve aracılık hizmeti sunabileceği **potansiyel müşteri** havuzudur. Bu ilişki müşteri kazanımı için başlangıç noktasıdır; tek başına aktif talep, işlem taraf rolü veya kazanılmış hizmet bedeli anlamına gelmez. E-posta veya kimlik doğrulaması profesyonellik yetkisi oluşturmaz.

**Ana başlangıçları:**
- Mülkümü satmak istiyorum → Hizmet Dosyası.
- Mülkümü kiraya vermek istiyorum → Hizmet Dosyası.
- Gayrimenkul satın almak istiyorum → Talep Dosyası.
- Kiralık gayrimenkul arıyorum → Talep Dosyası.

**Müşteri ekranları:** Genel Bakış, Talep Dosyalarım, Hizmet Dosyalarım, Mülk/ilan ilgilerim, Randevu ve gösterimlerim, Belgelerim, Mesajlarım, İşlem durumlarım.

Satıcı, alıcı, mülk sahibi ve kiracı kalıcı panel/profil türleri değildir. Bunlar ilgili Talep, Hizmet, Gösterim veya İşlem Dosyasındaki taraf rolleridir. Aynı kişi birden fazla dosyada farklı taraf rolüne sahip olabilir; paneli değişmez.

### 2.6 Üyelik, müşteri ilişkisi, profesyonel unvan ve işlem rolü ayrımı

Bu kavramlar aynı `User.role` alanına sıkıştırılmaz:

| Kavram | Kanonik anlam | Doğurmadığı sonuç |
|---|---|---|
| Standart Üye | Her hesabın temel üyeliği ve Üye/Müşteri çalışma alanı; GETMAKS açısından potansiyel müşteri havuzunun parçası | Otomatik alıcı/satıcı/kiracı rolü, profesyonel unvan veya gelir |
| Potansiyel Müşteri | GETMAKS'ın hizmet sunabileceği müşteri ilişkisi; ihtiyaç/etkileşimle nitelik kazanabilir | Kişinin tüm dosyalarda aynı rolü taşıması |
| Dosya içi taraf rolü | Alıcı, satıcı, mülk sahibi, kiraya veren, kiracı, devreden, devir alan vb. ilgili dosyada kayıtlıdır | Kalıcı hesap türü veya temel panelin değişmesi |
| Gayrimenkul Danışmanı | Profesyonel kabul/aktivasyon sonrası gayrimenkul profesyonelinin başlangıç unvanı | Ofis sahibi veya danışman yöneticisi olmak |
| Broker | Onaylı MAXIMUM franchise/ofis kuruluşu veya açık Broker/ALFA şube yöneticisi ataması ve gereken aktivasyon sonucu oluşan mesleki unvan | Otomatik olarak her ofise erişmek veya ALFA şubesinin sahibi olmak |
| Ofis üyeliği / görevlendirmesi | `OfficeMembership` veya broker–ofis ilişkisinin gerçek kaydı ve durumudur; erişim sunucuda izinlerle hesaplanır | Sadece üyelikten Broker unvanı kazanmak |
| Hizmet bedeli / hak ediş | İlgili sözleşme, olay ve iş koşulları doğrulandığında ayrı finansal yaşam döngüsüne girer | Sadece üyelik, talep veya mutabakat oluşturuldu diye kazanılmış sayılmak |

**Müşteri yaşam döngüsü:** Standart Üye → potansiyel müşteri → ihtiyaç/etkileşim → Talep Dosyası veya Hizmet Dosyası → ilgili dosyada taraf rolü → uygun işlem ve sözleşme koşulları → doğrulanmış finansal olay varsa ayrı finansal kayıt.

**Gayrimenkul profesyonel yaşam döngüsü:** Standart Üye → profesyonel başvuru/davet ve gerekli doğrulama → Gayrimenkul Danışmanı → (a) danışman olarak ofise bağlanma: unvan değişmez, aktif `OfficeMembership` kapsamındaki erişim açılır; veya (b) onaylı MAXIMUM franchise/ofis kuruluşu ya da (c) GETMAKS tarafından açık Broker/ALFA şube yöneticisi ataması: gereken koşullar sonrası Broker unvanı ve sadece ilgili aktif ofis kapsamındaki yetkiler açılır.

Broker/şube yöneticisi olarak açık atama ile normal danışman ofis üyeliği farklı ilişkilerdir. Üyelik veya unvan geçişi; sözleşme, ofis sahipliği, çalışma/ücret ilişkisi, ödeme ya da finansal hak edişi varsayımla oluşturmaz.

### 2.7 Pazar yeri vitrini — daha sonraki aşama

Pazar yeri, operasyon çekirdeğiyle aynı ilan ve yetkilendirilmiş mülk kayıtlarını kullanan vitrin katmanıdır. Kendi başına ikinci bir ilan/mülk kaynağı oluşturmamalıdır. Çekirdek akışlar doğru çalışmadan pazar yeri son rötuşlarına geçilmez.

## 3. Değişmez iş kavramları

### Ofis türü
- `Office.office_type = MAXIMUM | ALFA`
- MAXIMUM/ALFA, ofisin ticari/operasyonel türüdür.
- `ProfessionalWorkModel` ise tarihsel danışman çalışma/capability modelidir. Bunlar birbirine otomatik dönüştürülmez.

### Müşteriye sunulan hizmet kapsamı
- Uzaktan Destek
- Birebir Destek
- Uzman Hizmet

Bunlar hizmetin biçimi/kapsamıdır. Ofis türü, franchise yükümlülüğü veya genel “ticari plan” değildir.

### Franchise ve ücret ilişkileri
- Brokerın franchise/ofis açılış yükümlülüğü, markayla olan ilişkisinde tutulur; temel anlatım 5 yıllık franchise süresidir.
- Aylık/yıllık ödeme dönemi, ödeme yükümlülüğünün niteliğinden ayrı gösterilir.
- Marka tarafından belirli bir ofise atanmış brokerın maaş/SGK/prim düzeni yalnız bu çalışma ilişkisi gerçekten varsa uygulanır.
- Danışmanın giriş, aylık ve yıllık ücretleri alıcı tarafı (marka ve/veya ofis), neden ve koşul bilgisiyle ayrılır.
- “Ofis paketi” veya genel “ticari plan” adlı uydurma kavram oluşturulmaz. Mevcut veri modelinde bu ayrımları temsil eden yapı yoksa önce karar ve geçiş matrisi hazırlanır.

## 4. Üç ana operasyon kaydı

### 4.1 Talep Dosyası
Alıcı/kiracı ihtiyacını temsil eder. Müşteri, arama kriterleri, bütçe, konum, talep durumu, sorumlu ofis/danışman ve eşleşmelerle ilişkilidir.

### 4.2 Hizmet Dosyası
Mülk sahibi/satıcıdan alınan hizmetin merkezidir. Hizmet kapsamı, müşteri, mülk/temsil kanıtları, sözleşme/yetkilendirme, sorumlu ofis/danışman ve sonraki portföy/ilan adımlarını yönetir.

### 4.3 İşlem Dosyası
Talep Dosyası ile uygun Hizmet Dosyası/ilan ve tarafların mutabakatından doğar. İşlem türleri satış, kiralama veya devirdir. İşlem Dosyasının açılması kapanış anlamına gelmez. Sözleşmeler, teslim/devir kanıtları, bedel ve kapanış kontrolü ilgili işlem türüne bağlıdır.

## 5. Kanonik yaşam döngüsü

1. Standart Üye, GETMAKS’ın potansiyel müşteri havuzundaki temel hesabıyla ihtiyacını başlatır; bu noktada işlem taraf rolü veya gelir varsayılmaz.
2. Satıcı/mülk sahibi akışı Hizmet Dosyası; alıcı/kiracı akışı Talep Dosyası oluşturur.
3. Dosya uygun ofise ve yetkili danışmana atanır.
4. Hizmet Dosyasında hizmet kapsamı, mülk kanıtları, temsil/yetki sözleşmesi ve gerekli yetkilendirme kontrolleri tamamlanır.
5. Uygun Hizmet Dosyasından mülk, portföy ve ilan oluşturulur. İlanın kaynak Hizmet Dosyası bağlantısı korunur.
6. Talep Dosyası uygun ilan ve Hizmet Dosyalarıyla eşleşir.
7. Gösterim, talep + ilan + hizmet kaynağına bağlı yürütülür; yer gösterme formunun hazırlanması, imzalanması ve gösterim gerçekleşmesi farklı durumlardır.
8. Taraflar mutabık olduğunda işlem türüne uygun İşlem Dosyası başlatılır.
9. Satış/kiralama/devir için gereken sözleşme ve kanıtlar tamamlanır.
10. Gerçekleşme, teslim/devir ve kapanış koşulları doğrulanır.
11. Finansal etkiler yalnız gerçek ve doğrulanmış olaylardan ayrı tahakkuk, fatura, tahsilat ve ödeme kayıtları olarak doğar.

Sözleşme türü ve zorunluluğu, mevcut hukuk/marka tarafından onaylı gereklilik matrisi varsa oradan gelir. Mutabakat oluşmadan gelecekteki satış veya kira sözleşmesi imzalanmış sayılmaz.

## 6. Panel iletişiminin teknik standardı

- Aynı dosyanın her panelde ayrı kopyası olmaz; tek kaynak kayıt kullanılır.
- Her iş aksiyonu: kullanıcı etkileşimi → sunucu yetkisi → doğrulama → kalıcı kayıt/transaction → durum geçişi → audit/zaman çizelgesi → ilgili panellerde görünürlük.
- Bildirim varsa aynı olay kaydına bağlı ve idempotent çalışır; bildirim teslimi olayın kaydedilmesiyle karıştırılmaz.
- Bir paneldeki durum göstergesi diğer paneldeki aynı kayıtla çelişmemeli.
- Yetki menüden değil sunucuda, kaynak kaydın marka/ofis/ilişki sahipliği üzerinden belirlenir.

## 7. Ekran kalite standardı

1. Ana ekranlar boş teknik formlar yığını değil; iş kuyruğu, durum, sıradaki aksiyon ve ilgili kayıtları göstermeli.
2. Liste, filtre ve ayar/yapılandırma ekranları ayrılmalı. Örneğin belge gerekliliği yönetimi, broker başvuru listesine ham çok satırlı kod alanı olarak gömülmez; ayrı bir yapılandırma ekranı ve yapılandırılmış alanlarla sunulur.
3. Broker başvuruları ile danışman onboarding ekranları ayrı iş kuyruklarıdır. Ortak görünüm gerekiyorsa açık sekme/filtreyle ayrılır; birbirine karıştırılmaz.
4. Kullanıcıya gösterilen etiketler gerçek iş anlamını taşır ve Türkçe karakterleri doğru gösterir. `G8&#246nderildi` gibi ham/çift kaçışlı HTML entity gösterimi kabul hatasıdır; doğru metin `Gönderildi` olarak görünmelidir.
5. Üretim ortamında “İnceleme Modu”, rol taklidi veya yerel test kısayolları normal kullanıcıya gösterilemez.
6. Masaüstü 100% tarayıcı zoom'da temel form ve tablolar okunaklı, uygun genişlikte ve taşmasızdır; mobilde işlevler kaybolmaz.
7. Her buton gerçek bir aksiyon yapar veya açıkça devre dışı bırakılır; tamamlanmamış işlev sahte başarı mesajı göstermez.
8. Boş durumlar kullanıcıya bir sonraki anlamlı adımı söyler.
9. Formlar alan grupları, açıklamalar, doğrulama hataları ve kayıt sonrası geri bildirim içermelidir.
10. Tasarım prototipi uygulama sayılmaz; gerçek Blade ekranı, route, yetki, kayıt ve test birlikte tamamlanmalıdır.

## 8. Görseldeki Başvuru ekranının açık kusurları

`/admin/professional-applications` ekranında aşağıdaki sorunlar, mevcut uygulamada doğrulanıp düzeltilmesi gereken kabul kriterleridir:
- Durum seçeneğinde ham/bozuk `G8&#246nderildi` metni görünmemelidir; `Gönderildi` olmalıdır.
- Başvuru listesi içinde belge gerekliliğini `Kod|Ad|optional` metniyle topluca yazdıran ham textarea bulunmamalıdır. Gereklilik yönetimi ayrı ekrana, düzenlenebilir yapılandırılmış satırlara taşınmalıdır.
- Broker başvuruları ile onboarding aşamasındaki danışmanların aynı uzun sayfada ilgisiz bloklar gibi karıştırılması önlenmelidir.
- Başvuru listesi; arama, durum filtresi, aday satırı, başvuru tarihi, eksik belge durumu, karar ve detay aksiyonlarını net bir tablo/uygun kart görünümünde sunmalıdır.
- 33% tarayıcı zoom ile alınan görüntü tek başına CSS kusurunu kanıtlamaz. Ekran 100% zoom'da ayrıca doğrulanmalıdır; fakat bozuk etiket ve yanlış bilgi mimarisi zoomdan bağımsız hatalardır.

## 9. Mevcut sistemle uyumluluk ve güvenli değişiklikler

- C1–C5'teki başvuru belgeleri, bilgi talepleri, outbox, broker ilişki geçişleri ve merkezi erişim kontrolü korunur.
- `Office.office_type` ile tarihsel `ProfessionalWorkModel` ayrımı korunur; eski kayıtlar otomatik dönüştürülmez.
- `OfficeMembership` danışmanın ofis üyeliğidir; brokerın alt kullanıcı ilişkisi olarak modellenmez.
- Broker ilişki durumu, ofis üyeliği, profesyonel durumu, sözleşme ve panel erişimi ayrı kavramlardır.
- Eski/eksik kayıtlar tahminle sınıflandırılmaz. Migration gerekirse önce eski/yeni değerler için eşleme ve geri dönüş planı hazırlanır.
- Finansal kayıtlar yalnız doğrulanmış olaylardan sonra oluşturulur. Tahakkuk, fatura, tahsilat ve ödeme birbirinden farklı kayıtlardır.

## 10. Uygulama kabul kapısı

Bir ekran “tamamlandı” sayılabilmesi için birlikte doğrulanmalıdır:
- Doğru kaynak kaydı kullanması.
- Doğru rol/ofis/marka kapsamını uygulaması.
- Form ve filtrelerin gerçek verilerle çalışması.
- Butonun gerçek sunucu aksiyonu yapması.
- Geçerli/geçersiz durumların ele alınması.
- Sonucun diğer yetkili panellerde aynı kayıtta görünmesi.
- Hata, boş durum ve başarı geri bildiriminin düzgün olması.
- İlgili feature testlerinin geçmesi.
- Pint ve Blade view cache kontrollerinin geçmesi.

Yalnızca dosya eklemek, route tanımlamak veya testin bir bölümünü çalıştırmak tamamlanma kanıtı değildir.


---

**v3.1 değişiklik notu (26 Ekim 2026):** Standart Üye = potansiyel müşteri mantığı ile Gayrimenkul Danışmanı → Broker unvan yaşam döngüsü ayrıştırıldı. Normal ofis üyeliğinin Broker unvanı vermediği; MAXIMUM franchise kuruluşu ile ALFA şube yöneticisi atamasının farklı Broker yolları olduğu ve unvan/erişim/finansal hak edişin ayrı tutulduğu açıkça yazıldı.

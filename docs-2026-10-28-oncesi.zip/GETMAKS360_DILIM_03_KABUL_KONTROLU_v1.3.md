# Dilim 03 v1.3 — Kabul Kontrolü

## Yeni üyelik / profesyonel unvan kararları
- [x] İlk ekranda Standart Üye = GETMAKS açısından potansiyel müşteri mantığı anlatılıyor.
- [x] İhtiyaç seçimi, satış/kiralama hizmet talebini Hizmet Dosyasına; satın alma/kiralık arayışını Talep Dosyasına bağlıyor.
- [x] İhtiyaç belirtilmemiş üyede dosya içi rol veya hizmet geliri varmış gibi gösterilmiyor.
- [x] Profesyonel başlangıç unvanı Gayrimenkul Danışmanı olarak gösteriliyor.
- [x] Bir ofise normal danışman üyeliğinin unvanı Broker'a çevirmediği açık.
- [x] MAXIMUM franchise/ofis kuruluşu Broker yolu ve ilgili ofis alanı olarak ayrı gösteriliyor.
- [x] ALFA şubesine açık Broker/şube yöneticisi ataması ayrı Broker yolu olarak gösteriliyor; franchise sahipliği anlamı çıkarılmıyor.
- [x] Broker unvanı ile ofise erişimin aktif ilişki/izin koşullarına bağlı olduğu belirtiliyor.
- [x] Üye alanı profesyonel yaşam döngüsünde korunuyor.

## Önceki v1.2 kapsamı
- [x] MAXIMUM franchise kuruluşu ile marka tarafından kurulan ALFA şubesi ayrı akışlar.
- [x] Dış marka önizlemesinde `Maksimum Ofis / Elite` ve `Getmaks Alfa Bakırköy` kullanılıyor.
- [x] Dış marka modunda tüm iç ilişki bölümleri gizleniyor.
- [x] Satış, kiralama ve devir için dosya bazlı taraf rolleri gösteriliyor.
- [x] Yetki, gösterim, mutabakat, kapora/ön ödeme, nihai sözleşme ve kapanış kapıları korunuyor.
- [x] Kapora/ön ödeme kanıtı ile kira depozitosunun ayrı olduğu belirtiliyor.

## Tarayıcı kontrolü (HTML prototipi)
- [x] Yeni bölüm yükleniyor ve iki seçim kontrolü dinamik metni değiştiriyor.
- [x] Satış ve satın alma ihtiyaçları için doğru dosya başlangıcı gösteriliyor.
- [x] Danışman ofis üyeliği seçeneğinde unvan `Gayrimenkul Danışmanı` olarak kalıyor.
- [x] MAXIMUM ve ALFA seçenekleri Broker çıktısını farklı ilişkilerle açıklıyor.
- [x] Dış görünüm modunda yeni iç üyelik/unvan bölümü gizli kalıyor.
- [x] JavaScript çalışma zamanı hatası: 0.
- [x] Mobil 390px genişlikte yatay taşma yok (`clientWidth=390`, `scrollWidth=390`).

## Sınır
Bu kontroller HTML prototipinin etkileşim ve gösterim davranışını doğrular; Laravel, veritabanı, gerçek yetki, elektronik imza veya finans entegrasyonu için uygulama testi değildir.

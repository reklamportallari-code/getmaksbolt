# GETMAKS360 — İşlem Rolleri ve Dijital Sözleşme Kapıları v1.3

## 1. Hesap, profesyonel profil ve işlem rolü ayrıdır

- Her hesap önce `Standart Üye`dir; bunun ticari karşılığı GETMAKS'ın hizmet sunabileceği `Potansiyel Müşteri` havuzudur. İhtiyaç belirtmemiş üyede henüz dosya içi rol veya gelir varsayılmaz.
- Gayrimenkul profesyonelinin başlangıç unvanı `Gayrimenkul Danışmanı`dır. `Broker` unvanı onaylı MAXIMUM franchise/ofis kuruluşu veya GETMAKS tarafından açık Broker/ALFA şube yöneticisi ataması ve ilgili aktivasyon koşulları tamamlandığında kazanılır.
- Danışmanın bir ofise normal `OfficeMembership` ile katılması onu Broker yapmaz. `Ofis`, ayrı bir kullanıcı tipi değil; Brokerın gerçek ve aktif ofis ilişkisi veya danışmanın aktif `OfficeMembership` kaydı üzerinden izin kapsamıyla eklenen çalışma alanıdır.
- Standart üyelik, müşteri ilişkisi, dosya içi taraf rolü, profesyonel unvan, ofis ilişkisi ve finansal hak ediş ayrı kavramlardır. E-posta/e-Devlet doğrulaması tek başına profesyonel veya Broker erişimi sağlamaz.
- `Satıcı`, `Alıcı`, `Mülk Sahibi`, `Kiracı`, `Devreden` ve `Devir Alan` kalıcı hesap türleri değildir. İlgili dosya, ilan etkileşimi, gösterim, sözleşme ve işlem bağlamına bağlı taraf kayıtlarıdır.
- Aynı kişi farklı dosyalarda farklı taraf rollerine sahip olabilir. Bu, panelini veya genel kullanıcı kimliğini değiştirmez.

## 2. İç model ile dış marka adı

| İç model / ilişki | Müşteriye görünen ad | Dışarıya açılmayan iç bilgi |
|---|---|---|
| `office_type=MAXIMUM`; broker franchise yoluyla kurar | `Maksimum Ofis / [Brokerın eklediği ad]`; ör. **Maksimum Ofis / Elite** | MAXIMUM kodu, franchise ilişkisi ve iç kuruluş/işletme ayrıntıları
| `office_type=ALFA`; markanın kurduğu şube | `Getmaks Alfa [İlçe]`; ör. **Getmaks Alfa Bakırköy** | ALFA kodu, markanın kuruluş akışı ve broker varsa şube yöneticisi ataması

Konum, gerektiğinde ayrı konum bilgisi olarak sunulur. Resmî sözleşme/fatura üzerinde gerekli yasal taraf/unvan bilgileri korunur; public display name bunların yerine geçmez.

## 3. İşlem türüne göre taraf rolleri

| Aşama | Satış | Kiralama | Devir |
|---|---|---|---|
| Hizmet başlangıcı | Mülk Sahibi / Satıcı | Mülk Sahibi / Kiraya Veren | Devreden
| İlanla anlamlı etkileşim | Alıcı Adayı | Kiracı Adayı | Devir Alan Adayı
| Gösterim / inceleme | Alıcı + Satıcı/Mülk Sahibi; yer gösterme formu ilgili gösterime bağlanır | Kiracı + Kiraya Veren; yer gösterme formu ilgili gösterime bağlanır | Devir inceleme/görüşme tarafları; yer gösterme yalnız uygulanıyorsa
| Mutabakat | Alıcı + Satıcı | Kiracı + Kiraya Veren | Devreden + Devir Alan
| Nihai işlem | Alıcı + Satıcı | Kiracı + Kiraya Veren | Devreden + Devir Alan

Salt ilan görüntülemesi tek başına kalıcı bir hesap rolü yaratmaz. İletişim, talep veya gösterim isteği gibi anlamlı etkileşimler, ilgili ilan/Talep Dosyası bağlamında aday taraf kaydı oluşturabilir.

## 4. Sözleşme ve kanıt kapıları

### A. Hizmet başlangıcı ve ilan öncesi yetkilendirme

1. Üye hizmet isteğiyle Hizmet Dosyası başlatır.
2. Dosya tarafları, temsil yetkileri ve mülk/işletme bilgileri doğrulanır.
3. İlgili taraflar arasında **Yetki Sözleşmesi** için taslak hazırlanır.
4. Sözleşme sunulur, gerekli taraf imzaları alınır ve imza/kanıt kontrolü tamamlanır.
5. Yetki kapısı geçilmeden mülk/portföy/ilan yayınına geçilmez.

### B. İlan etkileşimi ve yer gösterme

1. Hizmet Dosyası, mülk, portföy ve ilan aynı kaynak ilişkisiyle bağlanır.
2. Alıcı/kiracı/devir alan adayı anlamlı etkileşimde bulunduğunda rol, ilgili dosya/ilan bağlamında oluşturulur.
3. Gösterim planlanırsa **Yer Gösterme Formu/Belgesi** o gösterim kaydına, taraflara ve imza kanıtına bağlı tutulur.
4. Formun taslağı, imzaya sunulması, taraf imzaları, kanıt kontrolü ve gösterimin gerçekleşmesi ayrı durumlardır.

### C. Mutabakat ve kapora/ön ödeme

1. Taraf mutabakatı ayrı kalıcı olay/kayıt olarak kaydedilir. Eşleşme veya gösterim tek başına mutabakat değildir.
2. Uygulanabilir sözleşme/iş koşullarına göre **Kapora/Ön Ödeme Sözleşmesi** hazırlanabilir.
3. Kapora/ön ödeme yükümlülüğü, sözleşmenin imzası ve ödeme kanıtı ayrı durumlar ve kayıtlar olarak izlenir.
4. Kiralama akışında kapora/ön ödeme ile kira depozitosu/güvence bedeli birbirine dönüştürülmez.
5. Gerçek ödeme veya tahsilat yapılmış gibi bir durum yalnız doğrulanmış ödeme kaydı/kanıtıyla gösterilir.

### D. Nihai işlem sözleşmesi

- **Satış:** Satış Vaadi Sözleşmesi; kullanılacak kesin tür, format ve imza standardı onaylı hukuk gereklilik matrisiyle doğrulanır.
- **Kiralama:** Kiralama/Kira Sözleşmesi; kira şartları, taraflar, depozito ve teslim maddeleri ilgili onaylı şablondan gelir.
- **Devir:** Devir Sözleşmesi; devir alt türü, izinler, taraflar ve imza şartları ilgili onaylı alt tür matrisinden gelir.

Nihai dijital sözleşme taslağı, İşlem Dosyası için taraf/temsil bilgileri, süreç adımları ve zorunlu belgeler tamamlandığında doğru dosya verilerinden oluşturulur. Taslak oluşturma, imzaya sunma, tüm taraf imzaları ve kanıt kontrolü farklı durumlardır. Prototipteki demo butonları gerçek elektronik imza veya hukuki geçerlilik teyidi sağlamaz.

### E. İşlem Dosyası kapanış kapısı

Aşağıdakilerin tamamı gerekir:

- İşlem tarafları ve temsil yetkileri doğrulanmış.
- İşlem türüne uygun süreç adımları, gerekli gösterim/mutabakat ve onaylar tamamlanmış.
- Onaylı gereklilik matrisindeki zorunlu belge sürümleri tamamlanmış.
- Gerekli sözleşmelerin taraf imzaları ve imza/kanıt doğrulaması tamamlanmış.
- Kapora/ön ödeme uygulanıyorsa ilgili sözleşme ile ödeme kanıtı doğrulanmış.
- İşlem türüne uygun gerçekleşme/teslim kanıtı kaydedilmiş.

Kapanışın oluşması; tahakkuk, fatura, tahsilat ve ödeme kayıtlarını tek bir kayıt haline getirmez. Finansal etkiler ayrı, onaylı kurallara bağlıdır.

## 5. Hukuk/uyum sınırı

Bu belge, ürün akışının ekran/veri sahipliği tasarımıdır; hukuki görüş değildir. Sözleşmenin türü, zorunluluğu, temsil ve imza şartları, elektronik imza türü ve geçerlilik koşulları marka tarafından onaylanmış hukuk gereklilik matrisinden beslenmelidir. Matris yapılandırılmamışsa sistem “eksiksiz” veya “hukuken tamamlandı” varsayımı yapmaz.

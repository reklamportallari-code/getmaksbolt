# GETMAKS360 — Üyelik, Potansiyel Müşteri ve Profesyonel Unvan Karar Matrisi v1.0

Tarih: 26 Ekim 2026  
Durum: Tasarım kararı / prototipte işlenmiştir; Laravel uygulamasına ayrıca onaylı görevle aktarılacaktır.

## 1. Ana karar

GETMAKS360'da **Standart Üye**, her hesabın temel üyelik durumudur ve ticari mantıkta GETMAKS'ın hizmet sunabileceği **potansiyel müşteri** havuzunu temsil eder. Gayrimenkul profesyonelinin başlangıç mesleki unvanı ise **Gayrimenkul Danışmanı**dır. **Broker** unvanı, onaylı MAXIMUM franchise/ofis kuruluşu veya GETMAKS tarafından açık Broker/ALFA şube yöneticisi görevlendirmesi ve gerekli aktivasyon koşulları tamamlandığında kazanılır.

## 2. Birbirine karıştırılmayacak kavramlar

| Kavram | Ne ifade eder? | Tek başına ne oluşturmaz? |
|---|---|---|
| Standart Üye | Temel kullanıcı hesabı ve Üye/Müşteri alanı | Kalıcı alıcı/satıcı/kiracı rolü, profesyonel statü, hizmet bedeli/hak ediş |
| Potansiyel Müşteri | GETMAKS'ın hizmet veya aracılık hizmeti sunabileceği müşteri ilişkisi | Kesinleşmiş talep, işlem, kazanılmış gelir |
| Talep Dosyası | Alıcı/kiracı veya uygun devralan tarafın ihtiyacını temsil eder | Global kullanıcı rolü veya gelir tahakkuku |
| Hizmet Dosyası | Mülk sahibi/satıcı/kiraya veren/devreden tarafına hizmet sürecini temsil eder | Otomatik yetki, ilan veya işlem kapanışı |
| Dosya içi taraf rolü | Alıcı, satıcı, mülk sahibi, kiracı, kiraya veren, devreden, devir alan vb. | Kalıcı kullanıcı tipi veya temel panel değişimi |
| Gayrimenkul Danışmanı | Profesyonel kabul/aktivasyon sonrası başlangıç unvanı | Ofis sahibi olmak, Broker olmak veya otomatik ofis yönetimi |
| Broker unvanı | Onaylı ofis kuruluşu veya açık Broker/şube yöneticisi ataması sonrası mesleki unvan | Her ofise erişmek, ALFA şubesinin sahibi olmak, otomatik maaş/prim |
| `OfficeMembership` | Danışmanın belirli bir ofise üyeliği ve izin kapsamı | Broker unvanı |
| Broker–ofis ilişkisi | Franchise/ofis sahibi veya marka tarafından atanmış şube yöneticisi gibi gerçek ilişki | İlişki türü farklıyken varsayımla sahiplik/ücret yükümlülüğü |
| Finansal hak ediş | Sözleşme, gerçek olay ve ilgili koşullar doğrulandıktan sonra oluşabilecek finansal sonuç | Üyelik, talep veya mutabakat anında otomatik gelir |

## 3. Potansiyel müşteri yaşam döngüsü

1. Hesap açılır ve temel durum Standart Üye'dir.
2. Standart üyelik, GETMAKS açısından kişiyi potansiyel müşteri havuzuna alır; henüz ihtiyaç belirtmemiş olabilir.
3. İhtiyaç ve işlem yönüne göre uygun akış başlar:
   - Mülkümü satmak istiyorum → Hizmet Dosyası.
   - Mülkümü kiraya vermek istiyorum → Hizmet Dosyası.
   - Gayrimenkul satın almak istiyorum → Talep Dosyası.
   - Kiralık gayrimenkul arıyorum → Talep Dosyası.
   - İşletme/hak devri → işlem yönü ve hizmet ihtiyacına göre Hizmet Dosyası veya Talep Dosyası.
4. Alıcı/satıcı/kiracı vb. taraf rolleri ilgili dosya, ilan etkileşimi, gösterim veya işlem bağlamında tutulur. Aynı hesap farklı dosyalarda farklı roller alabilir.
5. Hizmet bedeli ve aracılık hak edişi yalnız sözleşme ve gerçek iş/işlem koşulları doğrulandığında ayrı finansal yaşam döngüsüne alınır.

## 4. Gayrimenkul profesyoneli yaşam döngüsü

1. Hesap temel Standart Üye hesabını ve müşteri alanını korur.
2. Kişi profesyonel başvuru/davet, gerekli nitelik-belge ve aktivasyon kontrollerinden geçer.
3. Gayrimenkul profesyoneli başlangıç unvanı **Gayrimenkul Danışmanı**dır.
4. Buradan üç ayrı durum izlenir:
   - **Ofissiz danışman:** Danışman unvanı korunur; ofis operasyonları ve danışman yönetimi açılmaz.
   - **Ofise danışman olarak katılım:** Aktif `OfficeMembership` ile izin kapsamındaki ofis alanı açılır; unvan Gayrimenkul Danışmanı olarak kalır.
   - **Broker geçişi:** Onaylı MAXIMUM franchise/ofis kuruluşu veya GETMAKS'ın açık Broker/ALFA şube yöneticisi ataması ve gerekli aktivasyon koşulları tamamlanınca Broker unvanı ve yalnız ilgili aktif ofis ilişkisinin izin verdiği yönetim alanı açılır.

**MAXIMUM ve ALFA farkı korunur:** MAXIMUM franchise/ofisini broker başlatır; ALFA şubesini GETMAKS Marka kurar. MAXIMUM Broker yolu franchise/ofis kuruluşu üzerinden, ALFA Broker yolu açık şube yöneticisi ataması üzerinden ilerler. ALFA ataması şube sahipliği/franchise ilişkisi olarak sunulmaz.

## 5. Erişim ve güvenlik kuralları

- E-posta veya e-Devlet doğrulaması tek başına profesyonel kabul, Broker unvanı veya ofis yetkisi oluşturmaz.
- Panel ve buton görünürlüğü tek başına güvenlik değildir; bütün erişim sunucuda gerçek profil, unvan, aktif ilişki, ofis sahipliği/yöneticiliği ve izinler üzerinden kontrol edilir.
- Broker unvanı ile aktif ofis erişimi ayrı değerlendirilir. Askıya alınmış/sonlandırılmış ilişki, ilişkiye bağlı operasyon erişimini etkiler; üye alanını silmez.
- Ofis üyeliği, Broker görevlendirmesi, franchise sözleşmesi, istihdam/maaş/SGK/prim ve finansal hak ediş farklı ilişki/kayıt türleridir.
- Geçmiş unvan/ilişki geçişleri denetim izinde korunur. Eski kayıtlar tahminle dönüştürülmez; gereken veri geçişi ayrı eşleme ve geri dönüş planıyla ele alınır.

## 6. Prototipte kontrol edilecek örnekler

- Üye ihtiyacı seçimi `Hizmet Dosyası` ve `Talep Dosyası` başlangıçlarını doğru değiştirir.
- Henüz ihtiyacı olmayan standart üye için dosya içi taraf rolü yaratılmaz.
- Danışmanın normal ofis üyeliği seçeneği sonucunda unvan `Gayrimenkul Danışmanı` kalır.
- MAXIMUM kuruluşu sonucunda Broker + MAXIMUM ofis alanı gösterilir.
- ALFA şubesine Broker olarak atanma sonucunda Broker + atanmış ALFA alanı gösterilir; franchise sahipliği gösterilmez.
- Kamuya açık marka görünümü bu iç üyelik/unvan ilişkilerini göstermez.

## 7. Uygulama notu

Bu belge tasarım kararını sabitler. Şu anda `/mnt/data` içindeki HTML prototip ve mimari doküman güncellenmiştir; Laravel kaynak kodu, veritabanı, migration veya gerçek yetki davranışı değiştirilmemiştir. Kod uygulamasına geçmeden önce mevcut modeller ve `Professional.status`, profesyonel başvuru türleri, `OfficeMembership`, `BrokerEngagement` ile ofis başvuru/kayıt süreçleri karşılaştırılmalı; alan ve durum adları mevcut modelle uyumlu karara bağlanmalıdır.

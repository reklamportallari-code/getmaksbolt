# Değişiklik Günlüğü

## 2026-10-27 — Getmaks360 ekosistem blueprint eklenmesi

- Marka, ofis, danışman, broker, stratejik ortak ve yatırımcı katmanlarını tek akışta tanımlayan `14_GETMAKS360_EKOSISTEM_BLUEPRINT_v1.0.md` dosyası eklendi. Doküman, kullanıcı/üye başlangıcı, ofis ve profesyonel bağlanma, talep/hizmet/işlem dosya zinciri, panel yapısı, role/scope yetki modeli ve gelir paylaşımı akışını tek bir plan olarak netleştirir.

## 2026-10-22 — Bütünleşmiş panel tasarım sözleşmesi

- Üye/Müşteri, Broker, Danışman, Marka ve gelecekteki Yatırımcı yüzeyleri için ana ürün şartnamesinin proje içi veri sahipliği, rol/scope ve durum eşlemesi `docs/13_BUTUNLESMIS_PANEL_SARTNAMESI.md` içinde kayıt altına alındı.
- C1–C4 uygulamaları korunacak; C5 merkezi broker erişim kontrolü, bu tasarım sözleşmesi onaylandıktan sonraki uygulama sırasına bırakıldı. Bu belge çalışır bir yeni ekran, migration veya yetki değişikliği getirmez.
- Güncel ürün hedefi MAXIMUM/ALFA ofis türü olarak kaydedildi. Eski danışman çalışma modeli kayıtları için otomatik dönüşüm yapılmayacak; migration ve veri eşleme ayrı kararlaştırılacak.

## 2026-10-01 — Broker → Ofis → Marka Ticari Yaşam Döngüsü

- Admin ofis wizard'ı mevcut broker, yeni broker daveti ve brokerın sonra atanacağı üç kuruluş modelini tek akışta destekleyecek şekilde genişletildi.
- Ofis kurumsal alanları, ticari ilişki lifecycle alanları ve faturalandırma başlangıç/tahakkuk hazırlığı additive migration'larla eklendi; mevcut identity, invitation ve commercial action'lar korundu.
- Taslak → Onaya Gönder → Reddet/Yeniden Gönder → Onayla ve Aktifleştir rotaları eklendi. Aktivasyon fatura kesmez; sözleşmedeki faturalandırma başlangıcına göre mevcut ChargeAccrual hazırlığını oluşturur.
- Dört lifecycle feature testiyle mevcut broker, yeni broker invitation, deferred broker ve red sonrası yeniden onay yolları doğrulandı. Full suite 164 test / 858 assertion geçti; legacy proje değiştirilmedi.

## 2026-09-22 — Mülk sahibi akışında kurumsal, ticari ve operasyonel katman ayrımı netleştirildi

- Brand, Office, Broker ve Consultant katmanları ayrı autorite ve sorumluluk alanı olarak netleştirildi.
- Markanın ticari katmanı (CommercialAgreement, SubscriptionPlan, RevenuePolicy) ile ofis/broker operasyonel katmanı ayrıldı.
- ServicePackage, müşteri hizmet kapsamı ve faturalama modelidir; iş akışının teknik/operasyon katmanı değildir.
- Talep Dosyası ve Hizmet Dosyası ayrı akış olarak tanımlandı; aynı müşteri, aynı marka ve aynı ofis kapsamı içinde bir arada çalışsalar da ortak nesne değildir.
- Mülk sahibi akışında ServiceContract, External Authorization, taşınmaz numarası ve Property sırası netleşti; listing ön koşulu için tek karar noktası sonraki fazda kurulacaktır.
- Mevcut yaşam döngüsü bozulmadan yeni kararlar docs/07_DECISIONS.md içinde kayıt altına alındı; uygulama aşaması ancak onay sonrası başlayacaktır.

## 2026-09-19 — Faz 3C.4 Portfolio + Listing Aşama 1

- Service File üzerinden gerçek Property akışına Portfolio ve Listing katmanı eklendi; `service_files -> properties -> portfolios -> listings` zinciri tek operasyon akışında tamamlandı.
- `portfolios` ve `listings` tablolari, ilişkili model sorumlulukları ve factory/migration katmanları oluşturuldu; tek aktif portföy ve ilan kısıtı ilk sürümde korundu.
- `CreatePortfolio` ve `CreateListing` action'ları gerçek brand/office/consultant/customer/service_file/property bağlamıyla çalışacak şekilde eklendi; audit log kaydı ve temel erişim görünürlüğü dahil edildi.
- Operations rotaları `operations.portfolios.store` ve `operations.listings.store` olarak tanımlandı; Service File detay sayfasında Portföy ve İlan oluşturma arayüzü gösterildi.
- Aşama 1 iş akışı için hedef özellik testi yazıldı ve `php artisan test tests/Feature/PortfolioListingFlowTest.php --compact` ile başarıyla geçti; tam suite kapsamı bu adımda genişletilmedi.

## 2026-09-15 — Faz 3C.3 Ayarlar + Kullanıcı/Yetki Yönetimi

- `/admin/settings` desteklenen sistem ve marka alanları için `Düzenle / Vazgeç / Kaydet`; aktif Data Havuzu politikaları için mevcut versiyonlama action'ını kullanan `Yönet` akışına geçirildi. Teknik ortam, slug, ofis sayısı ve DocumentSequence değerleri salt okunur bırakıldı.
- Uygulama adı, saat dilimi, dil ve para birimi beyaz listeli `system_settings` kayıtlarıyla kalıcı hale getirildi ve çalışma zamanı config'ine bağlandı.
- Kullanıcı detayına Genel Bilgiler, Rol ve Yetkiler, Kurumsal İlişki, Durum ve Audit sekmeleri eklendi. User durumu Professional/onboarding/üyelik yaşam döngülerinden ayrıldı; aktif olmayan hesapların girişi ve mevcut oturumu engellendi.
- Mevcut rol izinleri rol seviyeli kapatma override'larıyla yönetilebilir hale getirildi; kullanıcıya özel override ve yeni RBAC motoru oluşturulmadı. Teknik permission kodları Türkçe iş etiketleri ve Kurumsal Yönetim/Operasyon/Ticari/Sistem gruplarıyla sunuldu.
- Son aktif marka yöneticisinin rolü/durumu ile kritik sistem yönetimi izinleri backend action katmanında kilitlendi. Sistem, marka, havuz politikası, kullanıcı durumu ve rol değişiklikleri audit edildi.
- 14 yeni test dosyası ve ek güvenlik senaryolarıyla tam suite 139 test / 700 assertion geçti; 42 migration ve 123 uygulama rotası doğrulandı.

## 2026-09-14 — Faz 3C.2 Brand Admin Kullanıcılar/Yetkiler + Ayarlar Restorasyonu

- Brand Admin SİSTEM menüsüne `Kullanıcılar ve Yetkiler` ile `Ayarlar` permission-koşullu, aktif bağlantılar olarak geri getirildi; pasif placeholder kullanılmadı.
- Mevcut RolePermissionRegistry/Gate altyapısına yalnız `users.view`, `roles.view`, `permissions.view` ve `settings.view` izinleri eklendi; yeni RBAC motoru veya migration oluşturulmadı.
- Kullanıcı listesi ve detay görünümü ile rol/izin matrisleri `/admin/users`, `/admin/users/{user}`, `/admin/roles` ve `/admin/permissions` GET rotalarına bağlandı.
- Ayarlar ekranı yalnız gerçek uygulama config'i, marka kaydı, DocumentSequence numaralandırması ve aktif PoolClaimPolicy değerlerini gösteriyor; sahte ayar veya bildirim kontrolü eklenmedi.
- Broker ve Consultant erişimleri role middleware ve controller Gate katmanında 403 ile engellendi; mevcut kurumsal, operasyon, ticari, audit ve Review Mode davranışları değiştirilmedi.
- 7 yeni regresyon testi / 48 assertion eklendi; tam suite 123 test / 612 assertion ile geçti. Migration sayısı 39 olarak korundu, uygulama rotası 116 oldu; Pint, Blade cache ve Vite production build doğrulandı.

## 2026-09-14 — Faz 3C.1 Dosya Merkezli CRM Minimal Uyarlaması

- Mevcut Customer/DataPool/RequestFile/ServiceOffer/ServiceFile motorları korunarak müşteri ekranları talep ve mülk sahibi dosya niyetlerine bağlandı; talep ve hizmet yönleri kullanıcı dilinde ayrıldı.
- Brand Admin marka genelinde, Broker ve MAXIMUM aktif ofis kapsamında Data Havuzu kaydı oluşturabilir hale geldi; ALFA ortak havuz engeli korundu. Broker yeni kaydı havuzda bırakabilir veya policy sınırında aktif ofis danışmanına atayabilir.
- Talep/Hizmet akışlarında Consultant ve Broker ofisi aktif üyelikten otomatik çözülüyor; Brand Admin ofis seçiyor. Broker talebi danışmana atayabiliyor veya ofis Data Havuzuna bırakabiliyor; çapraz-ofis POST erişimi engelleniyor.
- Yeni ofis kodu kullanıcıdan kaldırıldı ve `GET-O-NNNNNN` biçiminde transaction/kilit kullanan sayaçla otomatikleştirildi; eski kodlar ve mevcut ofis kayıtları değiştirilmedi.
- Permission verilen navigasyon öğeleri tıklanabilir route olarak sunuldu; izinsiz/rotasız pasif placeholderlar kaldırıldı.
- Danışman ve broker ticari ekranlarına Türkçe presenter katmanı eklendi; teknik durum, fiyat modeli, entitlement anahtarı/türü, minor-unit ve basis-point sunumu kullanıcı diline çevrildi.
- `request_files` tablosuna nullable dosya yönü ve talep kriteri alanları eklendi; eski satırlar, work-model history, ticari kayıtlar ve aktif dosyalar taşınmadı veya silinmedi.
- Property, Portfolio, Listing, Marketplace, gerçek geo-routing, Transaction ve final RevenueDistribution kapsamına girilmedi; legacy proje değiştirilmedi.
- Tam suite 116 test / 564 assertion ile geçti; 39 migration ve 111 uygulama rotası, Blade cache, Pint ve Vite production build doğrulandı.

## 2026-09-13 — Approval / Aktivasyon Semantiği Düzeltmesi

- Brand Admin’in doğrudan Office/Broker/Consultant ve Brokerın kendi ofisinde Consultant oluşturması ayrı approval aşamasından çıkarıldı; ticari plan authorization sınırları korundu.
- Doğrudan Consultant kaydı `ONBOARDING`, aktif marka/ofis üyeliği, aktif çalışma modeli ve aktif subscription ile oluşturuluyor; aktivasyon readiness üzerinden ilerliyor.
- Aktif danışmanın onboarding/profil güncellemesinde `PENDING_APPROVAL` durumuna geri düşmesi engellendi; mevcut ACTIVE kayıtlar, work model/subscription tarihçeleri ve RequestFile/ServiceFile snapshot’ları değiştirilmedi.
- Readiness alan ve metinleri approval kavramından ayrıldı; audit adları doğrudan akışta `ConsultantCreated` ve `ConsultantActivated` olarak netleştirildi.
- Consultant’ın Customer, RequestFile ve ServiceOffer oluşturmasının approval üretmediği regresyonlarla sabitlendi. Aday başvuru matrisi ADR-039’a, Listing/Transaction approval ihtimalleri gelecek fazlara kaydedildi; yeni Application/Listing/Transaction motoru oluşturulmadı.
- Yeni 8 test / 51 assertion ile tam suite 78 test / 428 assertion geçti. Migration/route eklenmedi; 38 migration ve 109 uygulama rotası korundu; Pint, Blade cache ve Vite production build başarılı.

## 2026-09-13 — Yerel Panel İnceleme Modu

- Giriş ekranına ve oturum içi sidebar'a marka yöneticisi, broker, MAXIMUM ve ALFA fixture hesapları arasında tek tıkla geçiş sağlayan yerel inceleme seçicisi eklendi.
- Rol middleware'leri, Gate kuralları ve profesyonel bağlamı bypass edilmedi; seçilen role ait gerçek fixture hesabıyla oturum yenileniyor.
- İnceleme endpoint'i yalnız `PANEL_REVIEW_MODE=true` ve local/testing ortamında çalışıyor; production ortamında 404 döndürüyor.
- İnceleme modu için 5 test / 17 assertion eklendi; tam suite 70 test / 377 assertion, 109 uygulama rotası, Pint, Blade cache ve Vite production build ile doğrulandı.

## 2026-09-12 — Faz 3A.1 Kurumsal Onboarding UX Düzeltmesi

- Ofis yaşam döngüsü DRAFT/SETUP/READY/ACTIVE/SUSPENDED/TERMINATED olarak genişletildi; readiness servisi, READY/ACTIVE gate’leri, durum tarihçesi ve audit akışları eklendi.
- Ofis oluşturma üç adımlı, broker oluştur/seç/ata dört adımlı ve danışman onboarding’i beş adımlı gerçek kayıt akışlarına dönüştürüldü.
- Marka yöneticisinin Brokerlar ana ekranına `+ Yeni Broker Ekle` eylemi eklendi; ofis seçimi ve dolu ofiste açık tarihçeli değişim onayı uygulandı.
- Ofis, broker ve danışman detaylarında gerçek sekme izolasyonu; Türkçe yaşam döngüsü sunumu, kurulum/aktivasyon checklist’leri ve responsive tablo/kart davranışı tamamlandı.
- Yerel fixture kişi ve plan adları insan-okur örneklere geçirildi; production fiyat/oran verisi oluşturulmadı.
- Toplam 38 migration ve 108 uygulama rotası doğrulandı; 03A.1 matrisi 10 test / 110 assertion, tam suite 65 test / 360 assertion ile geçti.
- Pint, Blade view compilation ve Vite production build başarılı; Property/Portfolio/Listing/Marketplace/Transaction ve final Finance/RevenuePool kapsamına girilmedi, legacy proje değiştirilmedi.

## 2026-09-11 — Faz 3A Brand → Office → Broker → Consultant UX

- Admin menüsü ve dokuz dashboard kartı spesifikasyondaki grup, filtre ve `/admin/*` rol bağlamına eşlendi.
- `/admin/offices` liste, üç adımlı yeni ofis wizard'ı, detay, düzenleme, pasife alma ve broker ata/değiştir ekranları eklendi.
- Broker değişimi eski `office_memberships` satırını değişim tarihinde kapatıp yeni satır açacak biçimde tarihçeli ve audit'li uygulandı; tek aktif broker constraint'i korundu.
- Admin ve broker danışman ekranları aynı ofis-scope'lu sorgu servisiyle gerçek kayıt, telefon araması, durum/model/üyelik filtreleri ve operasyon metriklerini gösteriyor.
- Dört adımlı danışman wizard'ı User, Professional, marka/ofis membership, MAXIMUM/ALFA work model ve gerçek aktif subscription planını tek transaction içinde oluşturuyor.
- Danışman detaylarına istenen sekmeler, overview kartları, Data Havuzu/claim görünümü, aktivasyon checklist'i, tarihçeli model/plan değişimi, suspend ve terminate akışları eklendi.
- Brokerın plan, work model, suspend ve terminate sınırları açık `BrokerCommercialAuthority` bayrakları ve kendi ofis scope'uyla korundu.
- Office, subscription, work-model request ve broker authority şemaları 1 yeni migration ile genişletildi; hard delete kullanılmadı.
- Faz 3A için 7 test ve 58 assertion eklendi; tüm suite 55 test ve 250 assertion ile başarılı. 100 route, Pint, view compilation ve Vite build doğrulandı.
- Property/Portfolio/Listing/Marketplace/Transaction ve final Finance/RevenuePool kapsamına girilmedi; legacy projede değişiklik yapılmadı.

## 2026-09-11 — Faz 3 Governance + Commercial Policy + UX Remediation

- Admin Broker akışı `/admin/brokers` liste/detay rotalarına taşındı ve marka paneli bağlamında tutuldu.
- Broker danışman listesi aktif ofis membership scope'u, gerçek consultant kayıtları, MAXIMUM/ALFA badge/filtreleri, üyelik ve operasyon metrikleriyle yenilendi; çapraz-ofis detay erişimi 404 oldu.
- Admin menüsü kurumsal/ticari/operasyon/yönetim; broker ve danışman menüleri rol bağlamlarına göre yeniden gruplandı.
- SubscriptionPlan pricing modeli genişletildi; CommercialAgreement, ChargePolicy ve PlanEntitlement ayrı tarihçeli katmanlar olarak eklendi.
- BrokerCommercialAuthority ile plan atama, indirim, ücretsiz hak ve kullanım limiti yetkileri varsayılan reddetme yaklaşımıyla sınırlandı.
- CommercialException standart plan/fiyatı değiştirmeden ücretsiz/hediye/indirim/waiver/özel koşul snapshot'ı saklayacak şekilde eklendi.
- RevenuePolicy MAXIMUM/ALFA parametreleri ve 10.000 basis-point toplam kuralıyla eklendi; gerçek gelir dağıtımı uygulanmadı.
- Idempotent UsageEvent → ChargeAccrual altyapısı kota ve charge-policy snapshot'ıyla kuruldu; fatura/tahsilat uygulanmadı.
- WorkModelPolicy capability matrisi Customer CRM, Talep/Hizmet Dosyası, bireysel kazanç ve paylaşım uygunluklarıyla genişletildi.
- 10 Faz 3 testi eklendi; tüm suite 48 test ve 193 assertion ile başarılı. Vite build ve Pint doğrulandı.
- Property/Portfolio/Listing/Marketplace/Transaction ve final Finance/RevenuePool kapsamına girilmedi; legacy projede değişiklik yapılmadı.

## 2026-09-10 — Faz 2 CRM + Data Pool + Request + Service

- Customer, CustomerActivity, duplicate uyarı/normalizasyonu ve rol bazlı visibility eklendi.
- Yalnız MAXIMUM danışmanın eriştiği Data Havuzu, tek aktif PoolClaim, tarihçeli policy, ilk temas ve otomatik expiry/release akışları eklendi.
- TD numaralı RequestFile, zorunlu lost reason, durum geçmişi ve değişmez work_model_snapshot uygulandı.
- Üç ServicePackage ve feature seed'i; tarihçeli, minor-unit/basis-point ServicePricingPolicy yönetimi eklendi.
- HT numaralı, parent/version tarihçeli ServiceOffer ve yalnız kabul edilen tekliften doğan tek aktif HD numaralı ServiceFile uygulandı.
- 19 adlandırılmış domain eventi, organizasyon kapsamlı audit ve periyodik claim expiry komutu eklendi.
- Brand/Broker/Consultant Faz 2 dashboard, menü ve responsive operasyon ekranları bağlandı; ALFA Data Havuzu UI/backend erişimi kapatıldı.
- Faz 2 için 22 yeni test eklendi; tüm suite 38 test ve 136 assertion ile başarılı.
- Legacy GETMAKS360 üzerinde değişiklik yapılmadı; Faz 3/4 kapsamına girilmedi.

## 2026-09-09 — Faz 1 Corporate Core

- GETMAKS marka ve tek ofis modeli, production-safe kurumsal seed ve yerel development fixture'ları eklendi.
- User'dan ayrılmış Professional; tarihçeli marka/ofis üyelikleri ve tek aktif broker/ofis constraint'leri kuruldu.
- MAXIMUM/ALFA çalışma modeli, onaylı değişiklik workflow'u ve WorkModelPolicy capability servisi eklendi.
- Ofis/danışman için polymorphic aylık-yıllık plan ve abonelik altyapısı kuruldu; ticari tutarlar hard-code edilmedi.
- Merkezi rol/izin, audit ve üç rol için responsive Faz 1 panelleri eklendi.
- 16 test, 54 assertion ve Vite production build başarıyla tamamlandı.

## 2026-09-09 — Faz 0 Bootstrap

- Temiz Laravel proje kökü, Laravel Boost, SQLite, temel migrationlar ve üst seviye mimari kuruldu.
- Kalıcı proje hafızası belgeleri eklendi; bağımsız Git deposu başlatıldı.
- Test runner ve Vite üretim derlemesi doğrulandı; legacy projeden dosya taşınmadı.

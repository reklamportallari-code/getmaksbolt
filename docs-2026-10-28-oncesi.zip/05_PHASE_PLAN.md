# Faz Planı

## 00 — Bootstrap

Temiz Laravel kökü, ortam doğrulaması, üst seviye mimari, kalıcı dokümantasyon, Git başlangıcı. İş modülü geliştirilmez.

Çıkış kapısı: Laravel açılır; DB, migration, test ve route komutları çalışır; docs eksiksizdir; handoff günceldir.

## 01 — Corporate Core

Marka, Ofis, Broker, Danışman, çalışma modeli ve üyelik/aktivasyon omurgası.

## 02 — Customer & Service Core

Customer, Data Havuzu, görüşme, Talep Dosyası, hizmet modeli ve Hizmet Dosyası.

## 03 — Governance, Commercial Policy & UX Remediation

Marka yönetim bağlamı, broker danışman UX'i, plan/ücret/hak ayrımı, ticari sözleşmeler, broker yetki çerçevesi, çalışma modeli ve gelir paylaşım politika altyapısı. Fatura, tahsilat ve gerçek gelir dağıtımı üretilmez.

## 04 — Property Core

Property, Portfolio, Listing ve tek pazaryeri.

## 05 — Lead, Appointment & Transaction Core

Lead, randevu, gösterim, ticari teklif ve İşlem.

## 06 — Finance & Revenue Pool

Fatura, tahsilat, gelir dağılımı, bireysel/ofis hakedişi, profesyonel faturası, ödeme ve Kazanç Havuzu.

## 07 — Final Test, Temizlik ve Kabul

Uçtan uca kabul zinciri, güvenlik/yetki regresyonları, veri bütünlüğü, performans, dokümantasyon ve ürün sahibi kabulü.

## Faz disiplini

- Bir faz tamamlanmadan sonraki faza geçilmez.
- Var olan ileri-faz kodu o fazı onaylanmış yapmaz.
- Her fazın kabulü test kanıtı, güncel handoff ve ürün sahibi geçiş kararı ister.
- Güncel faz ve izin verilen sonraki adım `09_CODEX_HANDOFF.md` içindedir.

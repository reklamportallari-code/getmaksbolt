﻿# GETMAKS360 V2 — Ana İş Modeli Doğrulaması ve Kabul Matrisi

**Amaç:** `10_SYSTEM_BEHAVIOR_CONTRACT.md` içindeki iş akışlarının gerçekten uçtan uca tanımlı olup olmadığını; `11_CROSS_MODULE_INTERACTION_MATRIX.md` ile uyumlu olarak kod kanıtı, belgelenmiş hedef ve ürün kararı diye ayırmak.  
**İnceleme sınırı:** Salt okunur doküman/kod/test incelemesi. Bu görevde uygulama kodu, veri veya önceki sözleşme değişmedi.  
**Durum sözlüğü:** “Kanıtlı” ilgili test/kod parçasının bulunduğu sınırda geçerlidir. “Kısmi” veri/ön koşul bulunup yaşam döngüsünün tamamı bulunmadığı anlamına gelir. “Hedef” mevcut iş belgelerinde belirlenmiş ama uygulanmamıştır. “Karar bekliyor” mevcut kaynaklar çatışıyor veya iş kuralı henüz seçilmemiştir.

## 1. Kapsam doğrulaması

Başlangıç–sonuç zincirini tanımlı saymak için başlangıç olayı, aktör/ekran, durum ve kayıt geçişleri, geçiş kuralları, yan etkiler ve test kabulü aranmıştır. Başlık veya model tek başına yeterli sayılmamıştır.

| İş zinciri | Sonuç | Doğrulama özeti |
|---|---|---|
| Getmaks marka yönetimi ve ticari politikalar | **Kısmi / çekirdek kanıtlı** | Brand/Admin, kullanıcı/rol/izin/ayar, commercial plan/charge/entitlement ve audit ekran/aksiyonları var. Marka bazında tam iş politikası kataloğu ve finansal gözetimden kapanışa giden uçtan uca raporlama yok. |
| Ofis kuruluşu, ilişki türü ve broker ataması | **İki kuruluş yolu kanıtlı; ilişki anlamı kısmi** | Admin doğrudan kuruluş ve Broker franchise-ofis başvurusu `Office.creation_source` üzerinden ayrılıyor; atama ve approval testleri var. Broker başvurusu ayrı Application aggregate değildir. Franchise/katılım ilişkisinin hukuki ve ücret anlamı tam sabit değil. |
| Broker kimliği, davet, aktivasyon ve ofis üyeliği | **Kısmi** | Broker User/Professional/BrandMembership/OfficeMembership ve davet rotası mevcut; atama tarihçeli. Genel broker aday başvurusu, davet iptal/süre sonu operasyonu ve teslim edilen gerçek e-posta doğrulaması bu incelemede kanıtlanmadı. |
| Ticari sözleşme, ücret kalemleri ve ödeme koşulları | **Kısmi** | Agreement/plan/charge/hak ve policy snapshot/usage accrual var. Taraf ve ücret alanlarının kaydı mevcut; hangi hizmet/işlem olayında kimin borçlu olduğu, fatura/cari/vade/tahsilat lifecycle'ı yok. |
| Danışman katılımı ve Ofis üyeliği | **Çekirdek yaşam döngüsü kanıtlı** | Admin/Broker onboarding, aktif plan/model/üyelik, readiness ve aktivasyon; askı/sonlandırma/transfer için kod/test var. Aday başvuru ve gerçek mail teslimi ayrı doğrulanmamış. |
| MAXIMUM/ALFA çalışma kuralları | **Politika kısmen kanıtlı; ürün kararı çelişkili** | `WorkModelPolicy`, middleware ve test MAXIMUM Data Pool erişimi / ALFA 403'ü doğruluyor; model snapshot ve revenue policy var. Üst iş haritasındaki ALFA ortak havuz erişimi ifadesi ADR/kod ile çelişiyor. Ekip çalışmasının kapsamı tam tanımlı değil. |
| Müşteri, Portföy ve İlan | **Müşteri akışı kanıtlı; Portföy ve taslak İlan kısmi** | Customer/Request/Service testleri, Property→Portfolio→Listing DRAFT akışı ve listing guard testi var. Public Marketplace yayını, müşteri lead'i, eşleştirme ve ilan durum yönetimi uçtan uca yok. |
| Müşteri talebi ve gayrimenkul işlem dosyası | **Talep/Hizmet akışı kanıtlı; gayrimenkul işlem dosyası yok** | RequestFile ve ServiceFile ayrı yaşam döngüleridir; teklif kabulü/hizmet dosyası/Property akışı var. Appointment, Showing, müzakere teklifi ve Transaction kayıtları/rotaları/testleri yok. `ServiceOffer` müşteri hizmet paketinin teklifidir, mülk işlemi teklifi değildir. |
| İşlemin tamamlanması ve gelir paylaşımı | **Hedef / uygulanmamış** | RevenuePolicy oranları kaydedilir; satış/kiralama Transaction close olayı, ConsultantEarning, revenue share hesabı veya dağıtım kaydı yok. |
| Tahakkuk, fatura, cari hesap ve tahsilat | **Tahakkuk kısmi kanıtlı; sonrası yok** | Kullanım ve office activation bazı koşullarda ChargeAccrual oluşturabilir. Invoice, receivable/current-account, ödeme sağlayıcı teyidi ve tahsilat lifecycle'ı yok. Tahakkuk fatura veya tahsilat değildir. |
| Yetkilendirme, gizlilik, audit ve bildirimler | **Yetki/audit çekirdeği kanıtlı; gizlilik ve bildirim kısmi** | Merkezi permission, role middleware, aktif üyelik/ofis görünürlüğü ve kritik audit testleri var. Kişisel veri minimizasyonu/şifreli alanlar ve duplicate HMAC dokümante edilmiş. İletişim rızası/retention/export, genel notification lifecycle ve gerçek sağlayıcı teslimi uçtan uca test edilmemiş. |

## 2. Kararları kanıttan ayırma

### A. Mevcut kod ve testlerle doğrulananlar

1. Tek GETMAKS Brand, Ofis başına en çok bir aktif Broker ve danışman için aktif OfficeMembership organizasyon kuralı; `CorporateCoreTest`, `BrokerBrandOfficeLifecycleTest`, `ConsultantOfficeTransferTest`.
2. Admin doğrudan Ofis kuruluşu ile Broker franchise-ofis başvurusunun ayrı kaynak olarak saklanması; approval/ret, readiness/aktivasyon ve hata rollback sınırları; `OfficeCommercialLifecycleTest`, `PhaseThreeOnboardingUxTest`.
3. Broker kimlik/üyelik kurulumu ve broker değişiminde geçmiş üyeliğin kapatılıp yenisinin açılması; `BrokerIdentityLifecycleTest`, `BrokerBrandOfficeLifecycleTest`.
4. Danışman onboarding checklist'i, gerçek plan ve model atanması, aktivasyon, transfer, askı/sonlandırma; `PhaseThreeOnboardingUxTest`, `ConsultantIdentityLifecycleTest`, `ConsultantOfficeTransferTest`.
5. Plan, ChargePolicy, PlanEntitlement ve RevenuePolicy ayrımı; aktif broker yetkisi; idempotent UsageEvent ve ChargeAccrual girdisi. Bu kanıt invoice/payment oluştuğunu göstermez; `PhaseThreeGovernanceTest`.
6. Model policy kodu: MAXIMUM Data Havuzu görür/claim eder, ALFA etmez; RevenuePool katılımı MAXIMUM için açık olabilir ve ALFA oranı sıfırdır. ALFA kuralının mevcut implementation'ı kanıtlıdır; ürün sahibi tarafından nihai onaylandığı varsayılmaz.
7. Customer → RequestFile ve owner service → ServiceOffer → ServiceFile → Property akışları; dosya kapsamı, duplicate uyarısı ve snapshot testleri; `PhaseTwo*Test`, owner/request creation tests, `ServiceFileCreatesPropertyTest`.
8. İmzalı ServiceContract ve PropertyNumberReceived ServiceAuthorization olmadan Listing oluşturulamaması; Portfolio oluşturma ve Listing'in DRAFT başlaması; `PortfolioListingFlowTest`. Sözleşme/yetkilendirme kullanıcı workflow'u bu testle kanıtlanmaz.
9. Rol ve scope yalıtımı ile bazı kritik audit/status değişiklikleri; `Unauthorized*Test`, `OperationalFileVisibilityTest`, `SettingsChangesAreAuditedTest`, `RolePermissionChangesAreAuditedTest`.

### B. İş modeli belgelerinde kararlaştırılmış, fakat kodda eksik olanlar

1. Nihai müşterinin lokasyon ve ihtiyaca göre uygun ofise yönlendirilmesi; public intake ve geo-routing yok.
2. Listing'in tek Getmaks Marketplace'te yayınlanması, yayından kaldırılması, lead oluşturması ve Portföy/Property kaynağına bağlanması; `listing.publish` gibi entitlement olası anahtarları gerçek publication behavior değildir.
3. Lead → iletişim → randevu → gösterim → Offer/OfferRevision → Transaction → close yaşam döngüsü; domain/entity/route/test bulunamadı. Listing kodunun olması bu zinciri kanıtlamaz.
4. Transaction kapanışından final müşteri hizmet bedeli faturası, danışman hakediş faturası, cari, tahsilat, iade/düzeltme ve ödeme; `docs/03_FINANCE_RULES.md` hedefi var, Finance modülü yok.
5. Tamamlanan işlemden Consultant/Brand/Office/RevenuePool paylarının işlem anı policy snapshot'ıyla hesaplanması; RevenuePolicy mevcutta yalnız parametre kaydıdır.
6. `ServiceContract` imza ve `ServiceAuthorization` müşteri dış sistem bildirimi/property number girişinin ekrana, action'a, actor'a, durum geçmişine ve audit'e bağlanması; model/enum/Listing guard mevcut, bu lifecycle route/controller'ı doğrulanamadı.
7. Bildirim, audit, belge yönetimi, arama, raporlama ve uçtan uca testler ortak sistem hedefi olarak yazılıdır; bütün domainler için gerçekleşmiş çapraz sistem davranışı değildir.

### C. İşletme tarafından açıkça karara bağlanması gerekenler

| Karar | Mevcut kaynaklardaki fark / eksik | İş sahibinin cevaplaması gereken soru |
|---|---|---|
| ALFA Data Havuzu | Önceki üst iş haritası kurallı erişim olabileceğini söylüyor; ADR-004, `02_BUSINESS_RULES.md`, `WorkModelPolicy` ve testler erişimi kapatıyor. | ALFA hiç mi erişmez, yoksa hangi ofis/policy/atama koşulunda hangi alan ve aksiyonları kullanabilir? Pool kaydını kim oluşturur, claim ve müşteri paylaşım onayı nasıl olur? |
| Broker franchise ve katılım | Uygulamada Broker'ın başlattığı kuruluş yolu `BrokerFranchise` yönetim modeliyle Office oluşturuyor; `relationship_type` ayrıca `OFFICE_FRANCHISE`, `EXISTING_OFFICE_BROKER`, `BRAND_CREATED_OFFICE` seçebiliyor. | Franchise hukuki/ticari ilişki midir, yoksa yönetim/kuruluş biçiminden ayrı sözleşme türü müdür? Franchise dışı broker katılımı, başvuru ve ret gerekçesi nedir? |
| Ticari ücret tarafları/periyotları | Agreement tarafları polymorphic; plan/charge cycle alanları var ama gerçek borç kalemlerinin payee/payer ve ödeme takvimi tüm kullanım durumları için belirlenmiş değil. | Ofis, Broker, danışman ve Getmaks arasında lisans/katılım/sabit/usage bedelinin her birinde borçlu, alacaklı, tetikleyici tarih, ödeme vadesi, vergi ve gecikme kuralı nedir? Aylık/yıllık hangi sözleşmeye opsiyoneldir? |
| İlan yayını | Listing create `DRAFT`; enumda ACTIVE/PAUSED/CLOSED var, fakat geçiş aksiyonu yok. Dokümanlar Broker publish approval'ını olası kural olarak bırakıyor. | Yayın öncesi imza/yetki/property no dışında hangi belge ve alanlar zorunlu? Kim draft'ı onaylar/yayınlar? Müşteri onayı, expiry, pause/close ve dış portal hatasında davranış nedir? |
| İşlem close ve mali tetikleyici | Transaction modeli ve approval yok; ADR-039 olası Broker close approval'ını gelecek kararı olarak bırakıyor. | Close hangi olay/kanıtla kesinleşir; kim başlatır/onaylar; başarısız/iptal/yeniden açma nasıl yürür? Müşteri hizmet bedeli ve dağıtım için hangi close status tetikleyicidir? |
| Finansal sonuçlar | Finans kuralları Getmaks müşteri faturasını, danışmanın Getmaks'a hakediş faturasını, ayrı tahsilat/dağıtımı hedefliyor; hesaplama ve yasal akış yok. | Ücret matrahı, taraf/payee, vergi/yuvarlama, fatura tarihi/kalemleri, cari mahsup, ödeme teyidi, iade/ters kayıt ve Kazanç Havuzu dönem formülü nedir? |
| Üyelik/Ofis değişiminde açık dosyalar | Broker değişimi dosya taşımaz; danışman transferinde otomatik müşteri/dosya taşıma yok. | Ayrılan Broker/danışmanın müşteri iletişimi, açık ServiceFile/Listing ve bekleyen transaction sorumluluğu kime ve hangi onayla devredilir? |
| Gizlilik ve bildirimler | PII koruma/duplicate kuralları var; iletişim consent, retention ve genel bildirim delivery lifecycle'ı eksik. | Müşteri iletişim izinleri/kanalları, retention/silme talepleri, paylaşım consent'i, bildirim türü/alıcısı ve başarısız teslim retry/escalation kuralı nedir? |

Bu kararlar kodun mevcut davranışına bakılarak otomatik verilmemelidir. Karar verildikten sonra `docs/07_DECISIONS.md` içindeki ilgili ADR ve bağlı iş/finans kuralı güncellenmelidir.

## 3. Kritik kullanıcı yolculukları kabul matrisi

“Kanıt” hücresindeki testler kaynakta mevcut kabul testleridir; bu görev sırasında çalıştırılmamışlardır. Tarayıcı testi sütununda otomatik UI testi yoksa açıkça belirtilmiştir. Her yeni satır önerisi önce ürün kararı ve faz kapısından geçmelidir.

| Başlangıç | Aktör / ekran / eylem | Ön koşullar | Kayıtlar ve beklenen sonraki durum | Etkilenen modüller; yetki/gizlilik | Başarısızlık davranışı | Otomatik / tarayıcı kanıtı |
|---|---|---|---|---|---|---|
| Brand ve registry etkin | Brand Admin `/admin/settings`, `/admin/users`, `/admin/roles`; politika/rol/User değiştirir | Whitelist alanı, mevcut rol izni, son admin kilidi | SystemSetting/Brand/role override/User güncellenir; audit eklenir; User durumu membership/professional değişimine dönüşmez | Brand → Admin/auth; Backend Gate/registry; hassas ayarlar read-only allowlist | Yetki/validation/son-admin ihlali reddedilir; kısmi yazım yok | `BrandAdminCanManageRolePermissionsTest`, `SettingsChangesAreAuditedTest`, `LastBrandAdminCannotBeSuspendedTest`; Blade HTTP feature tests, gerçek browser suite yok |
| Yeni doğrudan Ofis yok | Brand Admin `/admin/offices/create`; Ofis wizard'ını kaydeder | Marka; temel Ofis alanları; kuruluş modeli; ticari plan/şart; broker yolu seçimine göre broker bilgisi | Office `DRAFT → SETUP`, `BRAND_ADMIN_DIRECT`; seçilen broker membership; draft CommercialAgreement ve pending Subscription | Brand → Office → Broker → commercial; admin marka scope, request kaynak alanı dikkate alınmaz | Validation/unique/plan hatasında bütün onboarding transaction rollback | `OfficeCommercialLifecycleTest`, `PhaseThreeOnboardingUxTest`, `NewOfficeCodeGeneratedAutomaticallyTest`; browser wizard testi bu belge taramasında bulunmadı |
| Broker aktif, marka üyeliği mevcut | Broker `/broker/offices/create`; franchise-ofis başvurusu gönderir | Broker active; active brand membership; zorunlu Office/company/tax/address/plan/relationship/billing inputları | `Office` `BROKER_APPLICATION`, `BrokerFranchise`, başlangıç `SETUP`; admin submit ile `PENDING_APPROVAL` | Broker → Office application-as-Office → admin queue; broker yalnız kendi kimliğiyle başvurur | Pasif Broker/üyelik/validation reddedilir; kaynağı request ile değiştiremez | `OfficeCommercialLifecycleTest` ve Broker OfficeController/FormRequest; browser testi yok |
| Broker application `PENDING_APPROVAL` | Brand Admin `/admin/offices/{office}` approval/ret | Kaynak `BROKER_APPLICATION`; commercial plan ataması; approval/readiness; uyumlu subscription | Onay transaction'ı agreement/subscription/Office'i aktive eder; ret `SETUP`'a döndürür | Approval → commercial → broker panel/operasyon; admin yetkisi | Hata halinde subscription/agreement/status rollback; terminated veya yanlış kaynak reddedilir | `OfficeCommercialLifecycleTest` approval/rollback senaryoları; browser testi yok |
| Broker adayı davet edilmemiş | Brand Admin `/admin/brokers/create` veya Office broker atama; oluştur/ata/değiştir | Unique email, telefon, aktif marka ve hedef Ofis; dolu slotta açık replacement onayı | User/Professional/BrandMembership/OfficeMembership; eski broker satırı kapanır, yeni active satır/davet oluşur | Identity → Office/authority → broker panel; brand admin scope, tek active broker constraint | Onaysız dolu ofis değişmez; duplicate email veya constraint hatasında transaction rollback | `BrokerIdentityLifecycleTest`, `BrokerBrandOfficeLifecycleTest`, `OfficeCommercialLifecycleTest`; e-mail teslim/browser inbox testi yok |
| Danışman yok veya onboarding'de | Admin/Broker consultant wizard veya davet; danışman `/consultant/onboarding` tamamlar | Aktif marka/ofis, unique kimlik/iletişim, model, mevcut plan, gerekli profil/readiness | User/Professional/membership/WorkModel/Subscription kurulup `ONBOARDING`; readiness sonrası `ACTIVE` | Office team → data access → customer ops; Broker kendi ofisi/authority, consultant yalnız kendi kayıtları | Eksik checklist aktivasyonu engeller; terminated/duplicate/plan eksikliği rollback/ret | `PhaseThreeOnboardingUxTest`, `ConsultantIdentityLifecycleTest`, `ApprovalSemanticsTest`; otomatik browser suite yok |
| Danışman aktif üyelikli | Brand Admin `/admin/consultants/{id}/transfer`; transferi uygular | Aynı brand; hedef Office ACTIVE + aktif Broker; hedef plan/model; gerekçe ve geçerli tarih | Eski membership/model tarihçeli kapanır; yeni membership/model/plan açılır; eski dosyalar otomatik taşınmaz | Old/new Office, work model, commercial; admin yetkisi, Broker admin transfer endpointine erişemez | Aynı/başka brand/aktif broker olmayan/terminated/invalid date reddedilir; transaction rollback | `ConsultantOfficeTransferTest`, özellikle active broker ve broker replacement senaryoları; browser testi yok |
| Danışman için aktif model mevcut | Admin/Broker work-model change ekranı; modeli değiştirir/onaylar | Authority, aktif membership, tarih ve gerekiyorsa request approval | Eski WorkModel satırı kapanır, yenisi etkinleşir; yeni Request/Service snapshot yeni modeli alır | DataPool, CRM, future revenue policy; ALFA DataPool guard ve office scope | Yetkisiz veya ALFA pool action 403; geçmiş dosya snapshot'ı değişmez | Work model/governance testleri; `AlfaConsultantCannotAccessDataPoolTest`, `MaximumConsultantSeesOwnOfficePoolTest`; browser suite yok |
| Customer yok veya tekrar kullanılabilir | Brand Admin/Broker/Consultant `/operations/customers` veya dosya niyet akışı | Aktörün operational office scope; contact data doğrulaması; duplicate uyarısı | Customer + CustomerActivity; talep ise RequestFile, owner flow ise talep/hizmet offer zinciri | Customer/Request/Service; `OperationalAssignment`, visibility scope; duplicate merge yok; PII koruma | Cross-office id/body reddedilir; duplicate uyarı üretir ama otomatik merge yapmaz | Customer/Request creation tests, `OperationalFileVisibilityTest`; browser suite yok |
| PoolRecord AVAILABLE veya müşteri talebi yeni | Broker/Maximum/Admin pool ekranı; kaydet/claim/assign/convert | Office claim policy; MAXIMUM capability; claimant aktif ve aynı ofis; claim limit/expiry koşulları | PoolRecord/PoolClaim `AVAILABLE → CLAIMED → CONVERTED` ya da release/expiry ile geri açılır; dönüşüm RequestFile üretir | DataPool → RequestFile/Consultant; Brand Admin marka scope, Broker ofis scope, ALFA reddedilir | Limit/scope/policy ihlali reddedilir; tek aktif claim ve idempotency korunur | `PhaseTwoDataPoolTest`, broker/MAXIMUM office scope ve ALFA denial tests; browser suite yok |
| Customer ve talep niyeti mevcut | Consultant/Broker/Admin `/operations/request-files`; talebi aç/aktif et/kaybet | BUY/RENT/TAKEOVER yönü; aynı marka/ofis/müşteri; aktif consultant ve work model | TD RequestFile, status history, model snapshot; aktif/kayıp/kapanış geçişi | RequestFile/Customer/Service; `RequestFileVisibility` ve aktör/ofis scope | Başka müşterinin/ofisin dosyası reddedilir; geçersiz terminal geçişi history üretmeden reddedilir | `PhaseTwoRequestFileTest`, `RequestFileShowsOnlyBuyRentTakeoverTest`, broker/consultant scope tests; browser suite yok |
| Owner Service niyeti mevcut | Consultant/Broker/Admin Service flow ekranı; teklif yarat, gönder, kabul et | SELL/LEASE_OUT/TRANSFER_OUT; paket etkin; doğru customer/office; service decision | Customer + RequestFile + ServiceOffer (HT/revision); ACCEPTED ise tek ServiceFile ve Property; başka kararda ServiceFile oluşmaz | Customer → ServiceOffer → ServiceFile → Property; visibility ve same office/brand/customer | Rejected/Offered yalnız başına active ServiceFile oluşturmaz; duplicate active ServiceFile engellenir | `CreateOwnerServiceFlowWith*Test`, `AcceptedServiceOfferCreatesServiceFileTest`, `OfferedServiceOfferDoesNotCreateActiveServiceFileTest`, `ServiceFileCreatesPropertyTest`; browser suite yok |
| ServiceFile ve Property mevcut | Consultant/customer kontrat ve yetkilendirme kaydını tamamlar — mevcut UI akışı doğrulanmadı | ServiceContract taslak/gönder/imza; customer external authorization; property number alınması; actor/consent akışı kararı | ServiceContract `DRAFT/SENT/VIEWED/SIGNED` ve ServiceAuthorization `PENDING/CUSTOMER_REPORTED/PROPERTY_NUMBER_RECEIVED`; status/audit/history beklenir | ServiceFile → Property/Portfolio/Listing; owner, consultant, office scope + PII/authorization referansı | Eksik/iptal/süresi dolan belge Listing'i bloklar; invalid transition ve başka dosya scope'u reddedilir | `ServiceContractAuthorizationDomainTest` yalnız ilişki/model; `PortfolioListingFlowTest` Listing guard. Lifecycle UI/transition testi yok; browser testi yok |
| ServiceFile/Property var | Yetkili consultant/Broker `/operations/portfolios`; Portfolio kurar | OWNER_SERVICE; Property; doğru dosya scope; duplicate active Portfolio yok | Portfolio `ACTIVE`, ServiceFile/Property/Customer/Office snapshot bağlantıları | Service → Property → Portfolio; PortfolioVisibility office/consultant scope | Property yok/duplicate ise kayıt oluşmaz | `PortfolioListingFlowTest`; browser suite yok |
| Portfolio active | Yetkili professional `/operations/listings`; taslak listing kurar | Signed active contract; active authorization status `PROPERTY_NUMBER_RECEIVED`; numara dolu; duplicate active Listing yok | Listing `DRAFT`, price/title/currency ve kaynak ilişkileri | Portfolio/Property/ServiceFile; ListingVisibility; sonra publication yok | Guard/validation hatasında Listing yazılmaz | `PortfolioListingFlowTest` eksik contract/auth reddi ve başarılı DRAFT. Publish/pause/close/browser kabul testi yok |
| Listing DRAFT | Henüz uygulanmamış publish actor/screen/action | Ürün kararında belirlenecek imza, mülk numarası, müşteri onayı, kalite ve authority koşulları | Hedef MarketplacePublication ve Listing `ACTIVE`; success/failure/retry ve unpublish tarihçesi tanımlanmalı | Marketplace publication/lead/customer; data consent, field allowlist ve office scope gerekli | External portal timeout/retention/conflict davranışı karara ve retry policy'ye bağlanmalı | Mevcut publish action/route/test/browser kanıtı yok; önce karar, sonra feature+provider-fake test ve browser kabulü |
| Marketplace lead/aday müşteri | Hedef Broker/Consultant lead iş kuyruğu; iletişim/görüşme başlat | Listing aktif; lead duplicate/contact consent; claim/assignment ve response SLA kararı | MarketplaceLead veya kararlaştırılan mevcut Customer/RequestFile kaynağı; sahip/atama ve next status tanımı gerekli | Listing → Customer/Appointment; PII minimization, customer consent, same-office visibility | Duplicate/invalid/withdrawn listing ve iletişim opt-out davranışı tanımlanmalı | Lead/appointment routes/models/tests/browser yok |
| Aktif lead/listing ve görüşme | Hedef Consultant işlem dosyası; randevu/gösterim/offer/karşı teklif | Taraf doğrulama, representation/consent, listing/current status, authority | Appointment/Showing/OfferRevision/Transaction ve tarihçe; başlangıç ve transition durumları karara bağlı | Listing/customer/office/consultant → transaction; parties access separation | Offer withdrawal/revision, no-show, cancellation, conflicting close ve race condition için atomik ret/rollback | Bu domain için route/model/migration/test/browser kanıtı yok |
| Transaction close öncesi | Hedef Broker/Consultant transaction ekranı; tamamla/iptal | Close proof, gereken broker approval (karar bekliyor), fee policy valid-from | Transaction `COMPLETED` veya ret/iptal; close-time fee/revenue snapshot ve audit beklenir | Transaction → Finance/RevenuePool; yalnız yetkili participant ve audit trail | Tekrarlı close idempotent; başarısız/iptal işlemi invoice/payout üretmez; reversal kuralı gerekli | Transaction domain ve close test/browser yok |
| Aktif CommercialAgreement/plan veya billing start geldi | Sistem/Brand Admin commercial ekranı; usage/fixed accrual üretir | Effective agreement, plan charge policy, entitlement/quota, currency, idempotency key | UsageEvent ve policy snapshot'lı ChargeAccrual `PENDING/WAIVED`; subscription/billing state ayrı kalır | Commercial → subscription/finance preparation; broker authority sınırı; fiyat ve para erişimi role scope | Duplicate idempotent; inactive policy/limit/invalid amount reddi; invoice/payment'e otomatik sıçramaz | `PhaseThreeGovernanceTest`, `OfficeCommercialLifecycleTest`; invoice yokluğunu ispatlayan domain testi modeli henüz olmadığından eklenmeli |
| Transaction completed ve fee policy selected | Hedef Finance actor; customer invoice, receivable ve collection | Onaylı fee calculation, tax, recipient, due date, legal invoice identity; provider success confirmation | Invoice/Receivable → Payment/Collected veya Failed/Overdue; consultant earning ve pool contribution ayrı kayıtlar | Getmaks/customer; consultant/office/brand share; finance permissions, immutable snapshot | Provider confirmation yoksa paid değil; cancel/refund correction entry ile; repeated callback idempotent | Finance models/routes/actions/tests/browser yok |
| Herhangi bir kritik durum/permission değişikliği | İlgili yetkili actor; domain action/UI | Actor authenticated/active; scope; reason gerekli olduğu aksiyonda; PII minimization | AuditLog + StatusHistory; ilgili domain event commit sonrası | Merkezi RolePermissionRegistry + active user + role + resource visibility; audit view permission-scoped | Unauthorized 403/404; rollback durumunda success audit/event kalmamalı | Audit/authorization feature tests mevcut; tüm domain actions için coverage matrix yok; browser tests paketi yok |

## 4. Kabul testi öncelikleri

Bu sıralama mevcut test kanıtını tekrar çalıştırma talimatı değil; açık kabul kapsamının nasıl kapatılacağını belirtir.

### P0 — Mevcut çekirdek ve karar uyumu

1. **Handoff/faz kapısı mutabakatı:** 09 handoff'un 03C.4 sonraki kapsamı ile mevcut transfer/ofis ekranı/test kodunu karşılaştır; mevcut testleri ve ekranları gerçek acceptance criteria'ya bağla, eksik varsa yalnız o gap'i yaz.
2. **Office lifecycle:** Admin direct ve broker franchise application ayrımı, resource tam scope, approval/ret, eksik plan/readiness, terminal state ve transaction rollback regresyonları.
3. **Broker/consultant kimlik ve üyelik:** Invitation acceptance, active memberships, replacement/transfer, unauthorized/cross-office ve danışman/dosya otomatik taşınmaması.
4. **Ticari ayrımlar:** Agreement relationship vs work model vs plan/charge/payment period; usage idempotency, quota ve snapshot; activation/accrual'ın invoice/payment olmadığına yönelik explicit assertion.
5. **MAXIMUM/ALFA karar kapısı:** Ürün sahibi ALFA havuz seçimini ADR'ye işler; sonra aynı policy kararını middleware/action/menu ve pozitif/negatif tests ile kanıtla.

### P1 — Property/Listing öncesi zorunlu lifecycle

6. ServiceContract ve ServiceAuthorization için create/send/customer-report/sign/expire/cancel transitions, timestamp ve audit; actor/office/ServiceFile scope.
7. Listing draft guard: tüm zorunlu contract/auth/property-number kombinasyonlarının olumlu/olumsuz matrisi, concurrent duplicate, fiyat/currency validation, approval kararı.
8. Marketplace publish/unpublish: yalnız P1 sonrası işletme yayım kararı; external adapter mock/failure/retry, duplicate idempotency, public field allowlist ve consent; gerçek provider'a bağlı olmayan feature testleri.

### P2 — Transaction ve Finance fazları

9. Lead → appointment/showing → offer revision → transaction close/withdraw/cancel, visibility, optimistic/concurrency control ve audit.
10. Close-time fee/revenue snapshot → invoice/receivable → provider confirmation/collection → earning/pool distribution; duplicate event, rounding/tax, refund/reversal ve no-double-pay.

### P3 — Ortak sistem ve kabul

11. Gizlilik: role/office data matrix, consent, encrypted/HMAC fields, export/retention decision, log redaction.
12. Bildirim: event recipient/channel, queue failure/retry, dedupe, audit ve notification preferences.
13. Browser acceptance: auth context, wizard validation, role panel isolation, listing guard ve son kullanıcı journey'leri. Repoda package scripts yalnız `build/dev`; Playwright/Dusk/browser runner konfigürasyonu bulunmadı. Uygun browser runner/ortam varsa eklenecek test önerisi ayrı kararlaştırılmalı; mevcut feature tests browser kanıtı sayılmaz.

## 5. İlk uygulama aşaması ve tamamlanma ölçütü

### Ön kapı: mevcut faz ve kararların kilitlenmesi

`docs/09_CODEX_HANDOFF.md` 03C.4'ü sıradaki önerilen patch ve ardından Faz 4'ü ayrı talimata bağlı sonraki adım olarak gösteriyor. Buna karşılık `ConsultantOfficeTransferTest`, transfer action'ı ve ofis merkezli görünüm kanıtı mevcut. Bu nedenle doğrudan yeni Faz 4 koduna geçmek yerine önce 03C.4 için tamamlanma/ürün sahibi kabul durumu doğrulanmalı, handoff test/ekran kanıtıyla güncellenmeli ve ALFA DataPool kararı kaydedilmelidir. Bu görev bu kapıyı kapatmış veya 03C.4'ü kabul etmiş değildir.

### Önerilen ilk yeni teknik dilim: Service Contract + Authorization lifecycle

Faz kapısı ve ayrı ürün talimatı verildikten sonra ilk dar uygulama dilimi, mevcut `ServiceContract`, `ServiceAuthorization`, `ServiceFile` ve Listing guard'ını kullanarak mülk sahibi yetkilendirme adımlarını tamamlamalıdır. Yeni paralel sözleşme/property/approval modeli üretmemelidir.

**Kapsam:**

- ServiceFile'den sözleşme taslağı oluşturma, gönderildi/görüldü/imzalandı ve iptal/expired lifecycle'ı.
- Harici yetkilendirme müşteriden bildirildi ve taşınmaz numarası alındı durumlarını ayrı kayıt alanlarıyla yürütme; e-Devlet/e-imza entegrasyonu iddia etmeden mevcut harici reference akışını işletme.
- Consultant/Broker/Admin için karar verilmiş office/file visibility, hangi aktörün hangi alanı gireceği, gerekçe, status history ve audit.
- Mevcut Listing action guard'ının yeni lifecycle ile tam uyumu; invalid/expired/cancelled auth ile Listing oluşmaması.
- Liste/form/detail UI ve HTTP feature kabulü; browser runner sağlanırsa aynı yolculuk için görsel/etkileşim kabulü.

**Tamamlanma ölçütleri:**

1. Her durumun başlangıç/son koşulu, actor, zorunlu veri ve geri dönüşü ADR/iş kuralıyla onaylanmış.
2. Aynı ServiceFile için active contract/authorization kısıtları ve transaction rollback concurrency dahil test edilmiş.
3. Başka brand/office/file kullanıcısı kayıt okuyamıyor/yazamıyor; PII ve external reference role'a uygun saklanıyor/gösteriliyor.
4. State history/audit actor ve old/new status içeriyor; external event yokken harici onay/başarı uydurulmuyor.
5. Listing yalnız SIGNED contract + aktif ve geçerli authorization + property number guard'ından sonra DRAFT olarak açılıyor; publish/Marketplace bu dilimin dışında.
6. İlgili PHPUnit feature tests geçiyor; blade/view ve permission/menu kontrolleri tamam; güncel handoff açık kalan kararı/fazı doğru gösteriyor ve ürün sahibi kabulü alınmış.

## 6. Kaynak ve kapsam notu

Bu belge, 10 ve 11 numaralı belgelerin her iş kuralını yeniden yazmaz; yalnız kapsam testini, kanıt sınıflamasını, açık kararları ve kabul matrisini ekler. İş kararı karara bağlanırsa ADR ve ilgili ana iş/finans kuralı güncellenmeli; test adı/kanıtı gerçek kodla eşlenmeli. Test veya browser koşulmadan başarı sonucu iddia edilmemelidir.


## 03C.4 Transfer Acceptance Evidence Update (2026-10-17)

**Decision: KISMİ; product-owner acceptance is not declared.** The implementation reuses OfficeMembership, ProfessionalWorkModel, Subscription, existing activation logic, Laravel Scheduler, and current access scopes. No parallel lifecycle table or migration was introduced.

| Acceptance area | Evidence | Result | Remaining proof |
|---|---|---|---|
| Immediate vs future effective date | `TransferConsultantToOffice`; target rows pending/proposed/pending for a future date, source membership/model/subscription stay active; 03C.4 future transfer test | KABUL (automated feature scope) | Browser confirmation |
| Due date transition and idempotency | `ApplyScheduledConsultantTransfers`; source rows end at effective date, target rows activate, second command run changes nothing | KABUL (automated feature scope) | Host scheduler uptime and true cross-process concurrency |
| Rollback after mid-flow failure | Controlled subscription creation failure after old membership/model updates begin; database counts and old rows remain unchanged, target rows and success/close audit absent; `ConsultantOfficeTransferTest::test_transfer_failure_rolls_back_all_changes_and_returns_a_form_error` | KABUL (transaction/HTTP feature scope) | None identified in this test scope |
| Visibility before and after due date | Broker consultant and customer/request/service/listing endpoints tested before and after; new office can see the consultant only after activation, while untransferred source-office files remain inaccessible to the new Broker; consultant and Brand Admin scopes remain | KABUL (automated HTTP feature scope) | Browser confirmation |
| Broker replacement and office presentation | Broker replacement leaves consultant membership and customer/request/service/listing office and consultant bindings unchanged; list MAXIMUM/ALFA filter and office detail active membership rendering are covered | KABUL (automated feature scope) | Browser confirmation |
| Failure/retry and cancellation | Invalid destination Broker leaves current rows active, target rows pending, failure audit written; restored precondition permits retry. Cancellation terminalizes target rows and preserves current access | KABUL (automated feature scope) | Operational alerting for repeated failures is not implemented/verified |
| Scheduler execution | `routes/console.php` registers every-minute command with `withoutOverlapping(10)->onOneServer()`; `php artisan schedule:list` lists it | KISMİ | Confirm Windows/Laragon scheduler is continuously invoking `schedule:run` |

Focused result: `php artisan test --compact tests/Feature/ConsultantOfficeTransferTest.php` — 11 passed, 167 assertions. Full result: `php artisan test --compact` — 182 passed, 1,095 assertions. `vendor/bin/pint --dirty --format agent` passed. These are automated HTTP/feature tests; no browser surface or real scheduled host process was available to verify in this run. Therefore the phase remains KISMİ pending the stated operational/browser evidence and product-owner acceptance.

## Ofis belge ve sözleşme kanıtı uygulama durumu (2026-10-19)

**Durum: Uygulama ve feature kanıtı mevcut; yerel kalıcı veritabanı/browser kabulü yapılmadı.** Bu ek, 03C.4 transfer fazının kabul durumunu değiştirmez.

| Koşul | Kod / test kanıtı | Sonuç | Kalan doğrulama |
|---|---|---|---|
| Marka zorunlu belge listesi açıkça yapılandırılmadan ofis hazır olamaz | `OfficeDocumentRequirementSet`, `ConfigureOfficeDocumentRequirements`, `OfficeSetupReadiness`; `OfficeVerificationActivationTest::test_unconfigured_documents_and_missing_contract_proof_block_ready_and_activation_without_closing_active_offices` | KABUL (feature) | Yerel DB migration ve kullanıcı tarayıcısı |
| Özel belge yükleme, yükleyen/tarih/sürüm/hash ve inceleme durumu kalıcıdır | `UploadOfficeDocument`, `BeginOfficeDocumentReview`, `ReviewOfficeDocument`; `test_brand_admin_can_complete_document_contract_evidence_and_activation_chain` | KABUL (feature) | Özel disk izinleri ve tarayıcı dosya yüklemesi |
| Yeni belge sürümü eski onayı devralmaz; ret/düzeltme gerekçesi zorunludur | aynı feature testi ve `test_authorization_reasons_and_signature_version_binding_are_enforced` | KABUL (feature) | Tarayıcı etkileşimi |
| CommercialAgreement ACTIVE imza kanıtı değildir; sözleşme metni ve şart snapshot'ı değişmez sürümlüdür | `OfficeContractVersion`, `RecordOfficeContractSignature`, `ApplyOfficeContractSignatureVerification`; `test_contract_text_and_terms_snapshot_are_immutable_after_creation` | KABUL (feature) | İşletme tarafından gerçek sözleşme metni/kanıt kabulü |
| En güncel sözleşme sürümünün metin/koşul snapshot'ı güncel ilişki, plan ve etkin ücret koşullarıyla eşleşmeli; inceleme, gerekli taraf kanıtları ve tarihler tamam olmalıdır | `OfficeContractTermsSnapshot`, `OfficeSetupReadiness`, `ActivateEffectiveOfficeContract`; tam zincir testi, değişen ticari koşul ve yeni sürümde eski kanıtın geçerli sayılmadığı assertion | KABUL (feature) | İşletme tarafından kanıt kabulü |
| READY/ACTIVE POST istekleri merkezi koşulu tekrar kontrol eder | `MarkOfficeReady`, `ActivateOffice`; tam zincir ve doğrudan aktivasyon engeli testi | KABUL (feature) | Yerel DB migration sonrası HTTP smoke |
| Önceden ACTIVE ofisler otomatik askıya alınmaz; eksikleri yönetim ekranında görünür | `OfficeController@index/show`, ofis liste/detay görünümleri; aktif fixture testi | KISMİ | Mevcut yerel kayıtların salt okunur envanteri ve işletme bazında geçiş kararı |

Bu işin son odaklı test paketi: `OfficeVerificationActivationTest`, `OfficeCommercialLifecycleTest`, `BrokerBrandOfficeLifecycleTest`, `PhaseThreeOnboardingUxTest` — 35 test / 332 assertion. Testler in-memory test DB'sini kullanır. Yerel uygulama DB'sine migration uygulanmadı; bu nedenle tarayıcıdan gerçek kayıtlarla uçtan uca kabul yapılmış sayılmaz.

Final full test suite: 187 passed / 1,174 assertions. `vendor/bin/pint --dirty --format agent` and `npm run build` passed (optional Fontaine package warning only).


# GETMAKS360 V2 — Proje Bağlamı

## Kimlik ve amaç

- Proje: **Getmaks360 V2**
- Ana marka: **Getmaks**
- Proje kökü: `C:\laragon\www\GETMAKS360_V2`
- Legacy referans: `C:\laragon\www\GETMAKS360`
- Amaç: GETMAKS360'ın iş modelini temiz bir Laravel çekirdeğinde, faz kapılarıyla ve kalıcı karar hafızasıyla yeniden kurmak.

Legacy proje silinmez, yeniden adlandırılmaz, toplu taşınmaz ve kaynak kodu yeni projeye otomatik kopyalanmaz. Her yeniden kullanım kararı `08_LEGACY_MAPPING.md` içinde ayrı kaydedilir.

## MVP sınırı

MVP hiyerarşisi:

`GETMAKS → tek ofis → tek broker → danışmanlar`

`Office.office_type` üzerindeki **MAXIMUM** ve **ALFA**, ofisin kalıcı işletme türleridir. Bu sınıflandırma; ofis yönetim modeli, kuruluş kaynağı ve broker ticari ilişkisiyle aynı kavram değildir. Tarihsel `ProfessionalWorkModel.MAXIMUM/ALFA` kayıtları danışman çalışma/capability geçmişi olarak korunur; ofis türüne dönüştürülmez veya ondan türetilmez. MVP tek pazaryeriyle çalışır. Public tanıtım/landing sayfaları, çoklu ofis ve çoklu pazaryeri MVP dışındadır.

## Ürün omurgası

`Brand → Office → Professional → Customer → Request → Service → Portfolio → Listing → Marketplace → Transaction → Finance`

Ana operasyon zinciri:

`Müşteri → Talep Dosyası → Hizmet Modeli → Hizmet Dosyası → Portföy → İlan → Tek Pazaryeri → Lead/Randevu/Gösterim → Teklif → İşlem → Finans`

Ana dosyalar Talep Dosyası, Hizmet Dosyası ve İşlem'dir. Hizmet modelleri Uzaktan Destek, Birebir Destek ve Uzman Hizmet'tir.

## Kalıcı çalışma disiplini

Her yeni çalışma oturumunda en az şu belgeler okunur:

1. `00_PROJECT_CONTEXT.md`
2. `01_ARCHITECTURE.md`
3. `02_BUSINESS_RULES.md`
4. `03_FINANCE_RULES.md`
5. `05_PHASE_PLAN.md`
6. `07_DECISIONS.md`
7. `09_CODEX_HANDOFF.md`

Bir faz tamamlanmadan sonraki faza geçilmez. Test başarısı tek başına ürün sahibinin faz onayı sayılmaz.

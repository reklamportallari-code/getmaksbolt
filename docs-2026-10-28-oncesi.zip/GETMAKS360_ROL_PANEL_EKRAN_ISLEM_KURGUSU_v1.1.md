# GETMAKS360 — Rol, Panel, Ekran ve İşlem Kurgusu

**Sürüm:** 1.1 — Bağlayıcı ürün kurgusu ve panel yaşam döngüsü  
**Proje:** `C:\laragon\www\GETMAKS360_V2`  
**Amaç:** Kullanıcı rolü, panel/çalışma alanı, panel içindeki ekranlar ve işlem sonuçlarının birbirinden ayrılmasını ve doğru ilişkilendirilmesini sağlamak.  
**Bu belgenin niteliği:** İş/UX karar kaynağıdır. Laravel kodu veya veri modeli değildir; uygulamada mevcut kayıtlar ve ilişkiler kullanılarak hayata geçirilir.

---

## 1. Temel tanım: Dört ayrı katmanı birbirine karıştırma

GETMAKS360'ta “üye”, “müşteri rolü”, “profesyonel unvanı”, “panel” ve “ofis ilişkisi” aynı şey değildir. Bunları tek bir `User.role` değeriyle anlatmak panel hatalarının temel nedenidir.

### 1.1 Hesap / temel üyelik

Her hesap **Standart Üye** temel alanıyla başlar ve bu alan kalıcı olarak korunur. “Standart Üye” yalnızca veritabanında duran bir rol etiketi veya başlık rozeti değildir. Kullanıcının kullanabileceği tam bir **Nihai Müşteri Paneli** ve buna ait ekranlar vardır.

### 1.2 İşlem dosyasındaki müşteri rolü

Alıcı, satıcı, kiracı adayı, kiraya veren/mülk sahibi, devreden ve devir alan gibi roller genel hesap rolü değildir. Yalnız ilgili Talep Dosyası, Hizmet Dosyası, ilan etkileşimi, gösterim veya İşlem Dosyası kapsamında atanır. Rol değişti diye ana panel veya kalıcı hesap tipi değiştirilmez.

### 1.3 Profesyonel unvan / çalışma ilişkisi

- Gayrimenkul Danışmanı, onaylı ve gerekli aktivasyon kapıları tamamlanmış profesyonelin mesleki çalışma alanıdır.
- Profesyonel başvuru yapmak başvuruyu kabul edilmiş veya profesyoneli aktif yapmaz.
- Broker başvurusu/isteği yapmak tek başına Broker unvanı veya Ofis Paneli vermez.
- Kişi, MAXIMUM franchise ofisini kurma/aktif etme koşulları tamamlandığında veya GETMAKS tarafından açılmış ALFA şubesine açıkça Broker/şube yöneticisi olarak atandığında Broker olur.
- Bir ofise danışman olarak `OfficeMembership` üzerinden katılmak Broker yapmaz.

### 1.4 Panel / çalışma alanı

Panel, kişinin belirli işlerini yapabildiği ayrı çalışma alanıdır. Panel kazanmak temel üyeliği veya diğer geçerli panelleri silmez; **yeni çalışma alanı ekler**. Her panelin kendi menüsü, ekranları, butonları, kayıt kapsamı ve izinleri vardır. Aynı kişi panel değiştirince yeni kullanıcı hesabı veya kopya müşteri/dosya oluşturulmaz.

### 1.5 Nihai müşteri: Bireysel veya kurumsal taraf

Nihai müşteri yalnız gerçek kişi olmak zorunda değildir. Hizmetin veya işlemin tarafı **bireysel kişi** ya da **kurumsal/tüzel kişi** olabilir.

- Bireysel müşteri: gerçek kişi hesabı, kendi adına açtığı dosyalar ve dosya kapsamındaki rolleri.
- Kurumsal müşteri: şirket/kurum gibi ayrı bir hukuki taraf kaydı, bu kurum adına işlem yapma yetkisi verilmiş kullanıcı/temsilci ilişkisi ve kuruma ait dosyalar.
- Gerçek kişi kullanıcı ile temsil ettiği şirket aynı kimlik/kayıt olarak birleştirilmez. Yetkili temsilci oturum açtığında “Kişisel alanım” ile yetkili olduğu “Kurumsal alan” arasında bağlama göre geçiş yapabilir. Kurumsal bağlam yoksa veya kullanıcı temsilci olarak yetkilendirilmemişse kurumsal kayıt görünmez.
- Talep, Hizmet ve İşlem Dosyasında “taraf” bilgisi bireysel/kurumsal tipini ve hukuki tarafı gösterir. Kullanıcı bu dosyada bir şirketi temsil ediyorsa temsil yetkisi ve gerekli imza yetkilisi bilgisi ayrı kayıttır; kişinin kendi adına işlem yapmasıyla karıştırılmaz.
- Mevcut projede kurumsal taraf ve temsil yetkisi için uygun model varsa onu kullan. Yoksa aynı kişiyi şirket hesabı gibi göstermek veya yalnızca metin alanıyla taklit etmek yerine bu senaryoyu destekleyen en küçük tutarlı ilişkiyi mevcut mimariye ekle. Kurumsal temsilciye yalnız yetkili olduğu kurum/dosyalar gösterilir.

---

## 1A. Sistemin değişmez katmanları ve ilişki yönü

Aşağıdaki kavramlar birbirinin yerine kullanılamaz:

1. **Hesap/üyelik:** Her zaman bulunan Standart Üye alanı.
2. **Nihai müşteri niteliği:** Bireysel veya kurumsal taraf olarak hizmet alma/işlem yapma bağlamı.
3. **Dosya içi müşteri rolü:** Alıcı, satıcı, kiracı, mülk sahibi/kiraya veren, devreden, devir alan gibi dosyaya bağlı rol.
4. **Profesyonel durum/unvanı:** Başvuru durumu ve aktif Gayrimenkul Danışmanı statüsü.
5. **Broker kapasitesi:** MAXIMUM franchise Broker'ı veya markanın atadığı Broker/ALFA şube yöneticisi.
6. **Ofis operasyon ilişkisi:** Hangi ofisin hangi aktif Broker tarafından hangi tür ilişkiyle yönetildiği.
7. **Bağımsız ek ilişkiler:** Stratejik İş Ortağı, Marka Yönetimi ve Marka Yatırımcısı ilişkileri; kendi şartları/kapsamlarıyla açılır ve kapanır.
8. **Panel:** Yukarıdaki gerçek durum ve ilişkilere göre menü/ekran/aksiyon sunan çalışma alanı.

Panel, tek başına rol değildir; menü görünürlüğü de yetkilendirme değildir. Her butonun gerçek işlem sonucu ve veri kapsamı, ilgili ilişki/izin koşuluna bağlıdır.

---

## 2. Panel bileşimi — bağlayıcı tablo

| Gerçek durum / geçerli ilişki | Erişilebilen paneller | Açılma şartı / sınırı |
|---|---|---|
| Yeni veya mevcut standart üye | **Standart Üye / Nihai Müşteri Paneli** | Her hesapta kalıcıdır. Bireysel veya kurumsal müşteri bağlamı ayrıca belirlenebilir. |
| Danışman başvurusu gönderilmiş / değerlendirmede | **Standart Üye Paneli**; başvuru durumu Standart Üye alanındaki başvuru ekranında | Başvurunun gönderilmesi Danışman Paneli açmaz. |
| Aktif Gayrimenkul Danışmanı | **Standart Üye + Danışman Paneli** | Kabul ve gerekli profesyonel aktivasyon kapıları tamamlanmış olmalıdır. |
| Broker olmak için başvurmuş / koşulları tamamlamamış kişi | Mevcut yetkili panelleri; başvuru ekranı kendi akışında | Başvuru veya niyet, Broker/Ofis Paneli yetkisi değildir. |
| Aktif MAXIMUM franchise Broker'ı | **Standart Üye + Danışman + yetkili MAXIMUM Ofis Paneli** | Broker franchise ofisini kurmuş/aktif etmiş olmalı. Franchise sahibi olma ilişkisi atanmış Broker ilişkisinden ayrı tutulur. |
| Aktif atanmış Broker (GETMAKS tarafından açılmış ALFA şubesinde) | **Standart Üye + Danışman + atanmış ALFA Ofis Paneli** | Açık ve aktif Broker/şube yöneticisi ataması gerekir. Şube sahibi/Franchise Broker gibi etiketlenmez. |
| Kişi ofise yalnız danışman olarak katılmış | **Standart Üye + Danışman Paneli** | `OfficeMembership` tek başına Broker/Ofis Paneli açmaz. |
| Broker ofis görevinden alınmış, atanması/office broker ilişkisi bitmiş; profesyonelliği hâlâ aktif | **Standart Üye + Danışman Paneli** | Eski ofis için Ofis Paneli ve ofis operasyon izinleri derhâl kapanır. Diğer iki panel korunur. |
| Profesyonel statüsü iptal edilmiş | **Standart Üye Paneli** her zaman kalır | Danışman Paneli kaldırılır; Broker/Ofis yetkisi profesyonel statüye bağlı olduğu için kapatılır. Bağımsız geçerli Stratejik İş Ortağı/Marka/Investor ilişkileri kendi şartlarına göre değerlendirilir. |
| Ofis Broker ilişkisi askıda | **Standart Üye + aktif profesyonellik varsa Danışman Paneli** | İlgili ofisin operasyonel Ofis Paneli işlemleri kapalıdır. İlişki yeniden aktif olursa yetkiler yalnız yeni/aktif duruma göre döner. |
| Stratejik İş Ortağı ilişkisi aktif | **Standart Üye + Stratejik İş Ortağı Paneli** | Yalnız atanmış görev ve izinli veri kapsamı. Ayrı aktif danışmanlığı varsa Danışman Paneli de bağımsız olarak bulunabilir. |
| Stratejik İş Ortağı ilişkisi sona ermiş | **Standart Üye** ve diğer bağımsız geçerli paneller | Stratejik İş Ortağı Paneli ve görev erişimi kapanır; müşteri hesabı/dosyaları silinmez. |
| Marka yatırımcısı, geçerli yatırım ve ofis kapsamı var | **Standart Üye + kapsamla sınırlı Yatırımcı Paneli** | Yalnız sözleşmeye bağlı ofisler ve gerçek finansal kayıtlar. |
| Marka yönetimi yetkisi olan kullanıcı | **Standart Üye + Marka Yönetim Paneli** | Açık merkezi marka yetkileri ve kapsam. Bu panel ofis Broker yetkisinden ayrı tutulur. |

**Varsayılan giriş:** Oturum açınca Standart Üye Paneli açılır. Kullanıcı ayrıca yetkili çalışma alanlarına sahipse “Çalışma Alanlarım” seçicisiyle diğer paneline geçer. Panel geçişi kullanıcı hesabı veya kayıt kopyalamaz.

## 2A. Panel yaşam döngüsü ve geri alma kuralları

| Olay | Panel değişikliği | Korunanlar | İşlem sonucu |
|---|---|---|---|
| Hesap açılır | Standart Üye Paneli açılır | Hesap ve müşteri alanı | Kullanıcı müşteri ihtiyaçlarını seçebilir; tek başına dosya, müşteri rolü, profesyonellik veya gelir doğmaz. |
| Profesyonel başvuru gönderilir | Yeni panel açılmaz | Standart Üye Paneli | Başvuru durum/evrak/eksik bilgi akışı yalnız mevcut başvuru ekranında görünür. |
| Gayrimenkul Danışmanı aktif edilir | Danışman Paneli eklenir | Standart Üye Paneli | Aynı User ve aynı ilgili dosyalar yetki kapsamında yeni panelden görünür. |
| MAXIMUM franchise ofisi aktif edilir | Broker kapasitesi + yetkili Ofis Paneli eklenir | Standart Üye + Danışman | Franchise Broker türü ve sahiplik/ücret ilişkisi açıkça tutulur. |
| Kişi ALFA şubesine Broker olarak atanır | Atanmış Broker kapasitesi + o şubenin Ofis Paneli eklenir | Standart Üye + Danışman | Atama kapsamı dışında ofise erişim verilmez. |
| Broker ofisten/şube yöneticiliğinden alınır | İlgili Ofis Paneli/operasyon izinleri kaldırılır | Standart Üye + aktif danışmanlık varsa Danışman Paneli | Ofis korunur; yeni yetkili Broker/merkezi yönetim devralma akışıyla devam eder. Eski Broker'ın oturumu/önbelleği eski yetkiyi sürdüremez. |
| Profesyonellik iptal edilir | Danışman Paneli kapanır; ona dayanan Broker/Ofis yetkisi kaldırılır | Standart Üye Paneli ve bağımsız geçerli ilişkiler | Profesyonel operasyonlar kapanır; geçmişte kişinin taraf olduğu müşteri dosyaları silinmez ve uygun müşteri görünümünde kalır. |
| Stratejik İş Ortağı ilişkisi iptal edilir | Stratejik İş Ortağı Paneli kapanır | Standart Üye ve bağımsız geçerli paneller | Sadece atama/görev erişimi kapanır. |
| Kurumsal temsil yetkisi kaldırılır | İlgili şirket bağlamı/kurumsal dosyalara erişim kapanır | Kişinin kendi Standart Üye Paneli ve diğer bağımsız paneller | Kişi o şirket adına yeni işlem başlatamaz; kendi bireysel dosyaları etkilenmez. |

**Kademeli geri alma:** Ek panelin kaldırılması, kişinin temel hesabını veya geçmiş müşteri işlemlerini silme sebebi değildir. Yetki geri alma panel navigasyonu, backend aksiyonları, doğrudan URL erişimi, kayıt kapsamı ve aktif oturumdaki yetki kontrolünü birlikte etkiler.

**Profesyonellik iptali ve ofis devamlılığı:** Profesyonel statüsü iptal edilen kişi artık Danışman/Broker operasyonu yürütemez. Bununla birlikte ofis kaydı silinmez. Ofisin yeni Broker'a atanması veya marka tarafından devralınması ayrı bir yönetim işlemidir; eski kullanıcının kaldırılması ofis verilerinin sahipsiz/silinmiş olmasına neden olmaz.

## 2B. Bireysel ve kurumsal müşteri bağlamı

Standart Üye / Nihai Müşteri Paneli hem gerçek kişi hem de kurumsal müşteri süreçlerini destekler. Kurumsal müşteride oturum açan kullanıcı, şirketin kendisi değil; şirket adına işlem yapmaya yetkili gerçek kişi temsilcisidir.

- Üye hesabında kişisel bağlam her zaman korunur.
- Yetkili olunan bir veya daha fazla kurumsal müşteri varsa “Kişisel Alanım / Kurumsal Hesaplarım” bağlam seçicisi sunulur.
- Kurumsal bağlamda M01–M09 müşteri ekranları seçilen kurum adına açılan talep, hizmet, randevu, belge ve işlem kayıtlarını gösterir.
- Dosya tarafı bireysel kişi veya tüzel kişi olarak tutulur; temsilci, temsil yetkisi ve imza yetkilisi (gerekiyorsa) ayrı ilişkilerdir.
- Şirket çalışanı olmak tek başına tüm kurumsal dosyalara erişim vermez. Yetki kapsamı olmayan kullanıcı kurum bağlamını ve dosyalarını göremez.
- Bir şirketin mülk sahibi/satıcı/alıcı/kiracı/devreden/devir alan olması, oturum açan temsilciyi kişisel olarak o role dönüştürmez. Rol ilgili dosyada hukuki tarafa bağlanır.

---

## 3. Standart Üye / Nihai Müşteri Paneli — ekranlar tek tek tanımlı

Bu panelin referans görseli ve temel düzeni `GETMAKS360_UYE_MUSTERI_PANELI_TASARIMI_v2.1.html` ve `GETMAKS360_UYE_MUSTERI_PANELI_ONIZLEME_v2.1.png` dosyalarıdır. Müşteri paneli başka panelin daraltılmış görünümü değildir. Her kullanıcı bu paneli korur; aktif profesyonel veya Broker olsa dahi müşteri olarak kendi ihtiyaçlarını bu alandan yönetebilir. Nihai müşteri bireysel veya kurumsal olabilir. Kurumsal senaryoda aynı ekranlar seçilmiş, yetki verilmiş şirket bağlamıyla çalışır; yetki yoksa şirket kayıtları gösterilmez.

### M01 — Genel Bakış

**Amaç:** Kullanıcıya ilk ekranda müşteri ihtiyacını seçtirmek ve var olan süreçlerini izletmek.

Dört ana işlem kartı, ilk ekranda görünür ve belirgin olmalıdır:
1. **Mülkümü satmak istiyorum** → Hizmet Dosyası başlatma akışı.
2. **Mülkümü kiraya vermek istiyorum** → Hizmet Dosyası başlatma akışı.
3. **Gayrimenkul satın almak istiyorum** → Talep Dosyası başlatma akışı.
4. **Kiralık gayrimenkul arıyorum** → Talep Dosyası başlatma akışı.

Ayrıca “Süreçlerim” ve “Süreç nasıl ilerler?” alanları bulunur. Boş durum ekranı anlaşılır olmalı, gerçek kayıt bulunmadığında örnek/sahte işlem göstermemelidir. Profesyonel başvuru birincil ana kartların önüne geçmez. Kurumsal yetkili kullanıcı için kişisel/kurumsal bağlam seçici, erişim kapsamına göre görünür; kişisel bağlam varsayılan olarak korunur.

### M02 — Arayışlarım

Kullanıcının oluşturduğu satın alma/kiralık arama Talep Dosyalarını gösterir. Kullanıcı yalnız kendi veya usulüne uygun biçimde yetkili olduğu kayıtları açar. “Satın alma arayışı oluştur” ve “Kiralık arayışı oluştur” aksiyonları vardır.

### M03 — Mülklerim ve Hizmetlerim

Satışa veya kiraya vermeye konu ettiği mülklerini, ilgili Hizmet Dosyalarını ve hizmet ilerleyişini gösterir. “Mülkümü satmak istiyorum” ve “Mülkümü kiraya vermek istiyorum” aksiyonları vardır. Müşterinin beyanı, gerekli yetki belgeleri ve yetki sözleşmesi tamamlanmadan ilan otomatik yayınlanmış sayılmaz.

### M04 — Randevularım ve Gösterimlerim

Kullanıcının taraf olduğu gerçek randevuları/gösterimleri tarih, konum, durum ve ilgili mülk/işlem bağlantısıyla gösterir. Planlanmamış randevu uydurulmaz. Yer gösterme formu, ilgili gösterim olayına ve taraflarına bağlıdır.

### M05 — İşlemlerim

Mutabakat sonrasında başlatılmış İşlem Dosyalarını ve müşterinin erişebileceği aşamaları gösterir. Bir eşleşme tek başına işlem dosyası veya işlem kapanışı değildir. Müşteri sadece kendi taraf olduğu dosyanın ve paylaşılmasına izin verilen aşamaların detayını görür.

### M06 — Belgelerim

Kullanıcıya ait veya dosya/izin üzerinden paylaşılmış belgeleri gösterir. Belge yüklemek, bir dosyada talep edilen belgeyi göndermek veya sözleşmeyi görüntülemek kendi başına imzalama/onay anlamına gelmez.

### M07 — Hesap ve Güvenlik

Hesap bilgileri, iletişim ve güvenlik bilgileri, gerçek doğrulama kayıtları. E-posta/kimlik doğrulaması tek başına profesyonel statüsü oluşturmaz.

### M08 — Yardım ve iletişim

Yalnızca mevcut sistemde gerçek hedefi olan yardım/iletişim yönlendirmesi. Çalışmayan buton veya sahte destek kaydı yoktur.

### M09 — Profesyonel Başvuru (ikincil giriş)

Standart müşteri alanının bir parçası olarak erişilebilir ancak müşteri ihtiyacı kartlarının yerini almaz. Başvuru, belge, eksik bilgi talebi ve başvuru durumu kendi durum makinesiyle gösterilir. Başvuru göndermek Danışman Paneli açmaz; kabul ve gerekli aktivasyon koşulları tamamlandığında yeni panel eklenir.

**Müşteri panelinde bulunmaması gerekenler:** “Broker yönetimi”, “Danışmanlarım”, tüm ofis CRM'i, marka içi başvuru kuyrukları, tüm ofis portföyü veya yetkisiz diğer müşterilerin bilgileri.

---

## 4. Danışman Paneli — ekran ve işlem envanteri

Bu panel, aktif Gayrimenkul Danışmanının operasyon çalışma alanıdır; Standart Üye panelinin yerine geçmez. Üye panelindeki müşteri amaçları ve kendi kişisel mülk/talep işlemleri korunur. Profesyonel statü iptal veya pasif olduğunda bu panelin operasyon erişimi kapanır; Standart Üye Paneli ve geçmiş müşteri tarafları korunur. Brokerlık/Ofis erişimi de aktif profesyonelliğe bağlıdır.

### D01 — Danışman Genel Bakış
- Atanmış işlerin, kendi kapsamındaki taleplerin, Hizmet Dosyalarının, portföy/ilanların, randevuların ve bekleyen görevlerin özeti.
- Sadece gerçek, kullanıcıya atanmış ve erişilebilir kayıtlar.
- Ofis üyeliği, görev kapsamı ve profesyonel statü bilgisi.

### D02 — Müşterilerim
- Yalnız danışmana atanmış veya mevcut ofis iş akışıyla danışmanın sorumluluğuna verilmiş müşteri ilişkileri.
- Müşteri kaydı aynı User hesabına bağlıdır; danışman ekranı ayrı bir müşteri hesabı yaratmaz.
- Danışmanın erişemeyeceği ofis çapındaki kayıtlar gösterilmez.

### D03 — Talep Dosyaları
- Danışmana atanmış alıcı/kiracı talepleri, arama kriterleri, talep durumu ve izleyen adımlar.
- Eylemler: uygun eşleşmeyi değerlendirme, görevlendirilmiş müşteriye dönüş yapma, uygun randevu/gösterim adımını başlatma.
- Doğrudan müşterinin talep kaydını İşlem Dosyasına çevirmek yoktur; aradaki eşleşme, gösterim ve mutabakat koşulları korunur.

### D04 — Hizmet Dosyaları
- Danışmana atanmış satıcı/mülk sahibi/kiraya veren hizmet süreçleri.
- Yetki belgesi, yetki sözleşmesi, mülk bilgileri, hizmet paketi ve hizmet durumu uygun aşamalarla yönetilir.
- Müşteri hizmet paketi: Uzaktan Destek / Birebir Destek / Uzman Hizmet. Bunlar danışman ücret türü değildir.

### D05 — Portföylerim ve İlanlarım
- Sadece yetkili Hizmet Dosyası/kaynak mülk bağlantısından türeyen ve danışmanın erişimine verilmiş portföy/ilanlar.
- Yetki/temel belge ve zorunlu sözleşme kapıları karşılanmadan ilanın yayınlanmış sayılması engellenir.
- Müşteriye görünen ofis adı: “Maksimum Ofis / [ek ad]” veya “Getmaks Alfa [İlçe]”. İç model/atama ilişkisi ifşa edilmez.

### D06 — Eşleşmeler
- Gerçek arama kriterleri ile uygun ilanlar arasında oluşan eşleşmeleri, durum ve bir sonraki aksiyonuyla gösterir.
- Görüntüleme, eşleşme ve müşteri tarafından anlamlı etkileşim aynı şey değildir. Sırf ilan görüntüleme müşteri rolü oluşturmaz.

### D07 — Randevular ve Yer Gösterme
- Atanmış gerçek randevu/gösterim, ilgili taraflar, yer gösterme formu ve durum.
- Yer gösterme belgesi her ilgili gösterim olayı için ayrı tutulur.
- Belgeyi hazırlamak, taraflara sunmak, imza/onayı almak ve kanıtı doğrulamak ayrı aşamalardır.

### D08 — İşlem Dosyaları
- Danışmana yetkili olduğu işlem dosyaları, taraflar, koşullar, görevler, belgeler ve sözleşme aşamaları.
- Taraf mutabakatı yokken sadece eşleşme/gösterim nedeniyle nihai sözleşme veya kapanış yaratılmaz.
- Kapora/ön ödeme sözleşmesi, gerçek ödeme kanıtı ve nihai işlem sözleşmesi ayrı aşamalardır.

### D09 — Görevlerim ve Takvimim
- Danışmana atanmış görevler ve gerçek randevu/takvim verisi.
- Bir görev tamamlamak, ilişkili dosya ve belge koşullarını otomatik atlamaz.

### D10 — Belgeler ve Formlar
- Danışmanın görev/işlem kapsamındaki belgeleri. Müşteri veya ofis çapındaki tüm belgeler otomatik gösterilmez.

### D11 — Ofis Bilgim ve Üyeliğim
- Bağlı olunan aktif ofis, OfficeMembership durumu, izin verilen görev/rol ve üyelik geçmişi.
- Danışman buradan Broker rolü kazanmaz, ofis yöneticisi kullanıcı ekleyemez veya Ofis Paneli açamaz.

### D12 — Ücret Koşullarım
- Yalnız gerçek kaydı ve görme yetkisi varsa danışman giriş/aylık/yıllık ücretleri.
- Markaya ödenen ve ofise ödenen tutarlar alıcıya göre ayrıdır; yükümlülük, tahakkuk ve tahsilat farklıdır.

### D13 — Profil ve Güvenlik
- Kişisel hesap, iletişim ve doğrulama alanları. Profesyonel yetki değişimi, ilgili resmî başvuru/ilişki akışından yapılır.

---

## 5. Broker ve Ofis Paneli — birbirinden ayrı ekranlar, tek ofis kapsamı

Broker unvanı ve Ofis Paneli, başvuru metniyle değil gerçek aktif ilişkiyle açılır. Broker bir ofiste danışman üyeliği olduğu için yönetici olmaz. İki Broker yolu ayrı tutulur: (1) **MAXIMUM franchise Broker'ı** kendi franchise ofisini kurar/aktif eder; (2) **atanmış Broker** GETMAKS'ın açtığı ALFA şubesine Broker/şube yöneticisi olarak atanır. Kayıtlarda bu kapasite ve ilişkiler birbirine dönüştürülmez veya aynı sahiplik gibi sunulmaz.

Broker ofis görevi/ataması sona erdiğinde sadece yetki verilen o ofisin Ofis Paneli ve ofis operasyon izinleri kaldırılır. Profesyonel statüsü devam ediyorsa Standart Üye ve Danışman panelleri kalır. Profesyonellik ayrıca iptal edilmişse Standart Üye paneli kalır, profesyonel/Broker/ofis operasyon alanları kapanır. Ofis kaydı ve dosyaları silinmez; yeni sorumluya devir ayrı yönetilir.

### B01 — Broker statüsü / geçişi
- Başvuru, değerlendirme, eksik koşul veya ofis kuruluş/atanma aşaması yalnız ilgili geçerli başvuru akışında görünür.
- Aktif Broker olma koşulu tamamlanmadıysa kişi yalnız geçerli panellerini görür; başvuru Ofis Paneli açmaz.

### B02 — Ofis Genel Bakış
- Broker'ın kurduğu veya yönetmek üzere atandığı aktif ofis.
- Gerçek ofis durumları, açık iş/görev, danışman üyelikleri, portföy/ilan ve işlem özeti.
- Yetkisiz diğer ofislere geçiş/erişim yoktur.

### B03 — Ofis Bilgileri ve Ayarları
- İlgili aktif ofis kaydı ve yetkisi dâhilindeki ayarlar.
- MAXIMUM: broker franchise/ofis kurucusudur; franchise ilişkisi ve ücreti ofis türünden farklı kayıt/alanlardır.
- ALFA: şube GETMAKS tarafından açılır; broker atanmış yönetici olabilir. Şube franchise gibi gösterilmez.
- Müşteri görünümü kanonik dış ofis adını kullanır.

### B04 — Danışman Ekibim / Ofis Üyelikleri
- Broker'ın yetkili ofisindeki danışmanlar, OfficeMembership, durum, onboarding ve izin verilen eylemler.
- Onboarding başlatmak ile plan atamak veya danışmanı aktive etmek ayrı işlemlerdir.
- Aktif broker–ofis ilişkisi ayrı ücret/komisyon engagement kaydı gerektirmeden operasyonel ofis erişimi sağlar.
- Askı/sonlandırma durumunda kapsam dışı operasyon erişimi kapanır.

### B05 — Müşteriler ve Dosyalar
- Yalnız broker'ın ofisine ait veya ofise usulüne uygun atanmış müşteri/talep/hizmet/işlem dosyaları.
- Müşteri hesapları ve dosyalar çoğaltılmaz; danışman ve broker aynı kaynak kayıt üzerinde kendi izinleri kadar çalışır.

### B06 — Ofis Portföyü ve İlanlar
- Ofisin yetkili portföy/ilan kayıtları; kaynağı Hizmet Dosyası olan kayıtlar, yayın koşulları ve gerçek ilan durumu.

### B07 — Eşleşme, Randevu ve Gösterimler
- Ofis kapsamındaki eşleşmeler, atamalar, randevular ve yer gösterme adımları.

### B08 — İşlem Dosyaları
- Ofisin kapsadığı işlem dosyaları, sorumlular, taraflar, belge/sözleşme kapıları, gerçekleşme ve kapanış adımları.

### B09 — Görevler ve Ofis Takvimi
- Brokerın görme/yönetme izni olan ofis görevleri ve randevuları.

### B10 — Ofis Raporları
- Gerçek veri ve gerçek erişim kapsamına dayalı raporlar. Sahte KPI, tahmini ciro veya olmayan yatırım getirisi gösterilmez.

### B11 — Franchise / Görevlendirme / Ücret Koşulları
- MAXIMUM için ilgili franchise koşulu, 5 yıllık ilişki süresi ve geçerli ödeme düzeni birbirinden ayrı gösterilir.
- ALFA görevlendirmesi ve çalışma koşulları franchise ücreti değildir.
- Maaş/SGK/prim ancak gerçek marka ataması ve çalışma ilişkisi varsa gösterilir.
- Finansal koşul gerçek tahsilat gerçekleştiğini tek başına ifade etmez.

**Broker paneli sınırı:** Broker'ın Ofis Paneli GETMAKS marka yönetim paneli değildir. Marka geneli broker başvuruları, tüm ofisler, merkezi belge gereklilikleri ve tüm çalışanlar yalnız ayrı marka yönetim yetkisiyle görünür.

---

## 6. Stratejik İş Ortağı Paneli

Kişinin Standart Üye Paneli korunur. Aktif ve kapsamı belirli stratejik ortaklık ilişkisi ikinci çalışma alanını açar. Stratejik ortaklık sona erdiğinde yalnız Stratejik İş Ortağı Paneli ve bu ilişkiye bağlı görev erişimi kapanır; standart müşteri alanı ve geçmiş müşteri işlemleri kalır. Kişinin bağımsız aktif danışmanlık/Broker/Marka/Yatırımcı ilişkileri kendi şartlarına göre sürer veya sona erer.

### SO01 — Ortak Genel Bakış
- İş ortağına atanmış işler/görevler, durum ve bir sonraki aksiyon.

### SO02 — Atanmış Görevler
- Yalnız iş ortağına atanmış hizmet/işlem görevleri.
- Görev üzerindeki izinli adım, teslim sonucu veya açıklama.

### SO03 — Görev / İşlem Detayı
- Görevin yapılması için gereken asgari müşteri/dosya alanları.
- Tüm müşteri CRM'i, tüm ilanlar veya tüm İşlem Dosyaları açılmaz.

### SO04 — Belgeler ve Teslimatlar
- Yalnız kendisine atanmış görev kapsamında gerekli olan belge ve teslimat.

### SO05 — Takvim / İletişim
- Yalnız görevle ilgili randevu ve izin verilmiş iletişim alanı.

### SO06 — Ortaklık Profili / Kapsam
- Aktif ortaklık türü, izinli hizmet bölgesi/kapsamı ve gerçek sözleşme/durum kaydı.
- Model veya ilişki kaydı mevcut değilse genel bir stratejik ortaklar modülü uydurulmaz; geniş erişim açılmaz.

“Stratejik İş Ortağı” çalışma alanı, genel Gayrimenkul Danışmanı Paneli değildir. Aynı kişi bağımsız olarak aktif Gayrimenkul Danışmanı da ise bu gerçek ilişki ayrıca geçerli panelleri ekleyebilir; ortaklık kaydı tek başına Danışman/Broker/Ofis yetkisi üretmez.

---

## 7. Marka Yönetim Paneli

Marka yönetim alanı açık marka yetkisine sahip hesaplara görünür; standart üye hesabı korunur.

Ekranlar:
- MRK01 — Marka Genel Bakış
- MRK02 — Broker başvuruları, başvuru durumu, belge ve eksik bilgi süreçleri
- MRK03 — Brokerlar ve BrokerEngagement ilişkileri
- MRK04 — Ofisler ve MAXIMUM/ALFA türü
- MRK05 — Broker görevlendirmeleri ve atama geçmişi
- MRK06 — Profesyoneller ve ofis üyelikleri
- MRK07 — Danışman onboarding/başvuru belgeleri/aktivasyon durumları
- MRK08 — Müşteri hizmet kataloğu: Uzaktan Destek, Birebir Destek, Uzman Hizmet
- MRK09 — Franchise koşulları ve sözleşme kanıtları
- MRK10 — Danışman giriş/aylık/yıllık ücret koşulları; ödeyen ve alıcı taraf ayrımı
- MRK11 — Atama varsa Broker çalışma koşulları (maaş/SGK/prim), yalnız gerçek modelle
- MRK12 — Audit/işlem geçmişi
- MRK13 — Bildirim/outbox operasyon görünümü; teslimat kanalı yokken teslim edildi gösterilmez
- MRK14 — Marka yetkileri ve güvenlik

Marka kullanıcısının ofis veya profesyonel hesabına erişimi yetki ve görev kapsamına dayanır; marka paneli herkes için açık değildir. Broker Ofis Paneli ile marka yönetimi tek panelde birleştirilmez.

---

## 8. Marka Yatırımcısı Paneli

Bu alan hedef tasarımda tanımlanır; gerçek yatırım ilişkisi/anlaşması/ofis kapsamı modeli hazır ve geçerli değilse aktif finansal panel gibi sunulmaz.

Ekranlar, gerçek veri kaydı bulunduğu ölçüde:
- YT01 — Yatırımcı Genel Bakış
- YT02 — Anlaşmalarım
- YT03 — Anlaşmaya bağlı ofisler
- YT04 — Anlaşma kapsamındaki ofis portföyü ve gerçek operasyon göstergeleri
- YT05 — Yatırım payı/gelir kayıtları, yalnız sözleşme ve finans modelinin doğruladığı kapsamda
- YT06 — Belgeler ve anlaşma geçmişi

Kullanıcı sadece anlaşmada belirtilen ofisleri ve kendi yatırım haklarını görebilir. Yatırım modelinin eksik olması, tahmini gelir veya sahte finans kartı üretme izni değildir.

---

## 9. İşlemler ve panellerin bağlantısı

| İşlem başlangıcı | Kaydı/sonraki adımı yöneten alan | Müşteri tarafında gösterimi | Profesyonel/Ofis tarafında gösterimi |
|---|---|---|---|
| Mülkümü sat | Hizmet Dosyası | Mülklerim ve Hizmetlerim | Atanmış Hizmet Dosyası |
| Mülkümü kiraya ver | Hizmet Dosyası | Mülklerim ve Hizmetlerim | Atanmış Hizmet Dosyası |
| Satın almak istiyorum | Talep Dosyası | Arayışlarım | Yetkili/atanmış Talep Dosyası |
| Kiralık arıyorum | Talep Dosyası | Arayışlarım | Yetkili/atanmış Talep Dosyası |
| Mülk/ilanı anlamlı şekilde sorgulama veya gösterim isteme | İlgili dosyaya bağlı aday rolü/etkileşim | İlgili arayış/hizmet/işlem zaman çizelgesi | Eşleşme ve görev akışı |
| Yer gösterme | Her gösterim için ayrı gösterim olayı/formu | Randevularım ve Belgelerim | Randevu/Gösterim ekranları |
| Tarafların mutabakatı | İşlem Dosyası başlatma | İşlemlerim | Yetkili İşlem Dosyası |
| Kapora/ön ödeme sözleşmesi | Sözleşme aşaması; ödeme kanıtı ayrı kayıt | Paylaşılan sözleşme/işlem aşaması | İşlem Dosyası/sözleşme kapıları |
| Nihai sözleşme ve kapanış | İşlem türüne uygun sözleşme, belge/gerçekleşme/teslim kanıtları | Yetkili kapanış durumu | İşlem Dosyası kapanış kapıları |

### 9.1 Üç dosya türünün ilişkisi

- **Talep Dosyası:** Alıcı/kiracı veya devir alan gibi arayan tarafın ihtiyacını tutar.
- **Hizmet Dosyası:** Mülk sahibi/satıcı/kiraya veren/devreden adına sunulan hizmet sürecini tutar.
- **İşlem Dosyası:** Tarafların karşılıklı mutabakatına dayanan somut işlem sürecini tutar.

Bunlar aynı şeyin farklı etiketleri değildir; birbirine doğru ilişkilerle bağlanabilir, fakat otomatik ve koşulsuz biçimde birbirine dönüşmez.

---

## 10. Panel ekranı, izin ve işlem sonucu ilişkisi

Her ekran için uygulama aşağıdaki beş soruyu cevaplayacak şekilde yapılır:

1. **Kim?** Hangi hesap/profesyonel/ofis/ortaklık ilişkisi bu ekranı görebilir?
2. **Nerede?** Hangi panel ve hangi menü grubu içindedir?
3. **Ne görür?** Hangi gerçek kayıt kümesi ve hangi alanlar görünür?
4. **Ne yapabilir?** Hangi buton/form eylemi hangi mevcut route/controller/business action üzerinden yürür?
5. **Sonuç ne olur?** Hangi kayıt/durum/ilişki oluşturulur ya da güncellenir; bir sonraki hangi ekranda görünür?

Örneğin “Mülkümü satmak istiyorum” butonu yalnız modal açan dekoratif buton olarak kalmaz: uygun alanları ister, onayları alır, gerçek uygulama akışında Hizmet Dosyası başlatır ve sonuç Müşterinin “Mülklerim ve Hizmetlerim” ile profesyonelin yalnız yetkiliyse Hizmet Dosyaları ekranına aynı kaynak kayıt üzerinden yansır. Veri/politika altyapısı mevcut değilse sahte kayıt veya tamamlandı mesajı üretme; somut engeli bildir.

---

## 11. Navigasyon ve çalışma alanları

- İlk girişte Standart Üye / Nihai Müşteri Paneli açılır ve her zaman kullanılabilir kalır.
- Üst alanda **Çalışma Alanlarım** seçicisi bulunur; sadece ilişkileri geçerli olan ek panelleri listeler.
- Aktif Danışman: Standart Üye + Danışman. Aktif franchise Broker veya atanmış Broker: Standart Üye + Danışman + atanmış/kurulmuş ofisin Ofis Paneli. Stratejik İş Ortağı: Standart Üye + Ortak Paneli. Birden fazla bağımsız aktif ilişki varsa ilgili ek paneller bir arada bulunur.
- Standart Üye, Danışman, Ofis, Stratejik İş Ortağı, Marka ve Yatırımcı menüleri tek uzun menüde birleştirilmez. Her panel kendi başlangıç sayfasına, menüsüne, kayıt kapsamına ve eylem izinlerine sahiptir.
- Broker ofis görevinden alındığında Ofis paneli listeden kaldırılır; standart panel ve profesyonellik sürüyorsa Danışman paneli listede kalır. Profesyonellik iptal edilince Danışman/ona bağlı Broker-Ofis operasyon erişimi kapanır; Standart Üye her zaman kalır.
- Stratejik ortaklık veya kurumsal temsil ilişkisi biterse yalnız o bağımsız bağlama ait panel/erişim kapanır. Başka ilişkiler kendiliğinden değişmez.
- Standart Üye ekranları “yalnız hesap ayarı” gibi görünmeyecek; 3. bölümde tanımlı müşteri başlatma kartları ve sayfaları tam olarak korunacak.
- Menü öğesini gizlemek sunucu tarafı yetkilendirmenin yerine geçmez. Route/action, kayıt kapsamı, doğrudan URL, oturum/yetki yenileme ve ilgili eylem de aynı koşulu uygulamalıdır.

---

## 12. Mevcut kararları ve tamamlanmış işleri koru

- `Office.office_type`: `MAXIMUM` / `ALFA`; eski danışman `ProfessionalWorkModel` alanları otomatik dönüştürülmez.
- MAXIMUM franchise ofisi Broker tarafından kurulur; ALFA şubeyi GETMAKS açar ve broker atayabilir.
- Müşteriye gösterilen adlar: “Maksimum Ofis / [ek ad]”, “Getmaks Alfa [İlçe]”; iç franchise/atama bilgisi normal müşteri ekranına sızmaz.
- Müşteri hizmet paketleri yalnız Uzaktan Destek / Birebir Destek / Uzman Hizmet.
- C1: sürümlü gereklilik ve başvuru belgeleri; C2: kalıcı bilgi talebi/yanıtı; C3: outbox ve gerçek teslimat koşulları; C4: BrokerEngagement durum geçişi/audit; C5: merkezi operasyonel erişim kontrolü korunur.
- Aktif broker–ofis operasyon erişimi ayrı ücret/komisyon engagement kaydı şartına bağlanmaz.
- Panel bileşimi birbiri yerine geçen tek `User.role` alanına indirgenmez; Standard Member her zaman korunur, ek paneller ilişkilerle açılır/kapanır.
- Franchise Broker ve atanmış Broker ayrı kapasite/ilişki olarak tutulur. Atanmış Broker, MAXIMUM franchise sahibi olarak gösterilmez.
- Ofis görevi sonlandırılınca Ofis Paneli kapanır; aktif profesyonellik sürüyorsa Standart Üye + Danışman panelleri korunur.
- Profesyonellik iptal edilince Standart Üye paneli korunur; Danışman ve buna bağlı Broker/Ofis operasyon erişimi kapatılır. Ofis/dosya kayıtları silinmez.
- Nihai müşteri bireysel ya da kurumsal olabilir. Kurumsal müşteri ayrı hukuki taraf/kurum bağlamı ve yetkili temsilci ilişkisiyle ele alınır; temsilcinin kişisel hesabı şirketle birleştirilmez.
- Stratejik İş Ortağı erişimi kendi aktif ilişkisi ve atanmış iş kapsamıyla açılır/kapanır; ilişki sonlandığında Standart Üye paneli kalır.
- Brokerın uygun kendi ofisi için danışman onboarding başlatması, `plan.assign` izni bulunmadığı için engellenmez. Plan atama ve aktivasyon ayrı kapılardır.
- Broker detayındaki “başvuru belgeleri” etiketi korunur.
- Yatırımcı modeli kapsamı doğrulanmadan aktif yatırım getirisi hesaplanmaz.

---

## 13. Codex uygulama davranışı

Codex bu belgeyi ürün kararlarının bağlayıcı tanımı olarak uygular. Bu görevin amacı sistemi değerlendirmek veya yeniden tasarlamak değil, tanımlanan panel/ekran/işlem eşleşmelerini mevcut Laravel + Blade projesine uygulamaktır. Özellikle tek bir “rol etiketi” oluşturmak yerine, hesabın kalıcı Standart Üye katmanını ve bağımsız olarak eklenip kaldırılan profesyonel/ofis/ortaklık bağlarını uygulama davranışına dönüştür.

- Yeni alternatif iş modeli, yeni rol tanımı veya bağımsız mimari önerisi üretme.
- Paneli yalnız bir başlık/rozet veya tek bir `User.role` değeri olarak uygulama.
- Yukarıda tanımlı panel ve ekranları kapsamlarıyla uygulamaya taşı; mevcut route/model/policy yapısını yalnız gerekli değişiklik için kullan.
- Önceki C1–C5 davranışlarını ve 12. bölümdeki düzeltmeleri tekrar yazma veya bozma.
- Test yazma/çalıştırma, lint veya ayrı analiz/rapor çalışması yapma.
- Gerçek kod/ilişki eksikliği uygulamayı kesin olarak engelliyorsa iş kuralı uydurma; yalnızca engeli oluşturan somut dosya/bağımlılık ve uygulanamayan kısmı kısa bildir.
- Tamamlanmış işte kullanıcıya kısa olarak yalnız uygulanan değişiklikleri, önemli dosyaları ve varsa somut engeli bildir.

## 14. İlgili referans ekran

Standart Üye/Nihai Müşteri ekranlarının görsel ve metinsel referansı:
- `GETMAKS360_UYE_MUSTERI_PANELI_TASARIMI_v2.1.html`
- `GETMAKS360_UYE_MUSTERI_PANELI_ONIZLEME_v2.1.png`
- `GETMAKS360_UYE_MUSTERI_PANELI_MOBIL_v2.1.png`

Bu taslak müşteri panelinin başlangıç görselidir; bu ekranın sadece bir “Standart Üye” badge'ine indirgenmesi veya profesyonel panelle değiştirilmesi kabul edilmez.

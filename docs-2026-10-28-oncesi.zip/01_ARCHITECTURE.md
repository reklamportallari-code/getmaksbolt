# Mimari

## Hedef yapı

```text
app/
├── Core/
│   ├── Audit/ Authorization/ Organization/ Support/
├── Domains/
│   ├── Brand/ Office/ Professional/ Subscription/ Commercial/
│   ├── Customer/ DataPool/ RequestFile/ Service/
│   ├── Property/ Portfolio/ Listing/ Marketplace/
│   ├── Appointment/ Showing/ Offer/ Transaction/
│   └── Finance/ RevenuePool/
├── Integrations/
│   ├── Identity/ Eids/ Signature/ Notifications/ Accounting/
└── Providers/
```

Bir domain yalnız kendi fazında ihtiyaç doğduğunda Models, Actions, Policies, Services, DTOs, Events veya Http alt yapılarına ayrılır.

## Bağımlılık ilkeleri

- Domain iş kuralları HTTP/controller veya görünüm katmanına bağlanmaz.
- Uygulama aksiyonları domain davranışını orkestre eder; controller yalnız doğrulama, kapsam ve yönlendirme sınırıdır.
- Domainler arası iletişim açık sözleşmeler ve adlandırılmış olaylarla kurulur.
- Kimlik doğrulama ile yetkilendirme ayrı sorumluluklardır; varsayılan davranış reddetmedir.
- Kritik değişiklikler audit kaydı üretir; durum değişimleri ayrı tarihçede tutulur.
- Para integer minor-unit, oran basis-point ve para birimiyle temsil edilir; float kullanılmaz.
- Tarihçeli kararlar geçmiş kaydı değiştirmez; aktif dosyalar çalışma modelini snapshot olarak taşır.

## İşletme omurgası

`Brand → Office → Professional → Customer → RequestFile → ServiceOffer → ServiceFile`

Ticari yönetim omurgası:

`Ofis Franchise Sözleşmesi → sözleşme koşulları → ön muhasebe aktarım adayı`; danışman ticari planı ayrı akıştır.

`Plan`, `ChargePolicy` ve `PlanEntitlement` birbirinin yerine kullanılmaz. `ChargeAccrual` faturalama değildir; final fatura ve tahsilat Finans fazına aittir.

Sonraki fazların `Property → Portfolio → Listing → Marketplace → Transaction → Finance` zinciri Faz 3'e dahil değildir.

Dosya merkezli CRM, mülk sahibi hizmeti kabul edildiğinde `ServiceFile` kapsamındaki gayrimenkul bilgisini tekil bir `Property` kaynak kaydına taşır. Bu dar ilişki; Property yönetim ekranı, bağımsız Property yetkisi, portföy, ilan veya pazaryeri üretmez. Bunlar Faz 4'ün kapsamındadır.

`Professional → ProfessionalWorkModel → MAXIMUM | ALFA`

MAXIMUM/ALFA davranışı controller içindeki dağınık koşullarla değil `WorkModelPolicy` üzerinden yönetilir.

## Faz 2 uygulama sınırları

- `Domains/Customer`, `Domains/DataPool`, `Domains/RequestFile` ve `Domains/Service` iş kurallarını Action/Service sınıflarında uygular.
- Customer → CustomerActivity → RequestFile → ServiceOffer → ServiceFile zinciri gerçek veritabanı kayıtlarıyla çalışır.
- Data Havuzu erişimi route middleware, Gate, `WorkModelPolicy`, aktif profesyonel ve ofis kapsamı kontrolleriyle birlikte korunur.
- `StatusHistory` durum geçişlerini; marka/ofis kapsamlı `AuditLog` kritik aksiyonları izler.
- TD/HT/HD numaraları transaction ve satır kilidi kullanan `DocumentSequence` üzerinden üretilir.
- Claim süre sonu `pool-claims:expire` komutuyla her beş dakikada bir, overlap engellenerek çalıştırılır.

## Faz 3 yönetişim ve ticari politika sınırları

- Brand → Office, Brand → Consultant ve Office → Consultant ticari ilişkileri polymorphic `CommercialAgreement` ile tarihçeli tutulur.
- Marka ana planı, ücret kuralları ve kullanım hakları ayrı model ve tablolardır.
- Broker ana fiyatları değiştiremez; plan atama, indirim, ücretsiz hak ve limit aşımı yalnız etkin `BrokerCommercialAuthority` sınırında çalışır.
- İndirim/hediye/waiver/özel koşul ana politikayı değiştirmez; standart koşullar `CommercialException.standard_terms_snapshot` içinde korunur.
- `RevenuePolicy` çalışma modeline göre pay parametrelerini taşır; bu fazda gelir hesaplama veya dağıtma yapmaz.
- Admin broker rotaları `/admin/brokers` altında ve marka paneli bağlamındadır. Broker danışman sorguları aktif ofis üyeliğiyle sınırlandırılır.

## Faz 3A kurumsal yönetim akışı

- Marka yönetimi `/admin` route alanında `Brand → Office → {aktif Broker yöneticisi, Ofis Danışmanları}` organizasyonunu yürütür; `Broker → Consultant` ayrı bir sahiplik veya parent-child ilişkisi değildir. Admin hiçbir bağlantıda alt rol paneline geçirilmez.
- Ofis listeleme, oluşturma, düzenleme, pasife alma ve broker atama/değiştirme `Domains/Office` aksiyonları ile HTTP katmanından ayrılır.
- Broker değişimi mevcut `office_memberships` satırını overwrite etmez; eski satır `ended_at` ile kapanır, yeni satır `started_at` ile açılır ve nullable aktif anahtar tek aktif brokerı korur.
- Danışman, kendi aktif `OfficeMembership` kaydı üzerinden Ofise bağlıdır; Ofisin aktif Broker'ı bu kayıttan türetilir. Broker değişimi danışman üyeliğini, çalışma modelini veya operasyon dosyalarını değiştirmez. Danışmanın başka Ofise geçişi, eski üyelik/modeli tarihçeli kapatan ve yeni üyelik/model/ticari şartları açıkça kuran ayrı transfer aksiyonudur.
- Admin ve broker danışman listeleri aynı `ConsultantDirectory` sorgu servisini kullanır; rol farkı controller tarafından verilen ofis scope'udur.
- Danışman oluşturma; User, Professional, marka/ofis üyeliği, çalışma modeli ve gerçek SubscriptionPlan atamasını tek transaction içinde kurar. Kullanım bazlı gerçek plan yoksa sahte plan üretilmez.
- Çalışma modeli ve üyelik değişiklikleri yeni tarihçeli satır açar. Aktivasyon `ActivationReadiness` checklist'i tamamlanmadan ilerlemez.
- Broker plan, çalışma modeli ve yaşam döngüsü yetkileri aktif `BrokerCommercialAuthority` kaydından okunur; marka ana politikaları broker tarafından değiştirilemez.

## Faz 3A.1 kurumsal onboarding UX

- Ofis yaşam döngüsü `DRAFT → SETUP → READY → ACTIVE` ana hattını; `SUSPENDED` ve `TERMINATED` çıkışlarını kullanır. `OfficeSetupReadiness`, broker ve ticari ilişki dahil beş kurulum koşulunu domain katmanında hesaplar; yalnız `READY` ofis aktive edilir.
- Marka yöneticisi brokerı ofis detayındaki oluştur/seç/ata akışından veya `/admin/brokers/create` ekranındaki ofis seçmeli dört adımlı akıştan oluşturabilir. Her iki yol aynı `CreateBrokerAndAssignToOffice` ve `AssignBrokerToOffice` aksiyonlarını kullanır.
- Broker değişimi açık onayla yapılır; mevcut aktif üyelik ve ticari yetki tarihçeli kapatılır, yeni üyelik tek aktif broker kısıtını koruyarak açılır.
- Ofis, broker ve danışman detay sekmeleri allow-list ile doğrulanır ve yalnız seçilen bölümün verisini gösterir. Marka yöneticisi tüm zincirde `/admin/*` route ve layout bağlamında kalır.
- Danışman onboarding’i kimlik, ofis, çalışma modeli, gerçek aktif plan ve özet adımlarını tek transaction’da kurar. Profesyonel durum, onboarding, çalışma modeli, plan ve aktivasyon hazırlığı ayrı kavramlar olarak sunulur.

## Tek kaynak ilkesi

- Pazaryeri ayrı CRM, müşteri veya portföy kopyası üretmez.
- İlan, gelecekte Hizmet Dosyası ve Portföy kökünden doğacaktır.
- Data Havuzu müşteri/talep erişim alanıdır; Kazanç Havuzu finansal katkı ve hakediş alanıdır.

## Faz 3C / 3C.1 dosya merkezli CRM uyarlaması

- CRM girişinde Customer tek başına amaç değildir: talep tarafı `Customer → RequestFile`, mülk sahibi tarafı `Customer → RequestFile(OWNER_SERVICE) → ServiceOffer → ServiceFile → Property` zincirini kullanır. `ServiceFile` yalnız kabul edilmiş tekliften doğar; `Property` yalnız mülk sahibi hizmetinde kabul anında, aynı marka/ofis/müşteri kapsamıyla oluşturulur.
- `OperationalAssignment`, aktörün kullanabileceği ofisleri ve aktif danışman üyeliklerini tek yerde çözer. Brand Admin marka kapsamındaki ofisi seçer; Broker ve Consultant aktif ofis üyeliğinden otomatik kapsam alır. Broker birden fazla aktif göreve sahip olabilecek geleceği engelleyen tek-ofis sabiti içermez.
- Broker talep girişinde aktif ofis danışmanına dosya atar veya aynı müşteri/ihtiyaç verisini danışmansız `PoolRecord` olarak ofis Data Havuzuna bırakır. Bu iki sonuç aynı kayıt değildir.
- `DataPoolVisibility` Brand Admin için marka ofislerini, Broker ve MAXIMUM Consultant için yalnız aktif ofislerini kapsar. ALFA engeli `WorkModelPolicy` ve route middleware katmanında korunur.
- Yeni ofis kodu `DocumentSequence` içindeki `OFFICE_CODE` sayacı ve transaction kilidiyle `GET-O-NNNNNN` biçiminde üretilir. Mevcut kodlar dönüştürülmez.
- `CommercialTermsPresenter`, kalıcı enum/anahtar ve minor-unit/basis-point değerlerini değiştirmeden profesyonel ekranlarında Türkçe plan, hak, ücret ve pay karşılıklarına çevirir.
- Gelecekteki nihai müşteri yönlendirme sözleşmesi; talep/hizmet yönü ile il/ilçe/bölge girdisini alıp yetkili marka içindeki uygun veya en yakın hizmet veren ofisi döndürmelidir. Public form, mesafe hesabı ve geo-routing motoru Faz 3C kapsamında uygulanmamıştır.

## Faz 3C.3 sistem yönetimi

- `SystemSettings`, yalnız beyaz listedeki uygulama adı, saat dilimi, dil ve para birimini `system_settings` tablosundan okuyup çalışma zamanı config'ine uygular. Ortam, PHP ve framework sürümü yalnız okunur kalır.
- `RolePermissionRegistry` yetkilerin tek kaynağıdır. `role_permission_overrides` yalnız mevcut rol kapsamındaki bir yetkiyi kapatır; yeni rol, yeni yetki veya kullanıcıya özel override üretmez.
- Kullanıcı rolü ve oturum durumu ayrı action sınıflarında transaction ve audit ile değiştirilir. `User.status`, `Professional.status`, onboarding ve üyelik yaşam döngülerinden bağımsızdır.
- Son aktif `BRAND_ADMIN` rolü/durumu ve kritik sistem yönetimi yetkileri servis katmanında korunur. UI gizleme tek başına authorization sayılmaz.
- Marka ayarları yalnız mevcut `Brand.name/status`; Data Havuzu ayarları mevcut `SetPoolClaimPolicy` versiyonlama davranışı üzerinden güncellenir. Slug, ofis sayısı ve `DocumentSequence` sayaçları salt okunurdur.

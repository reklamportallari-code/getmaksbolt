# Hedef Veri Modeli

## Faz 1 — Corporate Core (uygulandı)

- `brands`, `offices`, `users`, `professionals`
- `brand_memberships`, `office_memberships`, `professional_work_models`, `work_model_change_requests`
- `subscription_plans`, `subscriptions`, `audit_logs`

## Faz 2 — CRM + Data Pool + Request + Service (uygulandı)

- `customers`: marka/ofis kapsamı, bireysel/kurumsal kimlik, normalize duplicate anahtarları ve oluşturan profesyonel.
- `customer_activities`: müşteri görüşmesi; opsiyonel RequestFile/ServiceFile bağı ve takip zamanı.
- `pool_records`: ofis kaynaklı iş fırsatı; tutarlar minor-unit.
- `pool_claims`: danışman claim'i, ilk temas/expiry/release tarihçesi; `(pool_record_id, active_key)` tek aktif claim'i korur.
- `pool_claim_policies`: süre, limit ve release izinleri; `(office_id, active_key)` tek aktif politika sürümünü korur.
- `request_files`: `TD-YYYY-NNNNNN`, müşteri ticari rolü, kaynak claim bağlantısı, durum ve değişmez çalışma modeli snapshot'ı.
- `service_packages`, `service_package_features`: markanın hizmet modelleri ve koddan bağımsız kapsamları.
- `service_pricing_policies`: paket/talep/taraf bazlı FIXED/PERCENTAGE/CUSTOM tarihçeli politika; para minor-unit, oran basis-point.
- `service_offers`: `HT-YYYY-NNNNNN`, paket/policy bağı, fiyat, durum ve parent/version revizyon zinciri.
- `service_files`: `HD-YYYY-NNNNNN`, kabul edilen tek tekliften doğan hizmet kaydı ve çalışma modeli snapshot'ı; RequestFile başına tek aktif kayıt.
- `status_histories`: RequestFile, ServiceOffer ve ServiceFile durum değişimlerinin polymorphic tarihçesi.
- `document_sequences`: dosya türü/yıl bazında concurrency-safe numara sayacı.
- `audit_logs.brand_id`, `audit_logs.office_id`: operasyon audit kayıtlarının organizasyon kapsamı.

## Faz 3 — Governance + Commercial Policy + UX Remediation (uygulandı)

- `subscription_plans.pricing_model`, `description`: aylık/yıllık sabit, kullanım, hibrit, ilan başına, paket, tek sefer ve işlem payı ürün tanımı.
- `commercial_agreements`: polymorphic provider/consumer ile Brand → Office, Brand → Consultant ve Office → Consultant plan ataması; yürürlük ve onay tarihçesi.
- `charge_policies`: plana bağlı sabit, kullanım, tek sefer ve işlem payı kuralı; tutar minor-unit, oran basis-point.
- `plan_entitlements`: plana bağlı boolean, kota veya sınırsız hak.
- `commercial_exceptions`: ücretsiz, hediye, indirim, waiver ve özel şart; standart koşul JSON snapshot'ı.
- `broker_commercial_authorities`: plan atama, indirim, ücretsiz hak ve limit aşımı izinleri ile azami indirim basis-point sınırı.
- `revenue_policies`: çalışma modeli ve kapsam bazlı danışman/marka/ofis/Kazanç Havuzu oran politikası; finansal hareket üretmez.
- `usage_events`: ticari sözleşmeye bağlı idempotent kullanım kaydı.
- `charge_accruals`: usage ve charge policy snapshot'ına bağlı bekleyen tahakkuk; final fatura değildir.

## Faz 3A.1 — Kurumsal onboarding UX (uygulandı)

- `offices.phone`, `email`, `started_at`, `onboarding_notes`: üç adımlı ofis wizard’ının iletişim, başlangıç ve kurulum notu alanları.
- `offices.status`: `DRAFT | SETUP | READY | ACTIVE | SUSPENDED | TERMINATED` yaşam döngüsünü taşır. Eski `PASSIVE` kayıtları migration sırasında `SUSPENDED` olur.
- `offices.ready_at`, `activated_at`, `suspended_at`, `terminated_at`: ofis onboarding ve yaşam döngüsü geçiş zamanlarıdır.
- `office_memberships.notes`: broker atama/değiştirme notu. `started_at`/`ended_at`, UX'teki effective_from/effective_until anlamını mevcut üyelik şemasında taşır.
- `subscriptions.notes`: plan atama/değiştirme notu; eski aktif subscription yeni plan başlangıç tarihinde `ends_at` ve `cancelled_at` ile kapanır.
- `work_model_change_requests.effective_at`: onaylanan model değişiminin yürürlük tarihi.
- `broker_commercial_authorities.can_manage_work_model`, `can_suspend_consultant`, `can_terminate_consultant`: brokerın kendi ofisindeki danışman yönetim sınırları; varsayılan değer `false`.
- Ofis READY/ACTIVE/SUSPENDED/TERMINATED ve danışman suspend/terminate geçişleri `status_histories` ve `audit_logs` kayıtları üretir; hard delete yapılmaz.
- Brokerlar bölümündeki doğrudan oluşturma ayrı bir broker tablosu üretmez; `users`, `professionals`, `brand_memberships` ve `office_memberships` aynı transaction’da oluşturulur.

## Constraint ve saklama kararları

- Foreign key'lerde operasyon tarihçesini korumak için çoğunlukla `restrictOnDelete` kullanılır.
- Tarihçeli aktif satırlar hard delete edilmez; bitiş alanları doldurulur ve nullable `active_key` null yapılır.
- Vergi no ve kimlik referansı encrypted cast ile saklanır; arama için anahtarlı hash tutulur.
- Para minor-unit, oran basis-point tutulur. Gerçek fiyat ve oran seed edilmez; yerel kayıtlar `TEST` işaretlidir.
- Ticari istisna ana politika satırını değiştirmez ve uygulama anındaki standart koşulları snapshot olarak korur.

## Sonraki faz envanteri

Property, Portfolio, Listing ve MarketplacePublication Faz 4; MarketplaceLead, Appointment, Showing, Offer/OfferRevision ve Transaction Faz 5; final Finance ve RevenuePool hareketleri Faz 6 kapsamında uygulanacaktır.

## Faz 3C / 3C.1 — Dosya merkezli CRM uyarlaması

- `request_files.flow_type`: `DEMAND` ile talep tarafını, `OWNER_SERVICE` ile mevcut ServiceOffer zincirini besleyen mülk sahibi ön kaydını ayırır. Eski null kayıtlar talep görünürlüğünde geriye uyumlu kalır.
- `request_files.province`, `district`, `region`, `room_count`, `usage_purpose`, `area_min_sqm`, `area_max_sqm`: Property oluşturmadan talep kriterlerini taşır; alanlar nullable eklenmiştir ve eski satırlar değiştirilmez.
- Talebin havuza bırakılması yeni bir RequestFile satırını danışmansızlaştırmaz; mevcut `pool_records` tablosunda müşteri/ofis bağlı iş fırsatı üretir.
- Hizmet başlangıcı mevcut RequestFile → ServiceOffer zincirini kullanır. `OFFERED` durumda ServiceFile yoktur; `ACCEPTED` kararında mevcut tek aktif dosya kısıtıyla ServiceFile oluşur.
- `document_sequences(document_type=OFFICE_CODE, year=0)` yeni ofis kodu sayacını taşır. `offices.code` unique kısıtı son savunmadır; mevcut ofis kodları ve satırları değiştirilmez.
- Ticari plan, agreement, entitlement, charge policy ve revenue policy satırları değişmeden kalır; insan-okur etiketler yalnız presenter çıktısıdır.

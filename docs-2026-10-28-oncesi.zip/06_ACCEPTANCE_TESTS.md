# Kabul Testleri

## Faz 0 ve Faz 1

- [x] Temiz Laravel uygulaması, SQLite, test runner, Vite ve kalıcı docs yapısı doğrulandı.
- [x] GETMAKS/tek ofis/tek broker, Professional, üyelik, MAXIMUM/ALFA, subscription, rol/izin ve audit omurgası çalışıyor.

## Faz 2 — Customer, Data Havuzu, Talep ve Hizmet

- [x] MAXIMUM ve ALFA kendi müşterisini oluşturur; rol ve organizasyon görünürlüğü backend seviyesinde uygulanır.
- [x] Normalize telefon/e-posta ve kimlik hash'leri duplicate uyarısı üretir; otomatik merge yapılmaz.
- [x] MAXIMUM Data Havuzunu görür/claim eder; ALFA GET/POST endpointlerinde 403 alır ve menü öğesini görmez.
- [x] Tek aktif claim, claim limiti, ilk temas, expiry/release ve Claim → Request dönüşümü çalışır.
- [x] Customer veya claim kaynağından TD numaralı RequestFile açılır.
- [x] work_model_snapshot model değişikliğinden etkilenmez; yeni dosya yeni modeli alır.
- [x] Request activate/lost, ServiceOffer revizyonu/kabulü ve tek aktif Hizmet Dosyası geçişleri tarihçeli çalışır.
- [x] Üç operasyonel ServicePackage seed edilir; gerçek fiyat seed edilmez.
- [x] TD/HT/HD numaraları DocumentSequence üzerinden concurrency-safe üretilir.

## Faz 3 — Yönetim bağlamı ve danışman UX

- [x] Admin broker listesi ve detayı `/admin/brokers` altında marka paneli bağlamında kalır; eski tekil rota yeni listeye yönlenir.
- [x] Broker danışman listesi gerçek Professional kayıtlarını model badge'i, durum, plan/üyelik, açık talep, aktif hizmet ve son aktiviteyle gösterir.
- [x] Tümü/MAXIMUM/ALFA/aktif/onboarding/askıda/aylık/yıllık/kullanım bazlı filtreleri backend sorgusuna bağlıdır.
- [x] Broker başka ofis danışmanını listede göremez ve detay URL'sinde 404 alır.
- [x] Danışman detayında çalışma modeli, ticari şartlar, üyelik/haklar, müşteri, talep, hizmet, aktivite, belge ve audit bölümleri vardır.
- [x] Danışman kendi ticari şartlarını salt okunur görür.

## Faz 3 — Ticari politikalar

- [x] Plan, ChargePolicy ve PlanEntitlement ayrı model/tablo ve audit davranışlarıyla çalışır.
- [x] Aylık/yıllık sabit, usage-only, hybrid, per-listing, package, one-time ve transaction-share plan türleri doğrulanır.
- [x] Brand → Office, Brand → Consultant ve Office → Consultant sözleşmeleri tarihçeli atanır.
- [x] Broker ana plan/fiyatı değiştiremez; plan/indirim/hak işlemleri etkin BrokerCommercialAuthority ile sınırlandırılır.
- [x] İndirim ana fiyatı değiştirmez ve standart koşul snapshot'ını saklar.
- [x] RevenuePolicy toplamı 10.000 bp'dir; ALFA Kazanç Havuzu payı sıfırdır; MAXIMUM payı parametreli tutulur.
- [x] Entitlement → UsageEvent → ChargePolicy → ChargeAccrual zinciri kota ve idempotency ile çalışır; fatura üretmez.
- [x] Faz 2 RequestFile/ServiceFile work_model_snapshot regresyonları korunur.

## Faz 3A — Brand → Office → Broker → Consultant UX

- [x] Brand Admin `/admin/offices` içinde ofis listeler, üç adımlı wizard ile DRAFT ofis oluşturur, detay/düzenleme/pasife alma ekranlarına admin context içinde gider.
- [x] Ofise broker atanır; broker değişiminde eski membership kapanır, yeni membership aynı tarihte açılır ve tek aktif broker constraint'i korunur.
- [x] Admin broker liste/detay linkleri yalnız `/admin/brokers/*` üretir; broker detayı admin layout içinde kalır.
- [x] Admin ve broker dört adımlı wizard ile gerçek danışman, ofis üyeliği, MAXIMUM/ALFA modeli ve mevcut aktif planı oluşturur.
- [x] Danışman listesinde arama; durum, model ve üyelik filtreleri aynı tablo üzerinde birlikte çalışır. MAXIMUM/ALFA yalnız badge ve filtre değeridir.
- [x] Aktivasyon checklist'i eksik plan/model/ofis/profil koşulunda aktivasyonu engeller; tamamlanan danışman aktifleştirilir.
- [x] Model ve plan değişimleri geçmiş satırı kapatıp yeni satır açar; RequestFile ve ServiceFile `work_model_snapshot` değerleri değişmez.
- [x] Suspend/terminate durum tarihçesi ve audit üretir; terminate belirtilen tarihte aktif model/üyeliği kapatır ve User kaydını silmez.
- [x] Broker çapraz-ofis danışman detayında 404; Consultant admin/broker yönetim route'larında 403 alır.
- [x] Admin, broker ve consultant panel context işaretleri rol değiştirmeden korunur.

## Faz 3A.1 — Kurumsal onboarding UX düzeltmesi

- [x] Ofis üç adımlı wizard ile durum seçtirmeden oluşturulur, `SETUP` olur ve beş adımlı kurulum göstergesi gerçek readiness koşullarını gösterir.
- [x] Ofis yalnız aktif broker ve ticari ilişki hazırlığı tamamlandıktan sonra `READY`; yalnız `READY` durumundan `ACTIVE` olur. Bu kontroller approval olarak adlandırılmaz; geçişler tarihçe ve audit üretir.
- [x] Ofis detayındaki broker atama ekranı hem mevcut broker seçimini hem dört adımlı yeni broker oluşturup atama yolunu destekler.
- [x] Brokerlar ana ekranında `+ Yeni Broker Ekle` eylemi bulunur; dört adımlı formda ofis seçilir ve başarılı kayıt admin broker detayına yönlenir.
- [x] Brokerlar bölümünden dolu ofise atama, mevcut brokerın tarihçeli kapanacağını açıkça onaylamadan kayıt oluşturmaz.
- [x] Danışman onboarding’i beş adımda gerçek User, Professional, ofis/marka üyeliği, MAXIMUM/ALFA çalışma modeli ve aktif aylık/yıllık planı oluşturur.
- [x] Ofis, broker ve danışman detay sekmeleri yalnız seçilen içeriği render eder; tüm marka yönetimi rotaları `/admin/*` bağlamında kalır.
- [x] Profesyonel, onboarding, model, plan ve aktivasyon durumları Türkçe ve ayrı alanlar olarak gösterilir; ana tablolar responsive sözleşmeyi sağlar.
- [x] Yerel panel inceleme modu, fixture hesaplarıyla marka yöneticisi, broker, MAXIMUM ve ALFA panellerine tek tıkla geçer; rol/Gate kuralları korunur ve production ortamında endpoint 404 döner.

## Approval / aktivasyon semantiği düzeltmesi

- [x] Brand Admin doğrudan Office, Broker ve Consultant oluşturduğunda `PENDING_APPROVAL` veya onaya gönderme adımı oluşmaz.
- [x] Broker, ticari plan atama yetkisi korunarak kendi ofisine Consultant oluşturduğunda ayrıca marka approval’ı beklenmez; çalışma modeli doğrudan aktif atanır.
- [x] Doğrudan oluşturulan Consultant marka/ofis üyelikleri aktif, profesyonel durumu `ONBOARDING` olur; readiness tamamlandığında mevcut aktivasyon endpoint’iyle `ACTIVE` olur.
- [x] Consultant Customer, RequestFile ve ServiceOffer oluşturduğunda profesyoneller arası approval kaydı oluşmaz.
- [x] Aktif danışmanın onboarding/profil güncellemesi kaydı `PENDING_APPROVAL` durumuna geri çekmez.
- [x] Aday başvurularının Brand Admin/Broker approval matrisi karar olarak kaydedildi; henüz Application domaini/rotası bulunmadığı için sahte uygulama veya ekran oluşturulmadı.
- [x] Listing publish ve Transaction close approval kuralları yalnız gelecek faz kararı olarak kaydedildi; Listing/Transaction motoruna girilmedi.

## Doğrulama sonucu

- [x] PHPUnit: 78 test, 428 assertion başarılı.
- [x] Approval semantiği matrisi: 8 test, 51 assertion başarılı.
- [x] Faz 3A.1 özel matrisi: 10 test, 110 assertion başarılı.
- [x] Blade şablonları derleniyor ve 109 uygulama rotası kayıtlı.
- [x] 38 migration uygulanmış durumda.
- [x] Vite production build ve Pint başarılı.
- [x] Property/Listing/Marketplace/Transaction ve final finans hareketleri uygulanmadı.

## Faz 3C / 3C.1 — Dosya merkezli CRM ve minimal uyarlama

- [x] Customer oluşturma ekranı talep ve mülk sahibi niyetlerini ilgili dosya akışlarına yönlendirir; mevcut müşteriyle de aynı akışlar çalışır.
- [x] Talep ekranı yalnız Alım/Kiralama/Devralma; hizmet ekranı yalnız Satış/Kiraya Verme/Devretme seçeneklerini gösterir.
- [x] Consultant ve Broker ofisi backend tarafından aktif üyelikten otomatik belirlenir; Brand Admin yetkili marka ofisini seçer.
- [x] Broker talebi kendi ofis danışmanına atar veya kendi ofis Data Havuzuna bırakır; farklı ofis ve farklı ofis danışmanı reddedilir.
- [x] Brand Admin marka genelinde havuz görür/filtreler/oluşturur; Broker ve MAXIMUM kendi ofisinde oluşturur; ALFA GET/POST erişiminde 403 alır.
- [x] Broker yeni havuz kaydını havuzda bırakabilir veya aktif ofis danışmanına mevcut claim policy ile atayabilir.
- [x] OFFERED ServiceOffer aktif ServiceFile oluşturmaz; ACCEPTED teklif oluşturur.
- [x] Yeni ofis kodu kullanıcı girişi olmadan `GET-O-NNNNNN` üretilir; mevcut kod düzenlemede değişmez.
- [x] Yetkili menü öğeleri linktir; yetkisiz Data Havuzu menüsü ve pasif placeholder sunulmaz.
- [x] Danışman ve broker ticari ekranlarında teknik plan modeli, durum, entitlement key ve value type kodları yerine Türkçe karşılıklar gösterilir.
- [x] Public müşteri/geo-routing, Property, Portfolio, Listing, Marketplace, Transaction ve final gelir dağıtımı uygulanmadı.
- [x] Tam PHPUnit paketi: 116 test, 564 assertion; 39 migration ve 111 uygulama rotası doğrulandı.
- [x] Blade view cache, zorunlu Pint düzeltme modu ve Vite production build başarılı.

## Faz 3C.3 — Ayarlar ve kullanıcı/yetki yönetimi

- [x] Desteklenen sistem ayarları düzenlenir; teknik ortam bilgileri, marka slug/ofis sayısı ve belge sayaçları salt okunur kalır.
- [x] Marka adı/durumu ile aktif Data Havuzu claim politikası mevcut model/action katmanları üzerinden güncellenir ve audit üretir.
- [x] Kullanıcı listesi ile beş sekmeli detay ekranı rol ve kullanıcı durumunu yönetir; User durumu Professional durumunu değiştirmez.
- [x] Roller kullanıcı/yetki sayılarıyla listelenir; mevcut rol izinleri Türkçe iş etiketleri ve dört iş grubu altında yönetilir.
- [x] Son aktif marka yöneticisi rol/durum kilidi ve kritik sistem yetkisi kilidi backend seviyesinde uygulanır.
- [x] Broker ve Consultant ayar/rol yönetimi endpointlerinde 403 alır; mevcut admin navigasyonu çalışmaya devam eder.
- [x] Tam PHPUnit paketi: 139 test, 700 assertion; 42 migration ve 123 uygulama rotası doğrulandı.

# CURRENT STATE

## Faz 4B.1 — Ofis kaynağı ve aktivasyon akışları kodla hizalandı

- `offices.creation_source` nullable alanı ve `OfficeCreationSource` enum'u eklendi: Admin oluşturma `BRAND_ADMIN_DIRECT`, broker başvurusu `BROKER_APPLICATION` kaynağıyla kaydedilir. Alan request input'undan alınmaz. Eski kayıtların kaynağı tahmin edilerek doldurulmaz; null kaynaklı ofisler normal approval/readiness/activation geçişlerine giremez ve elle incelenmelidir.
- Admin doğrudan kuruluşunda ofis `SETUP` başlar; taslak ticari ilişki ve bekleyen abonelik korunur. Admin onay kuyruğuna göndermeden `READY` işaretler. `ActivateOffice` transaction'ı readiness'i tekrarlar, uyumlu sözleşme/aboneliği aktive eder, mevcut koşullarda billing hazırlığı/ChargeAccrual üretir ve ofisi `ACTIVE` yapar.
- Broker başvurusu `SETUP` kaydedilir. Brand Admin ticari planı atar, ardından başvuruyu onaya gönderir. Onay eksik aboneliği mevcut `AssignSubscription` action'ıyla kurar ve subscription, ticari ilişki, `READY` ve `ACTIVE` geçişlerini tek transaction'da tamamlar. Ret `SETUP`'a döndürür. Admin approval endpointleri yalnız `BROKER_APPLICATION` kaynağını kabul eder.
- `MarkOfficeReady` ve `ActivateOffice` dış başvuru için yalnız onay controller'ının iç çağrısıyla geçebilir. Doğrudan route dış başvuruyu onaysız aktive edemez. `TERMINATED` koruması devam eder.
- Dış başvuru, kaynak sahteciliği, doğrudan kurulum, eksik readiness, yetkisiz erişim, bilinmeyen eski kaynak ve ticari rollback regresyonları `OfficeCommercialLifecycleTest` ve `PhaseThreeOnboardingUxTest` içinde kapsanıyor. Faz 4B.1 tam test paketi: 175 test / 953 assertion geçti.

## 2026-10-01 — Broker → Ofis → Marka Ticari Yaşam Döngüsü Uygulandı

- `/admin/offices/create` mevcut broker, yeni broker daveti ve brokerın sonra atanacağı kuruluş modellerini tek onboarding akışında destekliyor.
- Tarihsel 2026-10-01 kaydı: admin ofis onboarding'i `SETUP` / `DRAFT` ve `PENDING` subscription açıyor, approval endpointleri bu kayıtları `PENDING_APPROVAL` üzerinden aktive ediyordu. Faz 4B.1 ile approval davranışı yalnız dış başvuruya ayrıldı; admin doğrudan kurulumunda approval kuyruğu kaldırıldı.
- Aktivasyon fatura kesmiyor. Sözleşmedeki `billing_start_at` değerine göre subscription billing hazırlığı ve ilk `ChargeAccrual` oluşturuluyor; final invoice, cari ve tahsilat bu mevcut fazın dışında tutuluyor.
- `OfficeCommercialLifecycleTest` dört yolculuğu kapsıyor; tam suite 164 test / 858 assertion geçti. Admin wizard ve broker seçim panelleri tarayıcıda doğrulandı.

## Aktif karar: kurumsal, ticari ve müşteri hizmet akışı ayrımı

- Brand = ticari sözleşme ve marka düzeyinde yetki merkezi.
- Office = operasyonel lokasyon / franchise birimi.
- Broker = ofis yöneticisi / yetkili temsilci.
- Consultant = profesyonel çalışma ve müşteri hizmet katmanı.
- WorkModel = danışman erişim ve çalışma modeli.
- ServicePackage = müşteri hizmet kapsamı ve faturalama modeli.
- Customer = müşteri / taraf rolü.
- RequestFile = alıcı / kiracı / talep tarafı dosyası.
- ServiceFile = mülk sahibi tarafı operasyon dosyası.
- ServiceContract + ExternalAuthorization = ServiceFile'e bağlı iş sözleşmesi ve yetkilendirme kaydı.

Mülk sahibi akışında iş sırası: Customer → ServiceFile → ServiceContract → e-Devlet / external authorization → taşınmaz numarası → Property → Portfolio → Listing.

RequestFile ve ServiceFile akışları ayrı tutulur. Bu ayrım, müşteri tarafı ve mülk sahibi tarafı yönetimini tek bir dosya içinde karıştırmaz.


Current Phase:
03C.3 — AYARLAR + KULLANICI/YETKİ YÖNETİMİ MİNİMAL PATCH

Status:
COMPLETED

Completed:
- Bağlayıcı organizasyon modeli onaylandı: `Brand → Office → {aktif Broker yöneticisi, Ofis Danışmanları}`. Broker, danışmanın sahibi değil Ofisin yöneticisidir; danışmanın temel bağlantısı tek aktif `OfficeMembership` kaydıdır. Bu karar henüz yeni bir uygulama patch'iyle değiştirilmemiştir.
- Brand Admin Ayarlar ekranında desteklenen sistem tercihleri, marka adı/durumu ve aktif ofis Data Havuzu politikaları gerçek PATCH endpointleriyle yönetiliyor. Teknik ortam bilgileri, marka slug/ofis sayısı ve DocumentSequence sayaçları salt okunur.
- Kullanıcı yönetimi beş sekmeli detay, rol ve bağımsız User durumu işlemlerine sahip. Rol/durum değişimleri Professional, onboarding, membership, work model veya ticari kaydı değiştirmiyor.
- Roller mevcut registry kapsamındaki yetkileri rol seviyesinde etkin/pasif yönetiyor; kullanıcıya özel override veya yeni RBAC motoru yok. Permission kodları arayüzde Türkçe iş etiketleri ve dört iş grubu olarak sunuluyor.
- Son aktif marka yöneticisinin rol/durum kilidi ile kritik sistem permission kilidi action katmanında uygulanıyor; aktif olmayan kullanıcı girişleri ve mevcut oturumları engelleniyor.
- `SystemSettingChanged`, `BrandSettingChanged`, `PoolPolicyChanged`, `UserStatusChanged`, `RoleAssigned`, `RoleRemoved` ve `RolePermissionsChanged` audit aksiyonları bağlı.
- Brand Admin sidebar SİSTEM grubuna `Kullanıcılar ve Yetkiler` ile `Ayarlar` aktif ve permission-koşullu linkler olarak geri getirildi; pasif/gri placeholder kullanılmadı.
- `/admin/users`, `/admin/users/{user}`, `/admin/roles`, `/admin/permissions` ve `/admin/settings` GET rotaları eklendi. Her controller mevcut Gate/RolePermissionRegistry altyapısını kullanıyor; Broker ve Consultant backend seviyesinde 403 alıyor.
- Kullanıcı listesi ad, e-posta, rol, durum, aktif ofis, son audit aktivitesi ve detay bağlantısını; kullanıcı detayı genel bilgi, rol, izin, profesyonel/ofis ilişkisi, durum ve audit kayıtlarını gösteriyor.
- Roller ve izinler sayfaları yeni RBAC veya veritabanı tablosu üretmeden mevcut enum ve merkezi permission registry'nin salt-okunur görünümünü sunuyor.
- Ayarlar sayfası yalnız gerçek backend kaynaklarını gösteriyor: uygulama config'i, marka kaydı, DocumentSequence sayaçları ve aktif PoolClaimPolicy kayıtları. Sahte ayar formu veya backend karşılığı olmayan bildirim ayarı eklenmedi.
- Customer ekranları dosya merkezli hale getirildi; talep için BUY/RENT/TAKEOVER RequestFile, mülk sahibi hizmeti için SELL/LEASE_OUT/TRANSFER_OUT ve mevcut ServiceOffer → ServiceFile zinciri kullanılıyor.
- Mülk sahibi Hizmet Dosyası müşteri kabulünde, kaynak Talep Dosyasındaki gayrimenkul verisini aynı marka/ofis/müşteri kapsamında tekil `Property` kaydına taşır. Bu, Faz 4 Property Core yerine geçmez; Property CRUD, Portföy, İlan ve pazaryeri yüzeyi eklenmedi.
- Brand Admin marka genelinde Data Havuzu görür/filtreler/oluşturur; Broker ve MAXIMUM kendi aktif ofislerinde kayıt oluşturur; ALFA middleware ve WorkModelPolicy ile erişemez.
- Broker Talep Dosyası girişini kendi ofisinin aktif danışmanına atar veya aynı ihtiyacı kendi ofisinin Data Havuzuna bırakır. Consultant ve Broker ofisi sunucuda aktif üyelikten otomatik çözülür; Brand Admin ofis seçer.
- Broker Data Havuzu kaydını havuzda bırakabilir veya mevcut claim policy üzerinden aktif ofis danışmanına atayabilir. Farklı ofis kimlikleri backend tarafından reddedilir.
- Yeni ofis kodları `GET-O-NNNNNN` biçiminde kilitli sayaçla otomatik üretiliyor; mevcut kodlar korunuyor ve düzenleme ekranından değiştirilemiyor.
- Yetkili navigasyon öğeleri aktif link olarak sunuluyor; izinsiz/rotasız placeholder öğeler kaldırıldı.
- Danışman ve broker ticari ekranları teknik plan, durum, entitlement ve oran kodlarını değiştirmeden presenter katmanında Türkçe insan diline çeviriyor.
- Nihai müşteri için lokasyon → uygun/en yakın ofis yönlendirme sözleşmesi belgelendi; public form veya gerçek geo-routing motoru eklenmedi.
- Approval/aktivasyon semantiği ayrıldı: Brand Admin’in doğrudan Office/Broker/Consultant, Brokerın kendi ofisinde doğrudan Consultant oluşturması ayrıca approval beklemiyor; Consultant’ın Customer/RequestFile/ServiceOffer kayıtları da profesyoneller arası onaya gitmiyor.
- Doğrudan oluşturulan danışman `ONBOARDING` durumunda, aktif marka/ofis üyeliği, çalışma modeli ve subscription ile açılıyor; readiness tamamlandığında mevcut aktivasyon akışı `ACTIVE` yapıyor. Aktif danışmanın profil güncellemesi statüyü geriye çekmiyor.
- `required_approvals` adıyla tutulan gerçek readiness kontrolleri `profile_information` ve `broker_readiness` olarak düzeltildi. Aday başvuru akışları henüz uygulanmadığı için yalnız ADR-039 ile tanımlandı; sahte Application/Listing/Transaction motoru kurulmadı.
- Yerel inceleme için `PANEL_REVIEW_MODE` eklendi; giriş ekranı ve panel menüsü marka yöneticisi, broker, MAXIMUM ve ALFA fixture hesaplarına tek tıkla geçiyor. Mevcut rol/Gate kontrolleri korunuyor ve endpoint local/testing dışındaki ortamlarda 404 döndürüyor.
- Brokerlar ana ekranına `+ Yeni Broker Ekle` eylemi eklendi; ofis seçmeli dört adımlı akış gerçek User, Professional, marka üyeliği ve ofis atamasını tek transaction’da oluşturuyor.
- Seçilen ofiste aktif broker varsa Brokerlar bölümündeki doğrudan oluşturma açık değişim onayı istiyor; onaysız istekte hiçbir kayıt oluşmuyor.
- Ofis yaşam döngüsü DRAFT/SETUP/READY/ACTIVE/SUSPENDED/TERMINATED olarak uygulandı; beş readiness koşulu tamamlanmadan READY ve READY olmadan ACTIVE geçişi yapılamıyor.
- Ofis üç, broker dört ve danışman beş adımlı kurulum akışları; gerçek sekme izolasyonu, Türkçe durum sunumu ve responsive tablo/kart düzeniyle tamamlandı.
- Brand Admin → Ofisler → Yeni Ofis → Ofis Detayı → Broker Ata/Değiştir → Danışman Ekle → MAXIMUM/ALFA → Plan → Aktivasyon → Yönetim akışı tamamlandı.
- Admin ofis, broker ve danışman ekranları yalnız `/admin/*` route/context kullanıyor; alt rol paneline otomatik geçiş yok.
- Ofis listesi/üç adımlı wizard/detay/düzenleme/pasife alma ve tarihçeli broker atama ekranları eklendi.
- Admin ve broker danışman listeleri ortak backend filtre servisiyle ad/e-posta/telefon, durum, çalışma modeli ve üyelik filtrelerini birlikte uyguluyor.
- Beş adımlı danışman wizard'ı gerçek User/Professional/membership/work model/subscription kayıtlarını transaction içinde oluşturuyor; sahte plan üretmiyor.
- Danışman detayında dokuz sekme, yönetim aksiyonları, aktivasyon checklist'i, tarihçeli model/plan değişimi, suspend ve terminate akışları bağlı.
- Broker çalışma modeli, plan, suspend ve terminate aksiyonları kendi ofisi ve aktif BrokerCommercialAuthority bayraklarıyla sınırlandırılıyor.
- Faz 1 kurumsal omurga ve Faz 2 Customer → RequestFile → ServiceOffer → ServiceFile akışları korunarak Property öncesi remediation tamamlandı.
- Admin broker yönetimi `/admin/brokers` liste/detay rotalarına taşındı; admin rolü hiçbir broker sayfasında `/broker` bağlamına geçmiyor.
- Broker danışman listesi gerçek ofis Professional kayıtlarını model badge'i, durum, üyelik, açık talep, aktif hizmet ve son aktiviteyle gösteriyor.
- Broker danışman filtreleri ve çapraz-ofis 404 izolasyonu backend sorgularında uygulanıyor.
- Admin menüsü Kurumsal Yönetim, Ticari Yönetim, Operasyon ve Yönetim gruplarına ayrıldı; broker ve danışman menüleri rol bağlamına göre sadeleştirildi.

Commercial Policy:
- SubscriptionPlan `pricing_model` ile aylık/yıllık sabit, usage-only, hybrid, per-listing, package, one-time ve transaction-share türlerini destekliyor.
- Plan, ChargePolicy ve PlanEntitlement ayrı veri ve davranış katmanlarıdır.
- Brand → Office, Brand → Consultant ve Office → Consultant ilişkileri tarihçeli CommercialAgreement ile kuruluyor.
- BrokerCommercialAuthority plan atama, indirim, ücretsiz hak ve limit override yetkilerini açık bayraklar ve azami indirim basis-point sınırıyla yönetiyor.
- CommercialException ana plan/fiyatı değiştirmeden ücretsiz/hediye/indirim/waiver/özel şart ve standart koşul snapshot'ını saklıyor.
- RevenuePolicy çalışma modeline göre danışman/marka/ofis/Kazanç Havuzu paylarını basis-point olarak saklıyor; ALFA pool payı sıfır zorunluluğu var.
- PlanEntitlement → UsageEvent → ChargePolicy → ChargeAccrual zinciri kota ve idempotency ile çalışıyor; final fatura/tahsilat yok.

Work Models:
- `Office.office_type` içindeki MAXIMUM ve ALFA ofis türüdür. Ayrı olarak, tarihsel `ProfessionalWorkModel.MAXIMUM/ALFA` kayıtları danışman capability davranışını korur; `WorkModelPolicy` bu tarihsel danışman modelinin Customer CRM, Data Havuzu, claim, Talep/Hizmet Dosyası, bireysel kazanç, marka/ofis payı ve Kazanç Havuzu etkilerini merkezileştirir. İki alan otomatik eşlenmez.
- MAXIMUM Data Havuzu/Kazanç Havuzu katılımına açıktır; ALFA Data Havuzu ve Kazanç Havuzu dışında bireysel modeldir.
- RequestFile ve ServiceFile work_model_snapshot kayıtları model/policy değişikliklerinden etkilenmez.

Authorization / Audit:
- Brand Admin rolü `users/roles/permissions/settings` için view ve manage izinlerine sahiptir; kritik sekiz sistem izni kaldırılamaz. Diğer roller yalnız merkezi registry'deki kendi kapsamlarını kullanır.
- `role_permission_overrides` yalnız rolün mevcut iznini kapatır; farklı role yeni izin ve kullanıcıya özel override üretmez. Menü, controller/FormRequest ve action sınırları birlikte uygulanır.
- Doğrudan kurumsal kayıtlar `OfficeCreated`, `BrokerCreated`, `BrokerAssigned`, `ConsultantCreated` ve `ConsultantActivated` audit adlarını kullanıyor; `ApplicationSubmitted/Approved/Rejected` adları yalnız aday başvuru akışına ayrıldı.
- Merkezi permission registry ticari plan, charge, entitlement, agreement, revenue, exception, authority ve read-only own-view izinlerini kapsıyor.
- Broker ana plan/fiyat yönetemez; in-scope ticari aksiyonlar etkin authority kaydı olmadan reddedilir.
- CommercialAgreementCreated, PlanAssigned, ChargePolicyChanged, EntitlementGranted/Waived, DiscountGranted, RevenuePolicyAssigned, Consultant/OfficeCommercialTermsChanged audit adları destekleniyor.

Database:
- Faz 3C.3 ile User erişim durumu, kalıcı sistem tercihleri ve rol izin kapatma kayıtları için 3 additive migration; ardından Hizmet Dosyası kaynaklı gayrimenkul ilişkisi için 1 additive migration eklendi. Toplam 43 migration uygulanmış durumda.
- Ofis onboarding notu ve READY/ACTIVE/SUSPENDED/TERMINATED zaman alanları eklendi; eski PASSIVE ofis durumu SUSPENDED olarak taşındı.
- Office iletişim/başlangıç, membership/subscription notu, model değişim yürürlük tarihi ve broker lifecycle/work-model yetki alanları eklendi.
- Ticari tarihçe nullable `active_key`, effective_from/effective_until ve restrictOnDelete yaklaşımını kullanıyor.
- Para minor-unit, oran basis-point saklanıyor; gerçek fiyat/oran hard-code veya production seed edilmedi.
- Yerel örnek kişiler Selin Arslan, Ahmet Yılmaz, Ayşe Demir ve Mehmet Kaya olarak insan-okur biçimde gösterilir; broker ticari yetkileri varsayılan kapalıdır.

UI:
- Ayarlar ekranında desteklenen kartlar `Düzenle / Vazgeç / Kaydet`, aktif Data Havuzu politika satırları `Yönet` eylemi taşır; salt-okunur alanlar açıkça işaretlenir.
- Kullanıcı detayında Genel Bilgiler, Rol ve Yetkiler, Kurumsal İlişki, Durum ve Audit sekmeleri; rol listesinde açıklama, kullanıcı/yetki sayısı ve Yönet eylemi bulunur.
- Admin SİSTEM grubu `Kullanıcılar ve Yetkiler` → `Audit` → `Ayarlar` sırasıyla aktif bağlantılar içeriyor; ilgili sayfalar mevcut responsive kart/tablo dilini kullanıyor.
- Giriş ekranı ve oturum içi sidebar, yalnız local/testing ortamında görünen Panel İnceleme Modu seçicisini içeriyor.
- Brokerlar bölümünde doğrudan yeni broker oluşturma ve ofise atama ekranı bulunur; dolu ofiste değişim uyarısı ve onayı gösterilir.
- Admin menüsü GENEL, KURUMSAL YÖNETİM, OPERASYON, TİCARİ YÖNETİM ve SİSTEM gruplarıyla 03A spesifikasyonuna eşlendi.
- Dashboard'daki dokuz kurumsal kart ilgili filtreli admin listesine bağlandı.
- Ofis, broker ve danışman sayfalarında istenen breadcrumb, sekme, boş durum ve rol context'i uygulanıyor.
- Admin Broker liste/detay ve danışman 10 bölümlü detay görünümü hazır.
- Broker danışman tablosu ve detay görünümü; broker ticari yetki/read-only ekranı hazır.
- Danışman kendi üyelik, kullanım hakkı, ticari sözleşme ve istisnalarını salt okunur görür.
- Admin plan, ücret politikası, kullanım hakkı, ofis/danışman şartı, çalışma modeli, gelir politikası ve istisna ekranları bağlıdır.

Tests:
- `php artisan test --compact`: 182 passed, 1,095 assertions (2026-10-17; includes 11 focused 03C.4 transfer tests).
- `ServiceFileCreatesPropertyTest`: kabul edilmiş mülk sahibi hizmetinin müşteri, Hizmet Dosyası ve gayrimenkul kaydını aynı marka/ofis kapsamıyla kurduğunu ve Hizmet Dosyası ekranında gösterdiğini kapsar.
- 03C.3 sistem yönetimi matrisi: 16 test / 88 assertion; desteklenen ayar yazımları, salt-okunur sınırlar, politika versiyonlama, kullanıcı rol/durumu, Türkçe izinler, son admin kilidi, audit ve 403 sınırlarını kapsıyor.
- 03C.2 sistem yönetimi matrisi: 7 passed, 48 assertions; Brand Admin menü ve GET erişimi, kullanıcı detay/rol/izin/ayar görünümü, Broker/Consultant 403 sınırı ve mevcut admin navigasyonu kapsanıyor.
- Faz 3C/3C.1 aktör, scope, ofis kodu, menü ve ticari sunum matrisi: 20 test, 60 assertion; broker havuzdan danışman atama senaryosu ayrıca kapsanıyor.
- Approval semantiği matrisi: 8 passed, 51 assertions; doğrudan Office/Broker/Consultant, broker-created Consultant, Customer, RequestFile, ServiceOffer ve aktif kayıt regresyonu kapsanıyor.
- Panel inceleme matrisi: 5 passed, 17 assertions; görünürlük, doğru fixture oturumu, kapalı mod ve production 404 sınırı kapsanıyor.
- Faz 3A.1 özel matrisi: 10 passed, 110 assertions.
- Faz 3 özel matrisi: 10 passed, 57 assertions.
- Admin context, broker office isolation/filters, ticari ilişki matrisi, authority limiti, fiyat snapshot'ı, ALFA revenue kuralı ve kullanım tahakkuku kapsanıyor.

Build / Pint:
- `vendor/bin/pint --dirty --format agent`: başarılı.
- `npm run build`: başarılı; yalnız opsiyonel `fontaine` uyarısı var.
- Blade view cache başarılı; 123 uygulama rotası kayıtlı.

Known Issues:
- Broker/Consultant aday başvuru domaini ve rotaları henüz yok; approval matrisi ADR-039 olarak kayıtlı ve ilgili uygulama fazına kadar sahte ekran üretilmedi.
- Bağlı tarayıcı yüzeyi bu oturumda mevcut değildi; UI, tam HTTP/Blade matrisi, view compilation ve Vite production build ile doğrulandı.
- İşletim sistemi `docs/` içeriğini Codex yama aracına reparse point olarak sunduğu için belgeler staging dosyası + doğrulanmış güvenli kopya ile güncellendi; uygulama çalışmasını etkilemez.

Legacy Changes:
NONE

Next Recommended Phase:
03C.4 — OFİS MERKEZLİ ORGANİZASYON UX + DANIŞMAN TRANSFERİ MİNİMAL PATCH

Next Patch Scope:
- Broker panelinin ana bağlamını `Benim Ofisim` olarak sun; Ofis bilgisi, aktif yönetici, ticari şartlar/yetkiler, Ofis danışmanları, Data Havuzu ve operasyon özetini mevcut veri/izinlerle göster.
- Broker danışman listesini tek `Danışmanlar` bölümü olarak koru; MAXIMUM/ALFA yalnız çalışma modeli filtresi/bilgisi olsun.
- Brand Admin Ofis detayında `Ofis Bilgileri`, `Ofis Yöneticisi` ve `Ofis Danışmanları` ilişkisini açıkça göster.
- Danışman Ofis transferini eski üyelik/modeli kapatıp yeni üyelik/model/ticari şartları açan ayrı auditli aksiyon olarak uygula. Broker değişiminde danışmanları veya dosyaları taşıma.
- Yeni `broker_id`/Broker-Consultant sahiplik modeli, geniş refactor veya mevcut rol/izin/ticari yapı değişikliği yapma.

Next Recommended Phase After That Patch:
04 — PROPERTY CORE + PORTFOLIO + LISTING + SINGLE MARKETPLACE

Next Phase Entry Conditions:
- Ürün sahibi Faz 3C.3 Brand Admin ayar ve kullanıcı/rol yönetimi yüzeylerini kabul eder.
- Faz 4 için ayrı uygulama talimatı verilir.
- Faz 1-3 migration, authorization, work-model snapshot, commercial snapshot, office scope ve usage idempotency regresyonları korunur.
- Faz 4, ChargeAccrual'ı final fatura saymaz ve Finance/RevenuePool hareketlerini Faz 6'ya bırakır.

## 03C.4 Transfer Implementation Evidence (2026-10-17)

**Status: KISMİ — implementation and automated HTTP/feature evidence are present; product-owner acceptance remains open.** The former “Next Patch Scope” above describes work that has now been implemented and is retained as historical phase context. Do not treat this handoff update as phase acceptance.

- Future-effective consultant transfers create pending target membership, proposed work model, and pending subscription rows. The active source rows remain active until the effective date. Applying due transfers is registered through `consultant-transfers:apply-scheduled` every minute with overlap prevention; `php artisan schedule:list` showed the registration.
- A due transfer rechecks source/target membership, work model, plan, office, and active destination Broker inside a transaction. It retains a failed plan for retry and writes a failure audit. Cancellation closes the pending target records while leaving current access intact.
- `tests/Feature/ConsultantOfficeTransferTest.php`: 11 passed, 167 assertions. Coverage includes rollback after a controlled subscription creation error; future access timing; repeat application idempotency; invalid destination Broker and retry; cancellation; conflicting pending transfer rejection; Broker model filters; office detail memberships; Broker replacement without moving consultants or customer/request/service/listing records; and role-scoped HTTP visibility.
- Full suite: 182 passed, 1,095 assertions. Pint passed.
- The Laravel schedule registration was verified, but a continuously running Windows scheduler/cron process was not verified. A real browser session was unavailable; HTTP feature tests are not browser evidence. No true concurrent-process test was run. These remain acceptance evidence gaps.
- No database migration or legacy-project change was made. No `C:\laragon\www\GETMAKS360` files were touched.

**Next action:** review the listed product behavior and acceptance evidence, verify the host scheduler is running, and perform browser acceptance when a browser surface is available. Keep 03C.4 KISMİ until those gates are explicitly accepted.

## Office document and contract verification implementation (2026-10-19)

**Status: implemented in code and feature-tested; not yet migrated to the local application database or accepted in a real browser.** This does not change 03C.4's KISMİ phase status and does not establish later product-phase acceptance.

- The Brand Admin office documents tab now configures the brand's required-document list, stores private versioned office documents, records uploader/time/hash and review decisions, and prevents a later version from inheriting approval. Correction and rejection require a reason.
- Office contract evidence is separate from `CommercialAgreement` status. `OfficeContractVersion` snapshots contract text and terms, blocks updates/deletion, and records review plus Brand/Office evidence and authorized verification. Evidence upload is not electronic signature or legal-validity verification.
- `OfficeSetupReadiness` is shared by READY/ACTIVE/reactivation server actions. It checks required corporate fields, explicit brand document-list configuration, latest required document versions, the latest current-agreement contract version with reviewed/verified party proof and valid dates, broker readiness, and current commercial terms. A direct ACTIVE request fails when evidence is missing.
- Existing ACTIVE offices are not suspended by these rules. Their readiness gaps appear in admin office list/detail as a transition review. Suggested safe transition: inventory active records read-only; configure the actual brand requirements; verify current document versions; create contract versions from approved source text and exact terms; upload and verify party evidence; then have an authorized operator review each gap. Do not infer signatures or bulk-change office statuses.
- Contract readiness also compares the immutable snapshot against the current agreement, plan, and active charge-policy conditions. A commercial-condition change requires a new contract version and invalidates readiness for that latest version; it does not mutate or auto-close an already active office.
- `OfficeVerificationActivationTest` and affected lifecycle suites: 35 passed, 332 assertions. Final full suite: 187 passed, 1,174 assertions. Pint passed; `npm run build` passed with the existing optional Fontaine warning.
- At the time of the initial verification report, `migrate:status` showed the creation-source and five office verification migrations pending. A later read-only status check on 2026-10-19 shows `2026_10_16_202020_add_creation_source_to_offices_table` and all five `2026_10_19_1503xx/1504xx` office verification migrations as Ran. No application DB migration was run during the member-first package task. This confirms schema presence only; it is not browser acceptance or evidence that existing office records satisfy readiness.
- A real browser check was unavailable: the computer-use runtime failed initialization (`failed to write kernel assets: ... path not found`). Feature tests render the Blade screens but are not browser evidence. Legacy project was not accessed or modified.

**Next action:** perform read-only inventory of existing ACTIVE office readiness gaps and browser acceptance with controlled records. The listed office migrations are already present in the local V2 SQLite database; do not rerun or reset migrations. Keep existing ACTIVE offices unchanged until the per-office evidence review is complete.

## Member-first identity and customer access package (2026-10-19)

**Status: implemented in code, migrated to the local V2 SQLite database, and full-suite feature-tested; partial pending browser acceptance and approved-professional onboarding completion. Separate from 03C.4 and office activation verification.**

- Registration and new Broker/Consultant invitations retain `User.role=MEMBER`; explicitly authorized invitations may additionally create a Professional and scoped onboarding memberships. Legacy professional accounts also receive base Member routes/permissions without a bulk `User.role` update. Current professional panels are derived from Professional type and valid office membership. `User.role` cannot grant Broker/Consultant; existing professional access is not bulk-downgraded.
- `ProfessionalApplication` records Broker and Consultant applications. ADR-039 review routing is implemented; approval changes only application status to `ONBOARDING`, and no Professional or office membership is silently created.
- Members can create unassigned demand RequestFiles, see customer-facing status for explicitly linked files, request an authorized CRM account link, and submit a requested ServiceFile document to private storage. CRM links require explicit Brand Admin selection/review; email similarity alone exposes no file. Application, link request, and customer document submission are audit logged.
- `FileParty` stores customer side roles per RequestFile/ServiceFile. Transaction domain and transaction-party rows do not exist yet. Member-facing status is a whitelist presentation and does not expose internal summaries or professional finance.
- The approval status has a member-facing detail page, but no shared completion flow yet connects approved candidates with existing Professional creation, required agreements/documents/assignments, and final activation. The package therefore does not prove a new applicant can complete onboarding end-to-end. Operational access remains blocked until the existing active Professional and scoped office membership conditions are met.
- Additive migrations added: `2026_10_19_161342_create_professional_applications_table.php`, `2026_10_19_161915_create_customer_account_links_table.php`, `2026_10_19_162303_make_customer_and_request_files_office_scope_nullable_for_member_intake.php`, `2026_10_19_162642_create_service_file_documents_table.php`, `2026_10_19_162957_create_file_parties_table.php`. Before applying, the configured connection was verified as this project's `database/database.sqlite`; a temporary copy was SHA-256 verified identical. Only these five pending migrations ran successfully in batch 6. `migrate:status` confirms them Ran. No reset or destructive migration was used.
- Focused identity, application, CRM privacy, intake, document, and file-party tests passed. Follow-up coverage verifies newly invited Broker/Consultant users retain `MEMBER` as their base role while gaining only scoped professional rights through valid records, legacy Broker/Consultant users can use Member routes/permissions without changing their stored role or losing professional scope, and approved applications still cannot reach an operational endpoint. The identity matrix confirms one professional account can retain its scoped consultant panel while viewing only its explicitly linked customer file. Latest full suite: **203 passed, 1,304 assertions**; focused application/identity suite: **8 passed, 67 assertions**. Pint passed. No real browser session was available; these are HTTP/feature tests, not browser acceptance.
- No legacy project files were touched. Do not change 03C.4's `KISMİ` status. Office document/contract migrations are present locally, but keep their acceptance open until browser evidence and per-office readiness review are collected.

**Next package step:** define/implement the approved-applicant onboarding completion bridge using the existing provisioning, agreement, office membership, and activation actions. It must create no operational grant until those requirements succeed transactionally. Perform browser acceptance for this package and the existing office verification screens.

## Dilim 03 v1.3 — Current implementation authority (2026-10-26)

The following files in `docs/` are the current product authority for all subsequent implementation work. Read them before changing member identity, professional title, office/broker scope, customer roles, service/request/transaction flow, or contract gates:

1. `GETMAKS360_ANA_DEGISMEZ_ISKELET_v3.1.md`
2. `GETMAKS360_UYELIK_POTANSIYEL_MUSTERI_VE_PROFESYONEL_UNVAN_KARARLARI_v1.0.md`
3. `GETMAKS360_DILIM_03_ISLEM_ROLLERI_VE_SOZLESME_KAPILARI_v1.3.md`
4. `GETMAKS360_DILIM_03_KABUL_KONTROLU_v1.3.md`
5. `GETMAKS360_DILIM_03_PROTOTIP_v1.3.html` and `GETMAKS360_DILIM_03_V1_3_UYELIK_UNVAN.png` as UI references.

They supersede earlier ambiguous UI language. Standard membership is the member/customer foundation; customer-side roles are file-scoped; professional title and broker office scope are separately evidenced. No screen may claim a completed contract, signature, payment, entitlement, or operational access unless its source record and server-side conditions exist.

## Panel yaşam döngüsü v1.2 — güncel uygulama otoritesi (2026-10-26)

`GETMAKS360_CODEX_PANEL_YASAM_DONGUSU_UYGULAMA_TALIMATI_v1.2.txt`,
`GETMAKS360_PANEL_DURUM_GECIS_MATRISI_v1.0.md` ve
`GETMAKS360_ROL_PANEL_EKRAN_ISLEM_KURGUSU_v1.1.md` `docs/` altında saklanır ve
panel menüsü, rol geçişi, dosya kapsamı ve işlem ekranı değişikliklerinde birlikte okunur.

- Üye/Müşteri çalışma alanı her hesapta korunur. Müşteri dosyaları yalnız açık CRM bağlantısı veya dosya tarafı ilişkisi üzerinden görünür.
- Ek profesyonel, broker ve ofis çalışma alanları gerçek Professional, OfficeMembership ve broker-ofis ilişkisinden doğar; bir menü veya URL yetki vermez.
- Müşteri rolü dosya kapsamındadır. İşlem, gösterim ve belge ekranları müşteri için yalnız taraf olduğu kaynak kayıtlardan türetilir.
- Stratejik ortak ve yatırımcı panelleri, gerçek ilişki/kapsam modeli olmadan oluşturulmuş veya aktif finans ekranı gibi sunulmaz.
- Kaynak belge ile çelişen eski ekran dili yalnız ekran düzeni için değil, sunucu tarafı yetki ve durum kontrolleri bakımından da bu otoriteye göre düzeltilir.

## Panel, talep ve ofis tutarlılığı v1.0 (2026-10-27)

docs/10_PANEL_TALEP_VE_OFIS_TUTARLILIGI_v1.0.md, üye talep havuzu, marka onayı, profesyonel/ofis üyeliği ve broker ofis erişimi değişikliklerinde bu handoff ile birlikte okunacak güncel kaynak olarak eklenmiştir.


## Sözleşmeye esas form alanları v1.1 (2026-10-27)

Ofis ve danışman sözleşme sürümü ekranlarında ham JSON girişleri kaldırıldı. Çalışma modeli, paylaşım üst sınırları, görev/yetki, gerekli belge ve yükümlülükler yapılandırılmış form alanlarından mevcut snapshot şemasına dönüştürülür. Yeni finansal veya hukuki varsayılan oluşturulmaz.


## Ofis çalışma modeli ve paylaşım kuralı v1.2 (2026-10-27)

Ofis çalışma modeli Office.office_type kaydından tekil olarak türetilir. Sözleşme ve danışman formları modeli ikinci kez seçtirmez; paylaşım koşulları mevcut üst sözleşme sınırlarında ayrı snapshot verisi olarak kalır.

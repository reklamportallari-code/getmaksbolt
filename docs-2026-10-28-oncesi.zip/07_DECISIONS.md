# Mimari Karar Kayıtları

## ADR-001 — MVP tek pazaryeri
MVP tek pazaryeriyle başlayacaktır; uygulaması Property fazındadır.

## ADR-002 — Tek marka, yönetilebilir ofisler ve ofis başına tek broker
İlk sürüm tek GETMAKS markasıyla çalışır. Marka yöneticisi birden fazla ofis kaydı açabilir; `broker_active_key` her ofiste aynı anda yalnız bir aktif broker bulunmasını sağlar.

## ADR-003 — MAXIMUM/ALFA çalışma modelidir
MAXIMUM ve ALFA ofis tipi değil, tarihçeli danışman çalışma modelidir.

## ADR-004 — Data Havuzu yalnız MAXIMUM
Ortak Data Havuzunu görme ve claim etme yalnız aktif MAXIMUM danışmana açıktır. ALFA backend seviyesinde 403 alır.

## ADR-005 — Kazanç Havuzu yalnız MAXIMUM
Kazanç Havuzu finans domainidir. Faz 3 yalnız RevenuePolicy parametresini taşır; hareket üretmez.

## ADR-006 — Ortak operasyon yaşam döngüsü
MAXIMUM ve ALFA aynı Talep → Hizmet Teklifi → Hizmet Dosyası zincirini kullanır.

## ADR-007 — Çalışma modeli tarihçelidir
Model değişikliği ileriye dönüktür; Talep ve Hizmet Dosyası oluşturulduğu andaki modeli snapshot taşır.

## ADR-008 — Nihai müşteri faturasını Getmaks keser
Finans uygulaması Faz 6'ya ertelenmiştir.

## ADR-009 — Danışman hakediş faturası
Danışman hakediş faturası Faz 6 kapsamındadır.

## ADR-010 — Public landing MVP dışı
Public tanıtım ve landing sayfaları MVP kapsamında değildir.

## ADR-011 — Aktif anahtar stratejisi
Tarihçeli satırlar bitiş alanıyla kapanır; nullable `active_key` unique constraint'i tek aktif satırı korur.

## ADR-012 — Abonelik polymorphic tutulur
Office ve Professional aynı abonelik yaşam döngüsünü kullanır; para minor-unit, vergi basis-point saklanır.

## ADR-013 — Tek broker constraint stratejisi
`broker_active_key`, ofis başına tek aktif brokerı veritabanı seviyesinde korur.

## ADR-014 — Merkezi rol/izin ve backend enforcement
Rol → izin eşlemesi merkezi kayıttadır; route, middleware, Form Request ve action kontrolleri UI gizlemesinden bağımsızdır.

## ADR-015 — Customer duplicate strategy
E-posta küçük harf/trim, telefon yalnız rakam ve ülke kodu ile normalize edilir. Vergi no/kimlik referansı APP_KEY tabanlı HMAC hash ile aranır, ham değer encrypted saklanır. Eşleşme yalnız uyarıdır; otomatik merge yoktur.

## ADR-016 — Request domain naming
Laravel HTTP `Request` sınıfıyla çakışmayı önlemek için domain ve model adı `RequestFile` seçildi.

## ADR-017 — Pool claim expiry
Claim, ilk temas penceresi dolduğunda veya genel expiry zamanı geçtiğinde aktif ofis policy'si `auto_release_enabled` ise EXPIRED olur ve PoolRecord AVAILABLE durumuna döner. Komut beş dakikalık scheduler ve overlap kilidiyle çalışır.

## ADR-018 — work_model_snapshot
RequestFile açılırken aktif model kaydedilir; ServiceFile bunu kaynak RequestFile'dan devralır. Sonraki model değişiklikleri geçmiş dosyaları güncellemez.

## ADR-019 — ServicePricingPolicy
Fiyat politikası paket, opsiyonel talep/taraf, FIXED/PERCENTAGE/CUSTOM, geçerlilik aralığı ve durumla tarihçeli kaydedilir. Para minor-unit, oran ve KDV basis-point'tir; kodda fiyat yoktur.

## ADR-020 — Dosya numarası üretimi
TD/HT/HD için `document_sequences(document_type, year)` benzersiz satırı transaction içinde kilitlenir ve artırılır; `count()+1` kullanılmaz.

## ADR-021 — ServiceOffer history/version
Revizyon mevcut teklifi overwrite etmez. RequestFile kilitlenerek sıradaki version bulunur, yeni teklif parent_offer_id ile bağlanır; ACCEPTED teklif revize edilemez.

## ADR-022 — Faz 3 Property öncesi remediation kapısıdır
Property/Listing'e geçmeden yönetim bağlamı, ticari politika ve broker/danışman UX eksikleri ayrı Faz 3 olarak tamamlanır; sonraki fazlar 4-7 olarak yeniden numaralanır.

## ADR-023 — Plan, ücret ve hak ayrıdır
SubscriptionPlan ürün tanımıdır; ChargePolicy tahakkuk kuralıdır; PlanEntitlement erişim/kota hakkıdır. Bir kayıt diğerinin alanlarını üstlenmez.

## ADR-024 — Ticari sözleşme tarafları polymorphic'tir
Brand → Office, Brand → Consultant ve Office → Consultant aynı tarihçeli CommercialAgreement modeliyle tutulur.

## ADR-025 — Broker ticari yetkisi açık ve sınırlıdır
Broker marka ana fiyatını değiştiremez. `can_assign_plan`, `can_manage_work_model`, `can_apply_discount`, `max_discount_basis_points`, `can_grant_free_entitlement`, `can_override_usage_limit`, `can_suspend_consultant` ve `can_terminate_consultant` alanları varsayılan reddetme yaklaşımıyla uygulanır.

## ADR-026 — İstisna ana fiyatı değiştirmez
Ücretsiz, hediye, indirim, waiver ve özel koşul CommercialException kaydıdır; plan/ücret ana kaydı değişmez ve standart koşullar JSON snapshot olarak saklanır.

## ADR-027 — RevenuePolicy hesaplama değildir
RevenuePolicy yalnız yürürlük tarihli danışman/marka/ofis/Kazanç Havuzu pay parametrelerini taşır. Gerçek dağıtım, hakediş ve ödeme Faz 6'da oluşur.

## ADR-028 — Kullanım tahakkuku fatura değildir
Idempotent UsageEvent ve policy snapshot'lı ChargeAccrual gelecekteki faturalamanın girdisidir; sağlayıcı faturası, tahsilat veya muhasebe sonucu üretmez.

## ADR-029 — Panel bağlamı rotayla korunur
Marka yöneticisinin ofis, broker ve danışman sayfaları sırasıyla `/admin/offices`, `/admin/brokers` ve `/admin/consultants` altında admin layout/izinleriyle kalır. Broker danışman görünürlüğü aktif ofis üyeliğiyle scope edilir ve çapraz-ofis detayları 404 döner.

## ADR-030 — Broker değişimi üyelik tarihçesidir
Broker değişiminde `office_memberships` satırı overwrite edilmez. Mevcut brokerın `ended_at` değeri değişim tarihi olur; yeni broker aynı tarihi `started_at` olarak alır. Nullable aktif anahtarlar tek aktif satırı korur.

## ADR-031 — Danışman wizard'ı gerçek plan kullanır
Danışman oluşturma tek transaction içinde User, Professional, marka/ofis üyeliği, çalışma modeli ve aktif SubscriptionPlan kaydını bağlar. Kullanım bazlı motor veya plan hazır değilse sahte kullanım planı üretilmez.

## ADR-032 — Yaşam döngüsü geçmişi hard delete edilmez
Çalışma modeli ve plan değişiklikleri yeni satır açar. Askıya alma status history/audit üretir; sonlandırma belirtilen tarihte aktif üyelik ve modeli kapatır, User ile Talep/Hizmet geçmişini korur.

## ADR-033 — Office lifecycle and activation gate
Ofis `DRAFT`, `SETUP`, `READY`, `ACTIVE`, `SUSPENDED` ve `TERMINATED` durumlarını kullanır. Temel bilgi, marka, aktif broker ve geçerli ticari ilişki koşulları tamamlanmadan `READY`; `READY` olmadan `ACTIVE` geçişi yapılamaz. Aktivasyon anında readiness ve ticari koşullar yeniden doğrulanır. Readiness, approval değildir. Brand Admin'in doğrudan oluşturduğu ofis ayrı `PENDING_APPROVAL` adımı olmadan kurulum/readiness üzerinden aktive edilir. Dış başvuruyla gelen ofis yetkili incelemesi için `SETUP → PENDING_APPROVAL` approval yolunu kullanır; ret mevcut kurulum durumuna dönüş davranışını korur. `TERMINATED` terminaldir; approval, ret veya normal aktivasyon bu durumu açamaz.

## ADR-034 — Brand Admin role-context isolation
Marka yöneticisi ofis, broker ve danışman oluşturma, listeleme ve detay işlemlerinde yalnız `/admin/*` route ailesini ve admin layout’unu kullanır; `/broker` veya `/consultant` bağlamına otomatik geçiş yapılmaz.

## ADR-035 — Broker create/select/assign lifecycle
Broker mevcut profesyonellerden seçilebilir veya ofis bağlamında ya da Brokerlar bölümünden oluşturulabilir. Yeni broker User, Professional, marka üyeliği ve ofis üyeliğini tek transaction’da oluşturur; dolu ofiste değişim açık onay ve tarihçeli kapanış gerektirir.

## ADR-036 — Consultant onboarding checklist
Danışman onboarding’i kimlik, ofis, çalışma modeli, aktif ticari plan ve özet adımlarını izler. Aktivasyon User, Professional, ofis üyeliği, model, plan ve zorunlu profil bilgilerinin tamamını gerektirir; bu readiness koşulları approval değildir.

## ADR-037 — MAXIMUM/ALFA as work model
MAXIMUM ve ALFA rol, ofis tipi, menü veya ayrı modül değildir. Yalnız tarihçeli çalışma modeli ve capability matrisi olarak kullanılır; operasyonel snapshot’lar geçmiş modeli korur.

## ADR-038 — Admin UX table/detail standards
Kurumsal ana tablolar masaüstünde yatay kaydırma istemez ve küçük ekranda kart düzenine dönüşür. Detay ekranları yaklaşık 1200–1280 piksel kullanılabilir alanı kullanır; sekmeler yalnız seçilen bölümün içeriğini render eder ve boş durum bir sonraki eylemi açıklar.

## ADR-039 — Approval yalnız aday başvurusunda kullanılır
Approval yalnız bir kaynağın yetkili üst aktör incelemesini gerektirdiği başvuru yollarında kullanılır; readiness/validation ve approval ayrı kavramlardır. Brand Admin'in doğrudan oluşturduğu Office/Broker/Consultant ve Brokerın kendi ofisinde doğrudan oluşturduğu Consultant ayrıca approval beklemez. Ofis kaynağı `offices.creation_source` ile server tarafında `BRAND_ADMIN_DIRECT` veya `BROKER_APPLICATION` olarak atanır; istemciden gelen kaynak değeri kullanılmaz. Dışarıdan sunulan ofis başvurusu `SETUP → PENDING_APPROVAL` ile yetkili incelemesine girer; ofis ticari şartları belirlendikten sonra onay mevcut ticari, readiness, subscription ve aktivasyon mekanizmalarını kullanır, ret mevcut kurulum durumuna dönüş davranışını korur. `creation_source` eski kayıtlar için nullable'dır; kaynağı kanıtlanamayan eski ofisler tahminle sınıflandırılmaz ve normal onay/aktivasyon akışına sokulmaz. `TERMINATED` ofis terminaldir. Consultant’ın Customer, RequestFile ve ServiceOffer oluşturması profesyoneller arası approval üretmez. Profesyonel aday başvuru matrisi: Broker adayı için Brand Admin, marka geneli Consultant adayı için Brand Admin, belirli ofis Consultant adayı için ilgili Broker karar verir. Bu aday başvuru domaini/rotaları henüz yoktur; sahte kayıt veya UI üretilmez. Listing publish/activation ve Transaction close approval kararları ilgili gelecek fazlara bırakılır. Mevcut authorization, plan yetkisi, tarihçe ve snapshot kuralları korunur.

## ADR-040 — Customer dosya bağlamında oluşur
Customer CRM kaydı tek başına onboarding sonucu sayılmaz. Talep niyetinde RequestFile, mülk sahibi niyetinde mevcut ServiceOffer → ServiceFile zinciri kullanılır; mevcut Customer kayıtları iki akışta da yeniden kullanılabilir.

## ADR-041 — Talep ve mülk sahibi hizmet yönleri ayrıdır
BUY/RENT/TAKEOVER talep tarafıdır. SELL/LEASE_OUT/TRANSFER_OUT mülk sahibi hizmet tarafıdır. Property/Portfolio/Listing kurulmadan bu anlamlar aynı listede karıştırılmaz.

## ADR-042 — Data Havuzu görünürlüğü aktör ve ofis kapsamlıdır
Brand Admin marka genelini görür ve yetkili ofis adına oluşturur. Broker ile MAXIMUM Consultant yalnız aktif ofis kapsamını görür ve kayıt ekler. ALFA erişemez. Başka ofis kimliği endpoint seviyesinde kapsamı genişletmez.

## ADR-043 — Aktör bazlı ofis ataması
Consultant ve Broker için Talep/Hizmet ofisi aktif üyelikten otomatik çözülür; Brand Admin yetkili ofisi seçer. Broker yalnız kendi ofis danışmanını seçebilir. Gelecekte bir profesyonelin birden fazla yetkili ofis görevi olmasını engelleyen tek-ofis sabiti eklenmez.

## ADR-044 — Broker talebi atar veya ofis havuzuna bırakır
Danışmana atama RequestFile üretir. Havuz seçimi, aynı müşteri ve ihtiyaç bağlamını mevcut PoolRecord modelinde `AVAILABLE` olarak üretir; danışmansız RequestFile oluşturulmaz. Brokerın yeni havuz kaydını danışmana ataması mevcut claim policy ve ClaimPoolRecord davranışını kullanır.

## ADR-045 — Ofis kodu sistem tarafından üretilir
Yeni ofis kodu kullanıcı arayüzünden alınmaz; `DocumentSequence` üzerinde kilitli sayaçla `GET-O-NNNNNN` biçiminde üretilir ve `offices.code` unique kısıtıyla korunur. Mevcut kodlar geriye dönük değiştirilmez; düzenleme formu kodu yazılabilir alan olarak sunmaz.

## ADR-046 — Permission kullanılabilir özellik demektir
Bir özellik izni varsa menü linki, route ve backend authorization birlikte çalışır. İzni veya çalışan route'u olmayan seçenek gri bir ürün vaadi olarak gösterilmez. Mevcut RolePermissionRegistry yeniden kurulmaz.

## ADR-047 — Ticari teknik kodlar profesyonel kullanıcıdan gizlenir
Plan/entitlement/charge/revenue kayıtları ve hesaplama girdileri değişmez. `CommercialTermsPresenter` teknik enum, entitlement key, minor-unit ve basis-point verisini Türkçe insan diline çevirir; profesyonel ekranlar teknik kod veya test plan adını ana ticari kavram olarak göstermez.

## ADR-048 — Brand Admin sistem menüleri gerçek yetki ve backend yüzeyi ister
`Kullanıcılar ve Yetkiler` ile `Ayarlar`, Brand Admin için merkezi RolePermissionRegistry izinleri, çalışan GET rotaları ve controller Gate kontrolleri birlikte mevcutsa SİSTEM altında aktif link olarak gösterilir. Kullanıcı, rol ve izin görünümü mevcut statik rol/izin kaydını yeniden kurmaz; ayarlar ekranı yalnız gerçek uygulama config'i, marka kaydı, DocumentSequence sayaçları ve aktif PoolClaimPolicy kayıtlarını gösterir. Backend karşılığı olmayan ayar kontrolü veya pasif/gri placeholder üretilmez.

## ADR-049 — Sistem yönetimi rol seviyeli ve kilitlenmeye dayanıklıdır

Kalıcı uygulama tercihleri yalnız beyaz listedeki gerçek config karşılıkları için `system_settings` tablosunda tutulur. Mevcut `RolePermissionRegistry` rol izinlerinin tek kaynağı olmaya devam eder; `role_permission_overrides` yalnız rolün mevcut izinlerini devre dışı bırakabilir, yeni izin veya kullanıcıya özel override veremez. Kullanıcı erişim durumu Professional/onboarding/üyelik durumlarından ayrıdır. Son aktif marka yöneticisi ile `users/roles/permissions/settings` görüntüleme ve yönetme izinleri kaldırılamaz. Tüm değişiklikler ayrı audit aksiyonlarıyla izlenir.

## ADR-050 — Mülk sahibi Hizmet Dosyası gayrimenkulün kaynak kaydıdır

`OWNER_SERVICE` Talep Dosyasından doğan kabul edilmiş Hizmet Dosyası, aynı transaction içinde marka/ofis/müşteri kapsamını taşıyan tek bir `Property` kaydı üretir. Kayıt yalnız hizmet dosyasındaki gayrimenkul bilgisinin gelecekteki Portföy/İlan zincirine güvenli kaynağıdır; bağımsız Property CRUD, görünürlük yüzeyi, Portföy veya İlan davranışı oluşturmaz. Talep tarafındaki Hizmet Dosyası bu kayıtla zorlanmaz.

## ADR-051 — Broker Ofis yöneticisidir; danışman Ofis üyesidir

Organizasyon modeli `Brand → Office → {Broker, Consultants}` şeklindedir. Broker, Ofisin tek aktif yöneticisidir; danışmanlar Broker'ın bağımsız alt organizasyonu değil, aktif `OfficeMembership` ile Ofise bağlı profesyonellerdir. Danışmanın bağlı Broker'ı, Ofisin aktif Broker üyeliğinden türetilir; doğrudan `Broker → Consultant` sahiplik alanı kurulmaz. Broker değişimi danışman üyeliği, çalışma modeli, müşteri veya dosyaları taşımaz. Danışman transferi eski üyelik/modelin kapanıp yeni Ofis üyeliği/model/ticari koşulların açık aksiyonla kurulmasını, audit ve tarihçeyi gerektirir.

## ADR-052 — Marka Ticari Katmanı, Ofis Operasyon Katmanı, Müşteri Hizmet Katmanı ayrıdır

Kurumsal ve ticari yapı tek bir sınıf içinde toplanmaz. Ayrı katmanlar vardır:

- Brand / CommercialAgreement / SubscriptionPlan / RevenuePolicy: marka ve ticari sözleşme katmanı.
- Office / Broker authority / consultant membership: operasyonel ofis ve yönetişim katmanı.
- Consultant / Customer / RequestFile / ServiceFile / ServicePackage / Property / Portfolio / Listing: müşteri hizmet ve operasyon katmanı.

Bu ayrım, `WorkModel` ve `ServicePackage` kavramlarını birbirine karıştırmaz. `WorkModel`, danışmanın çalışma ve erişim modeli; `ServicePackage`, müşteri için sunulan hizmetin kapsam ve faturalama modelidir.

## ADR-053 — ServicePackage müşteri hizmet kapsamı ve faturalama modelidir

ServicePackage yalnız bir operasyonel dosya türü değildir; müşteri hizmetinin içeriğini, kapsamını ve fiyatlama mantığını tanımlar. Birebir destek ve uzaktan destek paketleri aylık / abonelik mantığıyla; uzman hizmet paketleri işlem olumlu olursa ücretli faturalama mantığıyla yürütülür.

Bu nedenle:

- marka ile profesyonel arasındaki ticari sözleşme ve planlar ayrı; 
- müşteri ile sunulan hizmetin operasyonel paketi ayrı; 
- ofis ve broker yetki katmanı ayrı; 
- müşteri/işlem akışı ayrı tutulur.

## ADR-054 — Talep Dosyası ve Hizmet Dosyası ayrı işlemdir

Mülk sahibi ve alıcı tarafı aynı business domain içinde birleştirilmez. Talep Dosyası, alıcı / kiracı / satıcı / kiralama talebi için kullanılır; Hizmet Dosyası, mülk sahibi tarafında açılan iş akışı için kullanılır.

Bu ayrım aşağıdaki şekilde korunur:

- RequestFile: müşterinin niyet ve talep dosyası
- ServiceFile: mülk sahibi tarafında açılan operasyonel dosya
- ServiceContract ve External Authorization: ServiceFile'e bağlanır
- Property / Portfolio / Listing: hizmet dosyası bağlamında ortaya çıkar

Bu katman aynı anda karar verici görünür olsa da ayrı akış olarak sürer; ServiceFile ile RequestFile eşitlenmez.

## ADR-055 — Mülk sahibi akışında yetkilendirme ve taşınmaz numarası ayrı sorumluluklardır

Mülk sahibi akışında üç ayrı karar katmanı vardır:

- Yetkilendirme: müşterinin dış sisteme verdiği e-Devlet / harici yetki
- Taşınmaz numarası: gayrimenkulün kimlik bilgisi
- Property: GETMAKS360 içindeki bağımsız gayrimenkul kaydı

Bu nedenle `ServiceAuthorization` ile `Property` aynı şey değildir. `ServiceAuthorization` yetkilendirme durumu ve referansı taşır; `Property` mülk kaydının operasyonel modelidir. Taşınmaz numarası yalnız gerekli olduğunda property üzerinde kalıcı olur, harici yetkilendirme kaydında referans olarak yer alır; iki kaynak aynı veri bütününü asla çift değil tek sorumlulukla tutmalıdır.

## ADR-056 — Hizmet dosyası ilk açılışında sözleşme ve yetkilendirme şartı ardından portföy/ilan akışına geçer

Getmaks360'te mülk sahibi akışında iş sırası şu şekilde sürer:

1. Mülk sahibi müşteri kaydı ve iş niyeti oluşturulur.
2. ServiceFile açılır.
3. ServiceContract oluşturulur.
4. Müşteri e-Devlet / harici sistem üzerinden yetki verir.
5. External Authorization kaydı müşterinin bildirimini ve referansını saklar.
6. Taşınmaz numarası danışman tarafından sisteme girilir.
7. Property kaydı oluşur.
8. Portföy ve Listing akışı başlar.

Bu bütün, Listing publish ön koşulu için tek karar noktasını sağlar. `ServiceContract`, `External Authorization` ve `property registration` ayrı kayıtlar olarak mevcut haline eklenir; ilan üretimi için gerekli olan tek ön koşul katmanı yalnız sonraki fazda devreye alınır.

## ADR-057 — Danışmanlar müşteri akışında aktif rol olarak iştirak eder, fakat bunun ticari sözleşme olmadan çalışması gerekmez

Danışman, müşteriye hizmet verirken işin hem operasyonel hem müşteri odaklı tarafında yer alır. Müşteri akışında danışman, gelir ve yetki bağlamını marka/office/ticari sözleşmeye bağlı çalıştırır. `Customer` ve `Consultant` ilişkisi, `ServicePackage` ve `CommercialAgreement` ile birlikte yürür; danışman sadece müşteriyle doğrudan ilişki kurmaz, aynı anda marka ve ofis ticari kapsamına göre çalışır.

Bu ayrım olmazsa, danışman, ofis, broker ve marka katmanları aynı anda aynı kayıtta temas eder; bu operasyonel akışı bozar ve işlevsel faturalama ile iş akışı birbirine karışır.

## ADR-058 — Ofis aktivasyonu güncel belge ve sözleşme kanıtı gerektirir

Marka başına kurumsal zorunlu belge listesi açıkça yapılandırılır; yapılandırma kaydı yokluğu eksikliktir. Ofis belgeleri özel depoda sürümlenir ve her sürüm ayrı inceleme/onay alır. Sözleşme sürümü metin ve ticari koşul snapshot'ını değişmez tutar; `CommercialAgreement` durumundan bağımsız olarak ilgili sürümün incelemesi, marka ve ofis taraflarına ait doğrulanmış imza kanıtları ve etkin tarih aralığı denetlenir. MVP yalnız kanıt yükleme ve marka yetkilisi doğrulaması yapar; e-imza veya hukuki geçerlilik iddiası taşımaz.

`OfficeSetupReadiness`, `MarkOfficeReady` ve `ActivateOffice` ortak kontrolü uygular. Yeni sürüm oluşturulması önceki sürümün kanıtını yeni sürüme kopyalamaz; yeni sürüm onaylanıp yürürlüğe girene dek eski sürüm kendi tarih aralığında geçerliliğini koruyabilir. Önceden aktif ofisler otomatik olarak kapatılmaz; eksikler raporlanıp işletme tarafından incelenir.

## ADR-059 — Üye hesabı kalıcı kimliktir; profesyonel yetki scoped ilişkiyle verilir

Kendi kendine kayıt yalnız temel `MEMBER` hesabı oluşturur. Yönetici/Broker tarafından davet edilen hesap da `MEMBER` rolünü korur; açık davet akışı ayrıca Professional kaydı kurabilir. Geçiş dönemindeki eski profesyonel hesaplar için de MEMBER temel erişimi `User.role` alanını topluca güncellemeden sağlanır; profesyonel erişim aynı anda scoped Professional ilişkilerinden çözülür. Broker/Danışman erişimi tek `User.role` değerini değiştirerek verilmez veya üyeliğin yerine geçirilmez; Professional türü ile geçerli marka/ofis üyelikleri ve operasyon middleware'i birlikte belirler. Profesyonel başvurusu kalıcı `ProfessionalApplication` kaydıdır; onay yalnız onboarding durumunu açar ve aktif yetki doğurmaz. Yeni başvuru için mevcut sözleşme/belge/atama provisioning zincirini tamamlayan ortak akış ayrıca gereklidir.

CRM Customer ile üye hesabı e-posta benzerliğine göre otomatik bağlanmaz. Görünürlük, doğrulanmış aktif `CustomerAccountLink` veya dosyaya bağlı `FileParty` üzerinden verilir. Taraf rolleri dosya kapsamındadır; User.role'a yazılmaz. Üye müşteri görünümü yalnız müşteri için yayımlanmış dosya durumu ve kendisinden istenen belge yükleme akışını sunar.

Bu karar eski profesyonel kayıtları toplu değiştirmez veya doğrulanmış kabul etmez. `ProfessionalApplication` onayı sonrasında ortak onboarding tamamlaması; gerçek e-imza/hukuki geçerlilik; Transaction dosyası ve işlem tarafı ilişkisi bu paketin dışındaki açık işlerdir. 03C.4 ve ofis aktivasyon kanıt kapıları bu kararla kabul edilmiş sayılmaz.

## ADR-060 — Bütünleşmiş paneller ve ofis türü geçiş sınırı

Üye/Müşteri, Broker, Danışman ve Marka panelleri tek bir yetki ve veri sahipliği sözleşmesiyle ilerler; çalışma alanı seçimi kendi başına yetki vermez. `ProfessionalApplication`, `Professional`, `OfficeMembership`, `BrokerEngagement`, ticari anlaşma ve panel erişimi ayrı durum eksenleridir. Broker, danışmanın sahibi değildir; danışman ofisin profesyonel üyesidir.

Güncel ürün kararı MAXIMUM ve ALFA'yı ofis türü olarak hedefler. Bu karar `Office.office_type` nullable enum alanı, yönetim/başvuru ekranı doğrulaması ve yeni ofislerde zorunlu seçimle 2026-10-24 tarihinde uygulanmıştır. Mevcut `ProfessionalWorkModel.MAXIMUM/ALFA` satırları eski danışman çalışma/capability anlamını korur ve ofis türüne otomatik dönüştürülmez. Eski NULL ofis türleri için veri eşleme ve `WorkModelPolicy` etkisi ayrı bir onaylı paketle ele alınacaktır. Bu karar C1–C5 kayıtlarını veya mevcut Data/Kazanç Havuzu kurallarını değiştirmez.

# İş Kuralları

## Kurumsal kapsam

1. Getmaks tek ana markadır.
2. MVP tek GETMAKS markasıyla başlar; marka yöneticisi birden fazla ofisi aynı admin bağlamında yönetebilir ve her ofiste aynı anda yalnız bir aktif broker bulunabilir.
3. `Office.office_type` içindeki MAXIMUM ve ALFA, ofis türüdür. Tarihsel `ProfessionalWorkModel.MAXIMUM/ALFA` kayıtları danışman çalışma/capability modelidir; iki eksen birbirinin yerine kullanılmaz veya otomatik eşlenmez.
4. Danışman aktif üyelik ve aktivasyon olmadan operasyon yapamaz.
5. Ofis ve danışman üyelikleri aylık, yıllık veya tanımlı diğer ticari model kapsamında olabilir.

## Çalışma modelleri

- **MAXIMUM:** Kendi müşterilerini yönetir, ortak Data Havuzunu görür ve policy sınırlarında claim eder; yürürlükteki gelir politikasında Kazanç Havuzu payı bulunabilir.
- **ALFA:** Yalnız kendi oluşturduğu veya kendisine atanmış müşteri/dosyalarla çalışır; Data Havuzu route ve aksiyonlarına erişemez; Kazanç Havuzu payı sıfırdır.
- İki model de Customer CRM, Talep Dosyası ve Hizmet Dosyası yaşam döngülerini kullanır.
- Model değişikliği ileriye dönüktür; mevcut Talep/Hizmet Dosyası snapshot'ı değişmez.
- Model davranışları `WorkModelPolicy` capability matrisi üzerinden okunur; kullanıcı rolü veya ofis tipi üretilmez.

## Ticari yönetim

- Kurumsal organizasyon `Brand → Office → {Broker: Ofisin aktif yöneticisi, Consultants: Ofise bağlı profesyoneller}` şeklindedir. `Broker → Consultant` ayrı organizasyonel sahiplik değildir.
- Danışmanın temel organizasyon bağlantısı aktif `OfficeMembership` kaydıdır; aktif Broker, danışmanın Ofisi üzerinden çözülür. Danışman tablosunda veya ilişkilerinde `broker_id` benzeri ayrı bir sahiplik alanı tutulmaz.
- Her danışmanın aynı anda yalnız bir aktif Ofis üyeliği vardır. Broker kendi aktif Ofisinin danışmanlarını yönetir; Broker tarafından danışman oluşturulurken Ofis kullanıcıdan seçilmez, aktif Broker üyeliğinden sunucuda çözülür.
- Broker değişimi yalnız Broker Ofis üyeliğini ve o Ofise ait broker ticari yetkisini tarihçeli kapatıp yeniler; danışman üyeliklerini, çalışma modellerini, müşteri veya dosyaları taşımaz.
- Danışman Ofis transferi ayrı, auditli ve tarihçeli bir aksiyondur: eski Ofis üyeliği ile bağlı aktif çalışma modeli kapanır; yeni Ofis üyeliği, yeni çalışma modeli ve gerekli ticari şartlar açıkça oluşturulur. Aktif müşteri/dosya taşıma davranışı ayrıca kararlaştırılmadan otomatik yapılmaz.
- Desteklenen ticari ilişkiler Brand → Office, Brand → Consultant ve Office → Consultant'tır.
- Ticari plan ürün/kapsam tanımıdır; ücret politikası tahakkuk kuralıdır; kullanım hakkı erişim, boolean, kota veya sınırsız hakkı tanımlar.
- Ofis–broker franchise ilişkisi beş yıllık sözleşme, franchise bedeli ile isteğe bağlı aylık ve yıllık ek ödeme yükümlülüklerinden oluşur. Bunlar danışman ticari planı değildir; tutar ve oranlar kayıttan okunur.
- Broker marka ana planını veya fiyatını değiştiremez. Plan atama, indirim, ücretsiz hak verme ve kullanım limiti aşımı ayrı yetki bayrakları ve azami indirim baz puanıyla sınırlandırılır.
- Ücretsiz, hediye, indirim, waiver ve özel şart kayıtları ana fiyatı overwrite etmez; standart koşulların anlık görüntüsünü saklar.
- `listing.publish`, `data_pool.access` ve `marketplace.profile` gibi anahtarlar hak altyapısında tutulabilir; bu durum Listing veya Marketplace domaininin uygulanmış olduğu anlamına gelmez.
- Kullanım zinciri `PlanEntitlement → UsageEvent → ChargePolicy → ChargeAccrual` sınırında biter. Fatura ve tahsilat bu fazda oluşmaz.
- RevenuePolicy oranları toplam 10.000 baz puandır. ALFA için `pool_share_basis_points` sıfırdır; MAXIMUM değeri kayıt üzerinden belirlenir.

## Faz 3A ofis ve danışman yönetimi

- Yeni ofis `DRAFT` varsayılan durumuyla açılabilir; iletişim ve başlangıç tarihi ofis kaydında tutulur.
- Broker değişiminde eski ofis üyeliği silinmez veya overwrite edilmez. Değişim tarihinde eski satır kapanır ve yeni aktif satır açılır.
- Danışman ekleme akışı ad, soyad, benzersiz e-posta, telefon, ofis başlangıç tarihi, MAXIMUM/ALFA seçimi ve mevcut aktif planı zorunlu tutar.
- Danışmana atanan plan sahte veya kod içi bir karşılık değildir; aktif `SubscriptionPlan` kaydından seçilir ve subscription tarihçesi korunur.
- Aktivasyon User, Professional/marka üyeliği, Office Membership, aktif Work Model, aktif Subscription/Plan ve zorunlu profil alanlarının tamamını gerektirir.
- Askıya alma üyelik/model satırlarını silmez. Sonlandırma belirtilen tarihte aktif üyelik, ofis/marka üyeliği ve çalışma modelini kapatır; User ve operasyon geçmişi korunur.
- Broker yalnız kendi aktif ofisinin danışmanlarını yönetir. Plan atama ve çalışma modeli yönetimi açık yetki kaydına; askıya alma/sonlandırma ayrı policy bayraklarına bağlıdır.
- BRAND_ADMIN ofis, broker ve danışman işlemlerinde `/admin` bağlamından ayrılmaz.

## Faz 3A.1 onboarding ve aktivasyon kuralları

- Yeni ofis kullanıcıdan durum istemeden önce `DRAFT`, kayıt transaction’ı tamamlandığında `SETUP` olur. Ofis durumları yalnız `DRAFT`, `SETUP`, `READY`, `ACTIVE`, `SUSPENDED` ve `TERMINATED` değerleridir.
- Temel bilgiler, marka bağlantısı, aktif broker ataması ve aktif ticari/üyelik ilişkisi tamamlanmadan ofis `READY`; `READY` olmadan `ACTIVE` olamaz. Bunlar approval değil aktivasyon hazırlığı koşullarıdır.
- Marka yöneticisi Brokerlar bölümünden yeni broker eklerken görev ofisini seçer. Seçilen ofiste aktif broker varsa değişim açıkça onaylanmadan hiçbir User, Professional veya üyelik kaydı oluşturulmaz.
- Broker oluşturma; benzersiz e-posta, telefon, aktif marka üyeliği ve tarihçeli ofis üyeliğini tek transaction’da oluşturur. Bir broker aynı anda yalnız bir aktif ofis üyeliğine sahip olabilir.
- Danışmanın profesyonel durumu, onboarding durumu, çalışma modeli, ticari planı ve aktivasyon hazırlığı birbirinin yerine kullanılmaz. Ofis türü de bunlardan ayrıdır: MAXIMUM/ALFA ofis sınıflandırması `Office.office_type` içinde, eski danışman capability anlamı ise `ProfessionalWorkModel` içinde kalır.
- Ana yönetim tabloları masaüstünde yatay kaydırma gerektirmez; dar ekranlarda satırlar erişilebilir kart düzenine dönüşür. Detay sekmeleri yalnız seçilen içeriği gösterir.

## Approval ve aktivasyon hazırlığı ayrımı

- Yetkili üst aktörün doğrudan oluşturduğu kayıt ayrıca approval beklemez: Brand Admin tarafından oluşturulan Office, Broker ve Consultant ile Broker tarafından kendi ofisinde oluşturulan Consultant doğrudan kurulum/aktivasyon hazırlığı yaşam döngüsüne girer.
- Doğrudan oluşturulan profesyonel için `PENDING_APPROVAL` üretilmez. Akış `Kurulum Devam Ediyor → Aktivasyona Hazır → Aktif` şeklindedir; zorunlu alan, ofis üyeliği, çalışma modeli ve ticari plan kontrolleri approval değildir.
- Brokerın doğrudan danışman oluşturması marka approval’ı gerektirmez. Brokerın ticari plan atama yetkisi gibi mevcut authorization sınırları aynen korunur.
- Consultant tarafından oluşturulan Customer, RequestFile ve ServiceOffer profesyoneller arası approval beklemez; kendi validation, scope ve yaşam döngüsü kurallarıyla doğrudan oluşturulur.
- Approval yalnız aşağıdan yukarı aday başvurusunda kullanılır: Broker adayı → Brand Admin; Consultant adayı → Brand Admin; belirli ofise başvuran Consultant adayı → ilgili Broker. Aday başvuru modeli ve rotaları henüz uygulanmadığından bu karar bu fazda sahte ekran veya kayıt üretmez.
- Gelecekte Listing publish/activation için Broker approval uygulanabilir; Transaction close için Broker approval zorunlu tutulabilir. Listing ve Transaction motorları mevcut fazda oluşturulmaz.
- Mevcut `ACTIVE` profesyoneller onboarding veya profil güncellemesi nedeniyle `PENDING_APPROVAL` durumuna geri çekilmez; geçmiş work model, subscription ve Talep/Hizmet snapshot kayıtları değiştirilmez.

## Ofis belge, sözleşme kanıtı ve aktivasyon güvencesi

- Ofis kurumsal belgeleri özel depoda sürümlenir; belge türü, sürüm, yükleyen kullanıcı, yüklenme zamanı, içerik özeti ve inceleme tarihçesi saklanır. Durumlar `UPLOADED → IN_REVIEW → APPROVED | CORRECTION_REQUESTED | REJECTED` şeklindedir. Düzeltme ve ret gerekçesi zorunludur; yeni sürüm öncekinin onayını devralmaz.
- Marka belge gereksinim listesi yapılandırılabilir. Yapılandırma kaydı yoksa zorunlu belge kontrolü eksiktir; açıkça kaydedilmiş boş liste, işletmenin gereksinim belirlemediği kararını ifade eder.
- `CommercialAgreement` iş/ticari ilişkinin durumunu tutar; `ACTIVE` imza kanıtı değildir. Sözleşme metni ve ticari şart snapshot'ı `OfficeContractVersion` içinde değişmez sürüm olarak saklanır. Metin/koşul değişikliğinde yeni sürüm açılır.
- İlk kanıt akışı yüklenmiş belge ve marka yetkilisinin doğrulamasını kaydeder; elektronik imza attığını veya hukuki geçerliliği otomatik doğruladığını iddia etmez. Marka ve ofis taraflarının sürüme bağlı doğrulanmış kanıtları, inceleme onayı ve geçerli başlangıç/bitiş tarihleri tamamlanmadan sözleşme yürürlükte sayılmaz.
- Ofis `READY`, `ACTIVE` veya yeniden `ACTIVE` geçişleri aynı `OfficeSetupReadiness` kontrollerini kullanır: kurumsal bilgiler, yapılandırılmış/güncel onaylı zorunlu belgeler, en güncel sözleşme sürümünün onaylı ve yürürlük koşulları, broker ataması/yetkisi ve mevcut ticari şartlar.
- Hazır olma/aktivasyon HTTP istekleri kontrolleri sunucuda tekrarlar. Eksik koşullar ilgili ofis tamamlama ekranına bağlanır. Yeni kontroller daha önce `ACTIVE` olan ofisleri otomatik askıya almaz; eksikler marka yönetiminde geçiş incelemesi olarak listelenir.

### Ofis başvuru kaynağına göre approval

- Brand Admin'in `/admin/offices` üzerinden doğrudan oluşturduğu ofis ayrı approval kuyruğuna girmez. Ofis, broker hesabı/üyeliği ve geçerli ticari koşullar dahil mevcut readiness tamamlanınca `READY`, ardından yeniden doğrulanan koşullarla `ACTIVE` olur.
- Dışarıdan gelen ofis başvurusu yetkili incelemesi için `SETUP → PENDING_APPROVAL` yolunu kullanır; ret mevcut `SETUP`'a dönüş davranışını korur. `TERMINATED` ofis approval veya normal aktivasyonla yeniden açılamaz.
- Başvuru kaynağı `offices.creation_source` alanına güvenilir server-side oluşturma akışından atanır: Admin rotası `BRAND_ADMIN_DIRECT`, Broker rotası `BROKER_APPLICATION`. İstek gövdesindeki kaynak değeri kullanılmaz; `creation_mode` broker oluşturma yöntemidir, `management_model` ofis modelidir.
- Dış başvuru `SETUP` olarak kaydedilir. Brand Admin ticari planı atadıktan sonra başvuruyu `PENDING_APPROVAL` durumuna gönderir; onay sırasında eksik subscription mevcut `AssignSubscription` action'ıyla kurulur, ardından ticari ilişki ve ofis aktivasyon akışları çalışır. Ret `SETUP` durumuna döner.
- `creation_source` eski ofisler için nullable bırakılmıştır; migration mevcut değerleri değiştirmez. Kaynağı kanıtlanamayan kayıtlar otomatik sınıflandırılmaz, submit/ready/activate geçişleri reddedilir ve elle incelenmelidir.

## Müşteri ve aktivite

- Customer üzerinde BUYER/SELLER/TENANT/LANDLORD rolü tutulmaz; ticari rol RequestFile.request_type ile oluşur.
- Aynı Customer için farklı zamanlarda birden çok BUY/SELL/RENT/LEASE_OUT/TRANSFER talebi açılabilir.
- Telefon/e-posta/vergi no/kimlik referansı normalize veya HMAC hash edilerek olası duplicate uyarısı üretilir; otomatik merge yapılmaz.
- Aktivite yalnız görünür müşteri ve aynı danışmana ait Talep/Hizmet Dosyasıyla bağlanabilir.

## Data Havuzu ve claim

- Data Havuzu yalnız iş fırsatı paylaşımıdır; Kazanç Havuzu değildir.
- Bir PoolRecord aynı anda yalnız bir aktif claim taşır.
- Aktif claim üst sınırı, ilk temas penceresi, claim süresi, otomatik release ve release yetkileri tarihçeli `PoolClaimPolicy` kaydından okunur.
- İlk temas penceresi veya claim süresi dolan kayıt, aktif policy izin veriyorsa otomatik expire edilir ve yeniden AVAILABLE olur.
- Claim'den RequestFile açıldığında claim ve PoolRecord CONVERTED olur.

## Talep ve hizmet

- RequestFile açılırken aktif çalışma modeli `work_model_snapshot` alanına alınır.
- Hizmet paketi marka tarafından tanımlanır; ilk paketler REMOTE_SUPPORT, ONE_TO_ONE_SUPPORT ve EXPERT_SERVICE'tir.
- Fiyat/tutar/oran kod veya enum içine gömülmez; tarihçeli ServicePricingPolicy ya da teklif üzerindeki açık değer kullanılır.
- ServiceOffer yalnız aktif veya teklif aşamasındaki RequestFile ve aktif ServicePackage üzerinden oluşturulur.
- Revizyon eski teklifi değiştirmez; yeni version ve parent_offer_id kaydı açar. ACCEPTED teklif revize edilmez.
- ServiceFile yalnız ACCEPTED ServiceOffer'dan doğar ve RequestFile başına yalnız bir aktif Hizmet Dosyası olabilir.
- Mülk sahibi hizmeti (`OWNER_SERVICE`) kabul edildiğinde aynı marka, ofis ve müşteri kapsamını taşıyan tek bir `Property` kaynak kaydı oluşturulur. Bu kayıt Portföy/İlan değildir; bağımsız bir kullanıcı rotası veya yönetim yüzeyi sunmaz.
- COMPLETED/CANCELLED hizmet dosyası aktif anahtarını bırakır; tüm durum değişimleri tarihçe ve audit üretir.

## Faz kapısı

Property Core yönetimi, Portfolio, Listing, Marketplace, Appointment, Showing, ticari Offer, Transaction, final ServiceFee, fatura/tahsilat, RevenueDistribution ve gerçek Kazanç Havuzu hareketleri Faz 3 kapsamında değildir. Mülk sahibi kabul akışındaki tekil `ServiceFile → Property` kaynak ilişkisi, bu ileri fazların yerine geçmez.

## Faz 3C / 3C.1 dosya ve aktör kuralları

- Talep Dosyası yalnız Satın Almak (`BUY`), Kiralamak (`RENT`) ve Devir Almak (`TAKEOVER`) ihtiyacını taşır. Hizmet akışı Satmak (`SELL`), Kiraya Vermek (`LEASE_OUT`) ve Devretmek (`TRANSFER_OUT`) yönlerini kullanır.
- Consultant Talep/Hizmet akışında kendi aktif ofisi ve kendi profesyonel kaydıyla çalışır. Brokerın ofisi aktif üyeliğinden otomatik gelir ve yalnız o ofisin aktif danışmanına atama yapılabilir. Brand Admin marka kapsamındaki ofis ve danışmanı seçebilir.
- Broker Talep Dosyası girişini danışmana atarsa RequestFile oluşur; Data Havuzuna bırakırsa danışmansız, `AVAILABLE` ofis PoolRecord kaydı oluşur. Yeni müşteri aynı transaction içinde doğru ofise bağlanır.
- Brand Admin tüm marka ofislerinin Data Havuzunu görür ve seçtiği yetkili ofis adına kayıt ekler. Broker yalnız kendi ofisine kayıt ekler, havuzda bırakır veya aktif ofis danışmanına mevcut claim policy ile atar. MAXIMUM Consultant yalnız kendi ofisine kayıt ekler ve policy ile claim eder. ALFA ortak havuzu görmez, eklemez ve claim etmez.
- Başka ofis kimliğinin POST ile gönderilmesi kapsamı genişletmez; backend aktif üyelik ve marka kapsamını yeniden doğrular.
- Yeni ofis kodu kullanıcıdan istenmez, sistem tarafından benzersiz üretilir ve düzenlenemez. Mevcut kodlara veri dönüşümü uygulanmaz.
- Permission verilen özellik menüde tıklanabilir route olarak sunulur ve backend aynı permission ile izin verir. Permission veya çalışan route bulunmayan placeholder kullanıcıya kullanılabilir özellik gibi gösterilmez.
- Profesyonel ticari ekranları `ACTIVE`, `MONTHLY_FIXED`, `BOOLEAN`, `QUOTA`, entitlement key veya test plan adı gibi teknik değerleri göstermez; Türkçe durum, dönem, kullanım hakkı, ücret ve pay karşılığını gösterir. Veri ve ticari hesaplama kuralları değiştirilmez.
- Gelecekte nihai müşteri talebi gayrimenkul/taşınmaz bölgesinden uygun veya en yakın hizmet veren ofise, ardından Broker/ofis sorumluluğuna yönlenecektir. Bu faz public başvuru veya gerçek geo-routing üretmez.

## Faz 3C.3 ayar ve kullanıcı yönetimi kuralları

- Marka yöneticisi yalnız backend karşılığı bulunan sistem, marka ve Data Havuzu politika alanlarını değiştirebilir. Ortam/framework bilgisi, marka slug'ı, ofis sayısı ve dosya sayaçları değiştirilemez.
- Rol yönetimi mevcut rol izin kümesini etkin/pasif hale getirir; bir role kayıtlı olmayan yeni izin verilemez ve kullanıcıya özel izin override'ı yoktur.
- Son aktif marka yöneticisinin rolü kaldırılamaz veya hesabı askıya/pasife alınamaz. Kullanıcı kendi kritik yönetim erişimini kaldıramaz.
- Kullanıcı durumu `ACTIVE`, `SUSPENDED`, `INVITED` veya `PASSIVE` olabilir ve yalnız kimlik doğrulama/panel erişimini belirler. Professional, onboarding, çalışma modeli ve üyelik durumlarını değiştirmez.
- Sistem, marka, havuz politikası, kullanıcı durumu, rol atama/kaldırma ve rol izin değişiklikleri ayrı audit aksiyonları üretir.

## Üye kimliği, profesyonel başvuru ve müşteri dosyası erişimi (2026-10-19)

- Her yeni kayıt ve profesyonel daveti `MEMBER` temel hesabını korur. Açıkça yetkilendirilmiş Broker/Danışman daveti ayrıca Professional ve onboarding ilişkilerini kurabilir; `User.role` Broker/Danışman olarak değiştirilmez. Kendi kendine kayıt sırasında profesyonel veya marka/ofis üyeliği oluşturulmaz.
- Geçiş dönemindeki eski profesyonel hesaplar da `User.role` alanı topluca değiştirilmeden temel üye alanı ve üye izinlerini kullanabilir; profesyonel erişimleri geçerli scoped ilişkilerden ayrıca çözülür.
- Üye hesabı kalıcıdır. Broker/Danışman erişimi, `User.role` değerini değiştirerek değil, ilgili Professional türü ve tarih/geçerlilik kapsamı içindeki marka/ofis üyeliklerinden çözülür. Operasyon rotaları ayrıca aktif Professional ve aktif ofis üyeliği ister. Eski kayıtlar otomatik düşürülmez veya doğrulanmış sayılmaz.
- Broker ve Danışman adayları `ProfessionalApplication` ile kalıcı başvuru yapar. Onay yalnız `ONBOARDING` aşamasını açar; tek başına Professional, marka/ofis üyeliği, çalışma modeli, ticari anlaşma veya operasyon yetkisi oluşturmaz. Ret gerekçesi ve review audit'i saklanır. ADR-039 yönlendirmesi korunur: Broker ve marka geneli Danışman başvurularını Marka Yöneticisi; belirli ofis Danışman başvurusunu o ofisin aktif Broker'ı inceler.
- Müşteri dosyası görünürlüğü yalnız aktif `CustomerAccountLink` veya dosyaya bağlı `FileParty` ilişkisiyle açılır. E-posta benzerliği hesap ile CRM kaydını otomatik bağlamaz. Marka yetkilisi açık CRM kaydı seçip incelemeyi onaylar; bekleyen bağlantı hiçbir müşteri verisi açmaz.
- Üye kendi talebini mevcut `RequestFile` yaşam döngüsünde ofis/profesyonel/model ataması olmadan açabilir. İşletme ataması yapılana kadar ofis ve profesyonel operasyonu başlatılmış sayılmaz.
- Üye yalnız izin verilen müşteri durumlarını ve kendisinden istenmiş Hizmet Dosyası belgelerini görür/sunar. Dosya iç notları ve profesyonel finans verileri müşteri görünümüne dahil edilmez. Bu paket mevcut Transaction domaini üretmez.
- `FileParty` alıcı, satıcı, kiracı, kiraya veren, devreden ve devralan rollerini dosya kapsamında tutar; roller genel kullanıcı rolü değildir. Bir hesap farklı dosyalarda farklı roller taşıyabilir ve ayrıca profesyonel olabilir.
- Profesyonel başvurusunun `ONBOARDING` aşamasını var olan profesyonel oluşturma, ticari anlaşma, belge ve atama zincirine bağlayan ortak tamamlama/yetkilendirme ekranı henüz yoktur. Başvuru onayı aktif erişim vermez; bu boşluk kapanana kadar adayın mevcut admin/provisioning akışından güvenli şekilde tamamlanabildiği kanıtlanmış sayılmaz.

## Çalışma alanı ve işlem tarafı ayrımı (2026-10-25)

- Her hesap önce Üye / Nihai Müşteri çalışma alanına sahiptir. Bu alan; arayış, mülk ve hizmet dosyaları, randevu/gösterim, işlem, belge ve hesap güvenliği görünümünü içerir.
- Broker çalışma alanı, kullanıcıya genel rol etiketiyle değil Getmaks ile yapılan yürürlükteki broker–ofis/franchise anlaşması ve aktif ofis ilişkisiyle açılır. Broker, marka bütününde kendi yetkili ofisinin sahibi veya yöneticisi olarak çalışır.
- Danışman çalışma alanı, brokerın alt kullanıcı ilişkisiyle değil yürürlükteki OfficeMembership ve danışman anlaşmasıyla açılır. Danışman yalnız yetkili olduğu ofisin kapsamındaki paneli kullanır.
- Alıcı, satıcı, kiracı, mülk sahibi, devreden ve devralan; kullanıcı hesabı veya profesyonel panel türü değil, ilgili talep/hizmet/işlem dosyasındaki kalıcı taraf rolleridir.
- Stratejik iş ortakları marka adına, atanmış ihtiyaç veya işlem dosyasında destek veren yan profesyonellerdir. Marka, broker, danışman veya nihai müşteri erişimini devralmazlar; erişimleri görev ve veri paylaşımı kapsamıyla sınırlıdır.
- Menü ve panel görünürlüğü yalnız güncel anlaşma, üyelik, ofis kapsamı ve dosya atamasından hesaplanır. İstemci tarafındaki seçim erişim vermez.
- İşlem kapanışı, müşteriden doğan hizmet bedelinin ilgili hizmet/talep dosyası, ofis ve paylaşım sözleşmesi sürümlerine göre hak edişe dönüşmesine aday olaydır. Franchise bedeli ile aylık/yıllık ofis ödemeleri bu paylaşımın dışındadır; panel görünümü ve pay sahipliği kapsam bazlıdır.

# GETMAKS360 V2 — Ana İş Modeli, Yaşam Döngüleri ve Sistem Etkileşim Kuralları

**Belge türü:** İş modeli ve uygulama davranış sözleşmesi  
**İnceleme temeli:** Bu depodaki dokümantasyon, route, controller, model, domain action, migration ve feature testleri  
**Sınır:** Bu belge, var olan sistemi tarif eder ve hedef/eksik davranışları işaretler; kendisi yeni davranışın uygulanmış olduğuna kanıt değildir.

## 1. Nasıl okunmalı

- **Mevcut:** Route/action/model ve ilgili regresyon testi ile destekleniyor.
- **Kısmi:** Veri veya temel akış mevcut; kullanıcı yüzeyi, durum geçişi ya da entegrasyon zincirinin bir bölümü eksik.
- **Hedef:** İşletme sözleşmesinde olması beklenen ancak uygulamada kanıtlanmayan davranış.
- **Karar gerekli:** Dokümanlar arasında fark veya ürün kuralı belirsizliği var. Kod bu kararı kendiliğinden vermez.

Bir `GET` ekranı veya model ilişkisi tek başına yaşam döngüsünün tamamlandığını göstermez. Bir akışın “mevcut” sayılması için yazma sınırı, yetki/scope kontrolü, kayıt ve durum davranışı ile ilgili test kanıtı birlikte aranır. Belge içindeki dosya yolları proje köküne göredir.

## 2. Sistem omurgası ve sabit ayrımlar

```text
GETMAKS Brand
  └─ Office ── aktif Broker yöneticisi
       └─ aktif OfficeMembership ile bağlı Consultants
            └─ WorkModel: MAXIMUM | ALFA
                 └─ Customer → RequestFile → ServiceOffer → ServiceFile
                      └─ Property → Portfolio → Listing (pazaryeri yayını henüz yok)
                           └─ Transaction ve Finance (hedef; bu repoda yok)
```

- `Brand` politika ve ticari ilişki kapsamıdır; `Office` operasyonel kapsamdır; Broker Ofis yöneticisidir. Danışman Broker'ın alt organizasyonu değil, aktif `OfficeMembership` ile Ofise bağlı profesyoneldir.
- MAXIMUM ve ALFA yalnız danışman `WorkModel` değerleridir; marka, rol veya ofis türü değildir.
- `RequestFile` ile `ServiceFile` farklı iş niyetlerini ve durum geçmişlerini taşır. Müşteri rolü Customer üzerinde değil talep/hizmet bağlamında belirlenir.
- `CommercialAgreement`, `SubscriptionPlan`, `ChargePolicy`, `PlanEntitlement`, `UsageEvent` ve `ChargeAccrual` farklı sorumluluklardır. İlişki türü, fiyatlama modeli/ödeme periyodu ve danışman çalışma modeli birbirinin yerine kullanılamaz.
- `DataPool` müşteri/talep fırsatı erişim alanıdır; `RevenuePool` finansal katkı ve dağıtım alanıdır. Birindeki kayıt ötekine dönüşmüş sayılmaz.
- Aktivasyon, tahakkuk, fatura, tahsilat ve gelir dağıtımı farklı olaylardır. Mevcut `ChargeAccrual` fatura/tahsilat değildir.
- Değerler kod içine sabitlenmez: para minor-unit integer, oran basis-point integer ve ISO para birimiyle tutulur; geçerli fiyat/ücret/politika kayıtlarından okunur.

## 3. Aşama sözleşmeleri

### 01 — Marka ve kurumsal yönetim

- **Amaç:** Marka kapsamını, kullanıcı rollerini/izinlerini ve kurumsal ayarları yönetmek.
- **Aktörler:** `BRAND_ADMIN`; diğer roller kendi izin ve operasyon scope'ları ile sınırlıdır.
- **Ekran/eylem:** `/admin` dashboard; `/admin/users`, `/admin/users/{user}`, `/admin/roles`, `/admin/permissions`, `/admin/settings`, `/admin/audit`. Ayar, rol ve kullanıcı işlemleri ilgili PATCH/POST rotalarından yapılır.
- **Zorunlu veri:** Marka adı/durumu gibi beyaz listedeki alanlar; rol/durum değişiminde hedef kayıt ve doğrulanmış eylem. Slug, ofis sayısı, sayaçlar ve çalışma ortamı salt okunurdur.
- **Kayıt/model:** `Brand`, `User`, `RolePermissionOverride`, `SystemSetting`, `AuditLog`; merkezi `RolePermissionRegistry` tek izin kaynağıdır.
- **Durum/geçiş:** Marka için mevcut `BrandStatus`; User için `ACTIVE`, `SUSPENDED`, `INVITED`, `PASSIVE`. Rol/izin atamaları merkezi rol kümesi içinde yapılır. Son aktif marka yöneticisinin rol/durumu ve kritik sistem izinleri kilitlidir.
- **Geçiş koşulu/iş kuralı:** Menü gizleme yetki sayılmaz; route/controller/action backend'de izin ve kapsam doğrular. Override yalnız mevcut rol iznini kapatır; yeni rol/izin veya kullanıcıya özel izin üretmez.
- **Yetki:** Brand Admin marka kapsamını yönetir; Broker/Consultant admin kullanıcı/rol/ayar ekranlarını açamaz.
- **Etkiler:** Değişiklikler sonraki admin ekranları ve kimlik doğrulama/authorization davranışını etkiler; User durumu Professional/onboarding/üyelik durumunu değiştirmez.
- **Hata/geri dönüş:** Yetkisiz işlem reddedilir; son admin ve kilitli izin silinemez; audit geçmişi korunur. Başarısız işlemde kısmi değişiklik olmaması transaction/test ile güvenceye alınır.
- **Kabul kanıtı:** `BrandAdminCanManageRolePermissionsTest`, `RolePermissionChangesAreAuditedTest`, `SettingsChangesAreAuditedTest`, `LastBrandAdminCannotBeRemovedTest`, `LastBrandAdminCannotBeSuspendedTest`, `UnauthorizedUserCannotAccessAdminSettingsTest`, `UnauthorizedUserCannotManageSettingsTest`.
- **Mevcut kod:** `routes/web.php`; `app/Http/Controllers/Admin/{AdminDashboardController,UserController,RoleController,PermissionController,SettingsController,AuditController}.php`; `app/Core/Authorization/{RolePermissionRegistry,Actions/*}.php`; `app/Core/Settings/*`; `app/Models/{Brand,User,SystemSetting,RolePermissionOverride,AuditLog}.php`; ilgili `resources/views/admin/**`.
- **Eksik/belirsiz:** Harici kimlik sağlayıcı veya ayrıntılı erişim talebi akışı yok. Bildirim ayarları için çalışan backend ayarı yok; dokümana özellik gibi eklenmemeli.

### 02 — Ticari ilişki ve kuruluş modeli

- **Amaç:** Bir ofisin kim tarafından ve hangi kurumsal/ticari bağlamda kurulduğunu ayırt etmek.
- **Aktörler:** Brand Admin doğrudan Ofis kurar; Broker kaynaklı dış Ofis başvurusu ayrı inceleme yoludur.
- **Ekran/eylem:** Admin Ofis wizard'ı `/admin/offices/create`; broker franchise-ofis başvurusu `/broker/offices/create` ve `/broker/offices` üzerinden açılır. Başvuru ayrı Application tablosu değil, `Office` kaydı ve `creation_source` ile temsil edilir.
- **Zorunlu veri:** Ofis temel/iletişim bilgileri, başlangıç tarihi, oluşturma modeli, uygun broker kurulumu ve ticari plan/koşul girdileri. Alan seti route'un FormRequest'leriyle doğrulanır.
- **Kayıt/model:** `Office.creation_source` (`BRAND_ADMIN_DIRECT` / `BROKER_APPLICATION`), `creation_mode`, `OfficeMembership`, `CommercialAgreement`, `Subscription`; `BrokerEngagement` ayrıca broker ticari katılım modelini taşır.
- **Durum/geçiş:** Admin doğrudan oluşturması `SETUP` ve draft agreement/pending subscription kurar; broker başvurusunda `SETUP` ardından `PENDING_APPROVAL` incelemesi beklenir. Bu statüsel akış ve approval işlevi ayrı kavramlardır.
- **Geçiş koşulu/iş kuralı:** Kaynak sunucu tarafında atanır, request body'den kabul edilmez. Bilinmeyen/null geçmiş kaynaklı ofis tahminle sınıflandırılmaz. İlişki türü franchise/katılım kararıyla eş anlamlı değildir; her ilişki sözleşme verisiyle belirlenir.
- **Yetki:** Doğrudan kurulum ve approval yalnız marka yetkilisinde; başvuru kabul/ret işlemi mevcut approval rotalarının rolüyle sınırlıdır.
- **Etkiler:** Kaynak, Ofis readiness/approval yolunu; agreement/plan uyumu aktivasyon hazırlığını; broker üyeliği broker panel scope'unu belirler.
- **Hata/geri dönüş:** Kaynak sahteciliği ve bilinmeyen kaynak reddedilir; reddedilmiş dış başvuru kurulum durumuna döner. Transaction başarısızlığında Ofis, üyelik ve ticari kayıtlar yarım kalmamalıdır.
- **Kabul kanıtı:** `OfficeCommercialLifecycleTest`, `PhaseThreeOnboardingUxTest`, `ApprovalSemanticsTest`, `NewOfficeCodeGeneratedAutomaticallyTest`.
- **Mevcut kod:** `app/Domains/Office/Actions/{CreateOffice,CreateOfficeOnboarding,MarkOfficeReady,ActivateOffice}.php`; `OfficeCreationSource.php`; `app/Domains/Professional/Actions/{CreateBrokerAndAssignToOffice,AssignBrokerToOffice}.php`; `app/Models/{Office,BrokerEngagement,CommercialAgreement}.php`; `routes/web.php`; `resources/views/admin/offices/**`, `resources/views/broker/offices/**`.
- **Eksik/belirsiz:** Ayrı ve genel broker/consultant aday başvuru domaini yok; broker franchise-ofis başvurusu ise yukarıdaki Office route'u üzerinden vardır. `management_model`, `creation_mode`, `creation_source` ve `relationship_type` farklı eksenlerdir; ürün dili ve franchise dışı katılım biçimi için ayrıca karar gerekir.

### 03 — Ofis yaşam döngüsü

- **Amaç:** Kurulumu, readiness, aktivasyon, askıya alma, yeniden etkinleştirme ve terminal sonlandırmayı güvenli sırada yönetmek.
- **Aktörler:** Brand Admin; dış başvuruda approval yetkili admin'i.
- **Ekran/eylem:** `/admin/offices`, `/admin/offices/create`, `/admin/offices/{office}` ve `ready`, `activate`, `submit-approval`, `reject-approval`, `approve-and-activate`, `suspend`, `terminate`, `reactivate` eylemleri.
- **Zorunlu veri:** Ofis temel bilgisi, marka kapsamı, kaynak doğrulaması, aktif broker ilişkisi, uygun commercial agreement/subscription ve readiness checklist.
- **Kayıt/model:** `Office`, `OfficeMembership`, `CommercialAgreement`, `Subscription`, `ChargeAccrual`, `StatusHistory`, `AuditLog`.
- **Durum/geçiş:** Temel hat `DRAFT → SETUP → READY → ACTIVE`; dış başvuru `SETUP → PENDING_APPROVAL → ACTIVE` veya retle `SETUP`; `ACTIVE ↔ SUSPENDED` yalnız tanımlı aksiyonla; `TERMINATED` terminaldir.
- **Geçiş koşulu/iş kuralı:** `OfficeSetupReadiness` READY öncesi, `ActivateOffice` aktivasyonda tekrar kontrol yapar. Aktifleştirme uyumlu agreement/subscription'ı aktive eder. Billing start ve geçerli charge policy varsa başlangıç tahakkuku hazırlayabilir; fatura kesmez.
- **Yetki:** `/admin/*` ve admin izinleri; ofis sahibi veya broker tek başına marka onay/aktivasyon yetkisi alamaz.
- **Etkiler:** ACTIVE olması brokerın ofis panel bağlamını ve sonraki üyelik/operasyon uygunluğunu açar. Askıya alma/sonlandırmanın müşteri dosyalarını otomatik taşıdığına veya sildiğine dair davranış yoktur.
- **Hata/geri dönüş:** Eksik readiness, uyumsuz agreement/plan, yanlış kaynak veya terminal durum geçişi reddedilir. Aktivasyon transaction içinde olduğundan ticari yan etkilerle ofis durumunun atomikliği korunmalıdır.
- **Kabul kanıtı:** `OfficeCommercialLifecycleTest`, `PhaseThreeOnboardingUxTest`; `OfficeSetupReadiness` ve `ActivateOffice` aksiyonlarının kontrolleri.
- **Mevcut kod:** `app/Domains/Office/{OfficeStatus,OfficeCreationSource}.php`, `Actions/*Office*.php`, `Services/OfficeSetupReadiness.php`; `app/Http/Controllers/Admin/OfficeController.php`; `Office` modeli; `offices`/agreement/subscription migration'ları; `resources/views/admin/offices/**`.
- **Eksik/belirsiz:** Suspend/terminate sonrası devam eden abonelik tahakkukları, servis dosyası sorumluluğu ve geri açmada ticari ilişki şartları iş sahibi düzeyinde netleştirilmeli; uygulama etkileri kod/test bazında her kombinasyonda doğrulanmalı.

### 04 — Broker kimliği ve ofis üyeliği

- **Amaç:** Broker kullanıcı hesabı, profesyonel kimliği, marka üyeliği ve Ofis yöneticilik geçmişini ayrı, tarihçeli kayıtlarda tutmak.
- **Aktörler:** Brand Admin broker oluşturur/seçer/atar/değiştirir; davetli Broker hesabını davet akışında tamamlar.
- **Ekran/eylem:** `/admin/brokers`, `/admin/brokers/create`, `/admin/brokers/{professional}`, Ofis detayındaki broker ata/değiştir; `/invitation/accept/{token}`.
- **Zorunlu veri:** Ad, benzersiz e-posta, telefon, atanacağı Ofis ve başlangıç tarihi; dolu ofiste değişiklik için açık onay ve gerekçe/etkin tarih kuralları.
- **Kayıt/model:** `User`, `Professional`, `BrandMembership`, `OfficeMembership`, `BrokerInvitation`, `BrokerEngagement`, `BrokerCommercialAuthority`.
- **Durum/geçiş:** User davet/erişim durumu ile Professional lifecycle ayrı tutulur. Ofis broker değişiminde eski aktif membership kapanır (`ended_at`), yenisi açılır (`started_at`); `broker_active_key` tek aktif broker kısıtıdır.
- **Geçiş koşulu/iş kuralı:** Yeni broker kurulumu tek transaction; açık değişim onayı yoksa dolu ofis değişmez. Brokerin operasyonal kapsamı aktif Ofis üyeliğinden türetilir; danışman ilişkisi doğrudan `broker_id` değildir.
- **Yetki:** Brand Admin broker yaşam döngüsünü marka/ofis kapsamıyla yönetir; broker kendi ofis kapsamı dışında yalıtılır.
- **Etkiler:** Yeni aktif broker yönetim ve operasyon paneline erişir, commercial authority ile sınırlı yönetim yetkisi alır. Değişim danışman membership/modeli ve tarihsel operasyon dosyalarını transfer etmez.
- **Hata/geri dönüş:** E-posta tekrarı, uyumsuz/aktif olmayan broker, aktif slot çakışması veya onaysız replacement transaction'ı durdurur; eski membership silinmez.
- **Kabul kanıtı:** `BrokerIdentityLifecycleTest`, `BrokerBrandOfficeLifecycleTest`, `OfficeCommercialLifecycleTest`, `PhaseThreeHierarchyUxTest`.
- **Mevcut kod:** `app/Domains/Professional/Actions/{CreateBrokerAndAssignToOffice,AssignBrokerToOffice,RemoveBrokerFromOffice,SetBrokerEngagement}.php`; `BrokerInvitationController`; `Admin/BrokerController`, `Admin/OfficeController`, `Broker/OfficeController`; ilgili modeller ve migrations; broker/admin Blade ekranları.
- **Eksik/belirsiz:** Davet e-postasının gerçek ortam sağlayıcısı, token süre/iptal operasyonu ve broker ayrıldıktan sonra Ofis operasyonlarının yetkili sorumlusu için ürün prosedürü ayrıca doğrulanmalı.

### 05 — Ticari sözleşmeler ve ücretler

- **Amaç:** Kimin kime hangi ticari ilişkinin hangi şartlarla bağlandığını, hakları ve ücret tahakkuk kuralını ayrı kayıtlarda ifade etmek.
- **Aktörler:** Brand Admin ana plan/politika ve anlaşmaları yönetir; Broker yalnız etkin `BrokerCommercialAuthority` sınırlarında plan/istisna atayabilir.
- **Ekran/eylem:** `/admin/commercial/{section}`, `/admin/settings`; broker `/broker/commercial`; danışman `/consultant/commercial-terms`.
- **Zorunlu veri:** Taraflar, ilişki türü, plan/kapsam, yürürlük ve isteğe bağlı billing başlangıcı; charge amount/cycle/tax veya rate verileri politika kaydından; broker için yetki bayrakları.
- **Kayıt/model:** `CommercialAgreement`, `SubscriptionPlan`, `Subscription`, `ChargePolicy`, `PlanEntitlement`, `CommercialException`, `BrokerCommercialAuthority`, `RevenuePolicy`, `UsageEvent`, `ChargeAccrual`.
- **Durum/geçiş:** Agreement/charge/exception status ve tarihçeli aktif anahtarlar; subscription enumu `PENDING/ACTIVE/PAST_DUE/SUSPENDED/CANCELLED/EXPIRED` değerlerini kullanır. Üyelik/ilişki dönemi ile ücret ödeme periyodu aynı alanın anlamı değildir.
- **Geçiş koşulu/iş kuralı:** İlişki tipi (Brand→Office, Brand→Consultant, Office→Consultant), çalışma modeli (MAXIMUM/ALFA), plan ürünü, ödeme periyodu ve `ChargePolicy` ayrı eksenlerdir. `RevenuePolicy` oran parametresidir, gelir hesabı değildir. İndirim/waiver ana fiyatı ezmez; standart şart snapshot'ı korunur.
- **Yetki:** Marka ana fiyat/politika sahibi; Broker yalnız explicit authority ile dar yetki; danışman ticari şartları salt okunur görür.
- **Etkiler:** Atanmış plan ve entitlement aktivasyon/readiness ile kullanım uygunluğunu etkiler. `UsageEvent → ChargeAccrual` tahakkuk girdisi oluşturabilir.
- **Hata/geri dönüş:** Taraf, plan ve agreement uyumsuzluğu; aktif tarih çakışması; limit aşımı yetkisizliği; idempotency key çakışması reddedilir. Tarihsel koşul snapshot'ı sonradan değişmez.
- **Kabul kanıtı:** `PhaseThreeGovernanceTest`, `CommercialTermsUseHumanReadableLabelsTest`, `TechnicalEntitlementCodesAreNotExposedToConsultantTest`, `OfficeCommercialLifecycleTest`.
- **Mevcut kod:** `app/Domains/Commercial/Actions/*`, `BrokerCommercialAuthorityEvaluator`, `CommercialTermsPresenter`; `Subscription/Actions/*`; `Admin/CommercialController`, `SubscriptionPlanController`, `Broker/CommercialController`, `Consultant/CommercialController`; commercial models/migrations/views.
- **Eksik/belirsiz:** Franchise lisans bedeli/royalty, marka katılım modeli ve müşteri hizmet bedelinin hangi taraflardan hangi olayda doğacağına dair uçtan uca onaylı hesap kuralı bu aşamada tamamlanmış değildir. Aylık/yıllık seçimi evrensel ticari ilişki zorunluluğu değildir.

### 06 — Danışman katılımı ve üyeliği

- **Amaç:** Danışman hesabı, profesyonel profili, marka/ofis üyeliği, çalışma modeli ve gerçek ticari atamasını tutarlı kurmak.
- **Aktörler:** Brand Admin marka kapsamında; Broker kendi aktif Ofisinde ve authority izinleri dahilinde; danışman davet/onboarding adımında kendi profilini tamamlar.
- **Ekran/eylem:** `/admin/consultants`, `/admin/consultants/create`, `/admin/consultants/{professional}`, broker `/broker/consultants/**`, `/consultant/onboarding`, davet kabul rotaları.
- **Zorunlu veri:** Kimlik/iletişim, marka/ofis, membership başlangıcı, MAXIMUM/ALFA modeli, mevcut aktif `SubscriptionPlan`, onboarding'de gerekli profil alanları.
- **Kayıt/model:** `User`, `Professional`, `BrandMembership`, `OfficeMembership`, `ProfessionalWorkModel`, `Subscription`, `CommercialAgreement`, opsiyonel `BrokerInvitation`, `StatusHistory`, `AuditLog`.
- **Durum/geçiş:** `ProfessionalStatus` ile `OnboardingStatus`, membership, work-model ve subscription durumları ayrı eksenler. Doğrudan yetkili oluşturma approval üretmez; aday başvurusu domaini mevcut değildir.
- **Geçiş koşulu/iş kuralı:** Aktivasyon `ActivationReadiness` checklist'i tamamlanmadan olmaz. Tek aktif Ofis üyeliği; gerçek plan seçimi; brokerın ofis scope'u ve authority kontrolü gerekir. Üyelik transferi açık action ile tarihçeli gerçekleşir; müşteri/dosyalar otomatik taşınmaz.
- **Yetki:** Admin marka/ofis scope'u; broker yalnız kendi ofisi; danışman yalnız kendi kayıt/profil görevleri.
- **Etkiler:** Aktiflik operational middleware'ı; membership ofis scope'unu; work model data erişimini; commercial assignment hakları/ücretleri etkiler.
- **Hata/geri dönüş:** Duplicate e-posta, etkin üyelik/plan eksikliği, terminated profesyonel veya eksik readiness reddedilir. Transaction rollback ile yarım User/Professional/membership oluşmamalıdır.
- **Kabul kanıtı:** `PhaseThreeOnboardingUxTest`, `ConsultantIdentityLifecycleTest`, `ConsultantOfficeTransferTest`, `BrokerIdentityLifecycleTest`, `ApprovalSemanticsTest`.
- **Mevcut kod:** `app/Domains/Professional/Actions/{InviteConsultant,CreateConsultantInvitation,ActivateConsultant,CompleteConsultantOnboarding,TransferConsultantToOffice,SuspendProfessional,TerminateProfessional}.php`; `Services/ActivationReadiness.php`; admin/broker/consultant controllers, requests, models, migrations, Blade wizard ve detayları.
- **Eksik/belirsiz:** Danışman aday başvuru ve bir ofis/broker'a aday yönlendirme akışı yok. Broker için mevcut başvuru yalnız franchise-ofis kuruluş başvurusudur; genel broker aday/katılım başvurusu ayrı bir akış değildir. Hesap kapatma ile yasal/finansal saklama süreleri ayrı veri yönetişimi kararı gerektirir.

### 07 — Danışman çalışma modeli: MAXIMUM ve ALFA

- **Amaç:** Danışmanın operasyonel capability ve gelir politika kapsamını tarihçeli şekilde belirlemek.
- **Aktörler:** Brand Admin; broker yalnız `can_manage_work_model` authority'si varsa talep/atama sınırında; model değişikliği onay rotası admin tarafındadır.
- **Ekran/eylem:** Admin/broker danışman detayları ve model değişim ekranları; `/admin/consultants/{professional}/work-model/change`, `/admin/work-model-change/{changeRequest}/approve`, broker `work-model-change` isteği.
- **Zorunlu veri:** Danışman, hedef model, Ofis üyeliği, yürürlük tarihi ve gerekliyse change request onayı.
- **Kayıt/model:** `ProfessionalWorkModel`, `WorkModelChangeRequest`; dosyalarda `work_model_snapshot`; `WorkModelPolicy` capability matrisi ve `RevenuePolicy` parametreleri.
- **Durum/geçiş:** Model satırları `PROPOSED → ACTIVE → ENDED`; değişiklik geçmiş kaydı overwrite etmez ve ileri tarihli olabilir.
- **Geçiş koşulu/iş kuralı:** İki model de CRM/talep/hizmet yaşam döngüsünü kullanır. Kodda MAXIMUM Data Havuzu capability'sine sahip; ALFA Data Havuzu erişim/claim yapamaz ve Kazanç Havuzu payı sıfırdır. Geçmiş dosya snapshot'ı model değişiminden etkilenmez.
- **Yetki:** Route middleware + `WorkModelPolicy` + aktif ofis/scope doğrulaması; yalnız menü saklamak yeterli değildir.
- **Etkiler:** Yeni Data Havuzu erişimi ve yeni talep/hizmet dosyalarının snapshot'ı; mevcut dosya ve geçmiş ticari kayıtlar değişmez.
- **Hata/geri dönüş:** Eski/başka ofis üyeliği, yetkisiz rol, geçersiz effective date veya ALFA Data Havuzu aksiyonu reddedilir.
- **Kabul kanıtı:** `AlfaConsultantCannotAccessDataPoolTest`, `AlfaConsultantCannotCreatePoolRecordTest`, `MaximumConsultantSeesOwnOfficePoolTest`, `MaximumConsultantCannotAccessOtherOfficePoolTest`, `ApprovalSemanticsTest` ve governance work-model testleri.
- **Mevcut kod:** `WorkModelPolicy`, `AssignProfessionalWorkModel`, `ChangeProfessionalWorkModel`, `ApproveWorkModelChange`; `EnsureDataPoolAccess`, `DataPoolVisibility`; `ProfessionalWorkModel`, `RequestFile`, `ServiceFile`, `RevenuePolicy`.
- **Eksik/çelişki:** Önceki kullanıcı tarafından verilen ana harita Alfa için “kurallı ortak havuz erişimi” ifadesi kullanırken bağlayıcı `ADR-004`, `02_BUSINESS_RULES.md`, `WorkModelPolicy` ve testler ALFA erişimini yasaklıyor. Bu belge mevcut ADR/kodu esas alır; Alfa Data Havuzu erişimi için yeni ürün kararı gerekir. “Ekip çalışması” yetenekleri de ayrı capability ve kapsam olarak henüz net değil.

### 08 — Müşteri ve ilişki yönetimi

- **Amaç:** Müşteri kimliğini, iletişim geçmişini ve talep/hizmet niyetlerini operasyon dosyalarına bağlı yönetmek.
- **Aktörler:** Yetkili Brand Admin, kendi scope'undaki Broker ve aktif Consultant.
- **Ekran/eylem:** `/operations/customers`, `/operations/customers/create`, `/operations/customers/{customer}`; aktivite ekleme; talep/hizmet oluşturma ve Data Havuzu akışları.
- **Zorunlu veri:** Müşteri kimlik/iletişim ve türü; işlem niyeti ayrı Request/Service flow'da; ofis/professional server-side scope'dan gelir.
- **Kayıt/model:** `Customer`, `CustomerActivity`, `RequestFile`, `ServiceOffer`, `ServiceFile`; ihtiyaç halinde `PoolRecord/PoolClaim`.
- **Durum/geçiş:** Customer kendi status'u; talep `DRAFT/QUALIFYING/ACTIVE/SERVICE_OFFERED/SERVICE_ACCEPTED/CONVERTED_TO_SERVICE/LOST/CLOSED`; teklif ve hizmet kendi enumlarını kullanır. BUY/RENT/TAKEOVER talep yönleri; SELL/LEASE_OUT/TRANSFER_OUT mülk sahibi hizmet yönleridir.
- **Geçiş koşulu/iş kuralı:** Duplicate eşleşmesi uyarıdır, otomatik merge değildir. İletişim PII için normalize/HMAC/encrypted cast kararları uygulanır. RequestFile aktif çalışma modeli snapshot'ı taşır. ServiceFile yalnız kabul edilmiş ServiceOffer'dan doğar; talep ve mülk sahibi dosyası eşitlenmez.
- **Yetki:** `OperationalAssignment`, `CustomerVisibility`, `RequestFileVisibility`, `ServiceFileVisibility`; Broker/Consultant ofisi aktif üyelikten çözülür; Brand Admin yetkili mark/ofisi seçer.
- **Etkiler:** Talep/hizmet teklifine, olası Property kaynağına ve Data Havuzu claim dönüşümüne etkisi vardır. Müşteri aktivitesi ilgili dosya ve timeline'a bağlanır.
- **Hata/geri dönüş:** Başka marka/ofis/profesyonel kapsamı 404/403 ile korunur; ret/iptal/kayıp durumları audit/history ile tutulur; duplicate otomatik birleştirme yaratmaz.
- **Kabul kanıtı:** `PhaseTwoCustomerTest`, `PhaseTwoRequestFileTest`, `PhaseTwoServiceTest`, `CreateRequestFileWithNewCustomerTest`, `CreateRequestFileWithExistingCustomerTest`, `CreateOwnerServiceFlowWithNewCustomerTest`, `CreateOwnerServiceFlowWithExistingCustomerTest`, `OperationalFileVisibilityTest`.
- **Mevcut kod:** `app/Domains/Customer`, `DataPool`, `RequestFile`, `Service` action/service sınıfları; Operations controllers/requests; Customer/Activity/RequestFile/ServiceOffer/ServiceFile modelleri; `/operations/**` rotaları ve Blade ekranları.
- **Eksik/belirsiz:** Müşteri rıza/iletişim tercihleri ve dış kanallı bildirim işleyişi kanıtlanmadı; nihai müşterinin public lead formu ve lokasyon bazlı ofis yönlendirme motoru yok.

### 09 — Portföy, ilan ve pazaryeri

- **Amaç:** Kabul edilmiş mülk sahibi hizmeti kapsamındaki Property kaydını Portföy ve taslak Listing akışına bağlamak.
- **Aktörler:** Operasyonel yetkiye sahip Brand Admin/Broker/Consultant, backend scope ve dosya görünürlüğü ölçüsünde.
- **Ekran/eylem:** ServiceFile detayından portföy oluşturma; `/operations/portfolios/{portfolio}`; ilanın oluşturulması ve `/operations/listings/{listing}` görüntüsü. İlgili POST rotaları `portfolios.store`, `listings.store`.
- **Zorunlu veri:** Kaynak ServiceFile + Property; Listing aşamasında imzalı aktif ServiceContract, aktif property-number authorization ve taşınmaz numarası; başlık/açıklama/fiyat/currency inputları validasyona tabi.
- **Kayıt/model:** `Property`, `Portfolio`, `Listing`; ServiceFile, ServiceContract, ServiceAuthorization ile ilişkiler.
- **Durum/geçiş:** Portföy oluşturma aktif portfolio kaydı kurar; listing oluşturma `DRAFT` başlatır. Listing enumunda `ACTIVE/PAUSED/CLOSED` değerleri mevcut olsa da bunlara geçiş action/route'u bu incelemede bulunmadı.
- **Geçiş koşulu/iş kuralı:** Property kaynak kayıt; Portfolio/Listings aynı ServiceFile/Customer/Office/Brand kapsamını devralır. Listing yaratımı duplicate active listing'i reddeder ve imzalı contract + `PROPERTY_NUMBER_RECEIVED` + dolu kayıt numarası arar.
- **Yetki:** `PortfolioVisibility`, `ListingVisibility`, `PropertyVisibility` ve operasyon middleware; admin marka, broker ofis, consultant kendi dosya scope'u.
- **Etkiler:** ServiceFile → Property → Portfolio → Draft Listing bağlantısı vardır. Public yayın, arama/eşleştirme ve lead üretimi bu zincirden sonra hedeflenen ama mevcut olmayan etkidir.
- **Hata/geri dönüş:** Property/contract/authorization eksikse Listing oluşmaz. Aktif duplicate portfolio/listing reddedilir. Yayın geri alma/ilan kapanışı için tamamlanmış lifecycle kanıtlanmadı.
- **Kabul kanıtı:** `ServiceFileCreatesPropertyTest`, `PortfolioListingFlowTest`; authorization scope için `OperationalFileVisibilityTest` ve ilgili görünürlük testleri.
- **Mevcut kod:** `app/Domains/Property`, `Portfolio`, `Listing`; `CreatePortfolio`, `CreateListing`; `Operations/{PropertyController,PortfolioController,ListingController}`; `resources/views/operations/{properties,portfolios,listings}`; property/portfolio/listing migration'ları.
- **Eksik/çelişki:** Tek MarketplacePublication/publication adapter, publish/unpublish rotası, dış portallarla senkronizasyon, müşteri lead/eşleştirme ve approval/publish politikası yok. `ServiceContract`/`ServiceAuthorization` modeli ve enumu var; onlar için operasyonel form/controller/route lifecycle kanıtı yok. ADR-056'nın tanımladığı ön koşul kodda ilan oluşturma guard'ına yansımış; sözleşme/yetki toplama süreci tam uygulanmış sayılmaz.

### 10 — Gayrimenkul işlem dosyası

- **Amaç:** Listing veya müşteri lead'inden tamamlanan satış/kiralama işine kadar tarafları ve kararı tek işlem yaşam döngüsünde izlemek.
- **Aktörler:** Hedefte Consultant ve Broker; gerektiğinde müşteri tarafı. Kesin başlatıcı ve Broker onayı halen ürün kararıdır.
- **Ekran/eylem:** Mevcut işlem dosyası, appointment, showing, offer/offer revision veya transaction ekran/rotası bulunmadı.
- **Zorunlu veri:** Hedef olarak müşteri/taraflar, kaynak Listing/Property, ofis/danışman, işlem türü, görüşme/gösterim/teklif/karşı teklif ve kapanış/iptal bilgisi; kesin zorunlu alanlar kararlaştırılmamıştır.
- **Kayıt/model:** `Transaction`, `MarketplaceLead`, `Appointment`, `Showing`, `Offer`, `OfferRevision` model/migration/domain bulunamadı. Mevcut `ServiceOffer` müşteri hizmet paketi teklifidir, gayrimenkul satın alma/satış teklifi değildir.
- **Durum/geçiş:** İşlem durumu ve kapanış enum/action'ı yok; hedef durum makinesi tanımlanmalıdır.
- **Geçiş koşulu/iş kuralı:** Listing/public lead bağlanması, yetkili teklif, taraf onayı, sözleşme ve close koşulları belirsizdir; bunlar kod varmış gibi yazılmaz.
- **Yetki:** Mevcut operational middleware yalnız genel role/aktif ofis/file-scope sağlar; işlem-özel yetki matrisi henüz yok.
- **Etkiler:** Tamamlanan transaction hedefte müşteri hizmet bedeli ve gelir paylaşımının kaynağı olacak; mevcut kod bu olayı üretmiyor.
- **Hata/geri dönüş:** Teklif revizyonu, geri çekme, başarısız görüşme, taraf ayrılması, iptal/iade ve duplicate close davranışları karara bağlanmamış ve test edilmemiş.
- **Kabul testi:** İşlem domainine özgü feature testi bulunamadı. Gerekli kabul zinciri; listing/lead scope'u, offer revision, concurrency/idempotency, onay yetkisi, close/rollback ve audit kapsamalıdır.
- **Mevcut kod:** Bu aşamada doğrudan dosya/route/action karşılığı yok. `ServiceOffer`/`ServiceFile` yalnız önceki hizmet aşamasıdır.
- **Durum:** **Hedef / kodlanmamış.** Faz kapısı ve ayrı uygulama talimatı gerekir.

### 11 — Gelir paylaşımı ve ön muhasebe

- **Amaç:** Sabit/usage/işlem bazlı tahakkukları gerçek faturalar, cari hesap, tahsilat, hakediş ve varsa Kazanç Havuzu hareketlerinden ayrı yönetmek.
- **Aktörler:** Hedefte Brand Finance/Admin ve yetkili finans rolleri; Broker fiyat/ana politika sahibi değildir. Gerçek aktör/yetki matrisi Finans fazında belirlenmelidir.
- **Ekran/eylem:** Admin commercial policy ekranları, tahakkuk/politika verisini gösterir. Invoice, cari, payment, earnings veya Revenue Pool hareket ekranı bulunmadı.
- **Zorunlu veri:** Plan/ücret/hak kayıtlarında plan, taraf, effective dates, tutar ve vergi/para birimi; gelecekte faturada borçlu, fatura kalemleri, vade; tahsilatta provider teyidi; dağıtımda işlem anı policy snapshot'ı gerekir. Bunların finans tarafı henüz hedef sözleşmedir.
- **Kayıt/model:** Mevcut `CommercialAgreement`, `Subscription`, `ChargePolicy`, `UsageEvent`, `ChargeAccrual`, `RevenuePolicy`; `Invoice`, `Receivable`, `Payment`, `ConsultantEarning`, `RevenueDistribution`, `PoolContribution`, `PoolPeriod`, `PoolDistribution` modelleri bu repoda yok.
- **Durum/geçiş:** `ChargeAccrual` PENDING/WAIVED gibi dar tahakkuk durumuna sahiptir. Invoice/payment/earning/pool status lifecycle yok.
- **Geçiş koşulu/iş kuralı:** Sabit ücretler agreement/billing tarihine göre; işlem bazlı gelir tamamlanan işlem ve işlem anındaki policy snapshot'ına göre hedeflenir. Fatura ancak uygun borç/tahakkuk ve yasal belge şartı ile; tahsilat yalnız ödeme sağlayıcı teyidiyle; dağıtım ayrı finansal kayıtlarla olmalıdır. Aktivasyon veya tahakkuk bunların hiçbirini otomatik tamamlamaz.
- **Yetki:** Mevcut broker yetkileri plan/istisna yönetimiyle sınırlı. Fatura ve ödeme yetkileri mevcut değil.
- **Etkiler:** Nihai müşteriden alınacak hizmet bedeli, Getmaks faturası; danışman hakediş faturası; ofis/marka/pay/havuz dağıtımı ayrı yönlerdir. Data Havuzu verisi finansal katkı sayılmaz.
- **Hata/geri dönüş:** Duplicate event idempotency; ödeme sağlayıcı başarısızlığı/tekrar callback'i; fatura iptal/düzeltme; iade ve yuvarlama için immutable reversal/adjustment kayıtları tasarlanmalıdır. Mevcut kodda bu kapsam uygulanmamıştır.
- **Kabul kanıtı:** Ticari policy için `PhaseThreeGovernanceTest` ve kullanım tahakkuk testleri mevcuttur; fatura/tahsilat/dağıtım için test/domain yok.
- **Mevcut kod:** `app/Domains/Commercial/Actions/{RecordUsageEvent,AssignRevenuePolicy,DefineChargePolicy}.php`; `app/Domains/Subscription/Actions/*`; ilgili models/migrations; `docs/03_FINANCE_RULES.md`.
- **Eksik/belirsiz:** Müşteri hizmet bedeli hesap tabanı, KDV/yuvarlama, fatura tarafı, sabit bedellerin ödeme periyodu, iptal/iade ve havuz period/distribution formülü kararları kapanmadan finans hesaplama kodlanmamalıdır.

### 12 — Ortak sistem kuralları: yetki, audit, bildirim, veri güvenliği ve entegrasyon testleri

- **Amaç:** Aşamalar arası güvenlik, izlenebilirlik, güvenilir kayıt ve tekrar üretilebilir kabul kanıtı sağlamak.
- **Aktörler:** Her aktör yalnız merkezi permission, rol, aktif kullanıcı ve operasyonel scope içinde; sistem komutları yalnız tanımlı scheduler/job yetkisiyle.
- **Ekran/eylem:** Role göre admin/broker/consultant layout'ları; audit listesi; login/davet; Data Pool policy. Dış sistem/Marketplace/ödeme entegrasyon yönetim ekranı doğrulanmadı.
- **Zorunlu veri:** Actor, scope, subject, before/after, gerekçe; PII için yalnız amaçla gerekli alanlar ve şifreli/normalize arama karşılıkları; job/event için idempotency/concurrency anahtarı.
- **Kayıt/model:** `AuditLog`, `StatusHistory`, `User`, `RolePermissionOverride`, olay sınıfları; `Customer` sensitive casts; `DocumentSequence`; scheduler claim expiry.
- **Durum/geçiş:** Authorization default-deny; user active check, role middleware, FormRequest/action scope; audit/status history durum geçişiyle birlikte yazılır. Event'lerin bazıları transaction commit sonrası dispatch edilir.
- **Geçiş koşulu/iş kuralı:** UI gizleme güvenlik değildir. Cross-brand/office/resource scope backend'de tekrar doğrulanır; hard delete yerine tarihçeli kapanış/terminal kayıt; file number transaction/lock; claim expiry scheduler overlap protection; idempotent usage.
- **Yetki:** `RolePermissionRegistry`, `EnsureActiveUser`, `EnsureRole`, `EnsureOperationalAccess`, `EnsureDataPoolAccess`, `OperationalAssignment`, domain visibility servisleri.
- **Etkiler:** Her domain yazımı audit/history, event listener/mail ve sonraki read model görünürlüğünü etkileyebilir. Sadece kodda bağlı yan etki belgeye “mevcut” olarak yazılır.
- **Hata/geri dönüş:** Yetki hatası, doğrulama hatası, concurrency çakışması, transaction rollback, dış servis timeout/tekrar deneme için ayrı testler gereklidir. Harici entegrasyon başarısızken başarı kaydı üretilmemelidir.
- **Kabul kanıtı:** `Unauthorized*`, `OperationalFileVisibilityTest`, Data Pool scope regresyonları, `ApprovalSemanticsTest`, `Review/PanelReviewControllerTest`, belge/numara ve lifecycle testleri. Tam suite'in bu görev sırasında çalıştırılması istenmedi ve çalıştırılmadı.
- **Mevcut kod:** `app/Core/{Authorization,Audit,Organization,Support}`; middleware; `app/Events/**`; `app/Console/Commands/ExpirePoolClaims.php`; `routes/console.php`; auth controllers/notification mail; tests/Feature.
- **Eksik/belirsiz:** İlan yayını, e-Devlet/e-imza, marketplace, ödeme ve muhasebe entegrasyon adaptörleri bulunmadı. Tüm domain actions için ortak idempotency/outbox garantisi varsayılamaz; event/mail listener eşleşmeleri ve queue retry politikaları ayrı ayrı denetlenmelidir.

## 4. Bağlayıcı olmayan ürün kararı kayıtları

Bu sözleşme mevcut kabul edilmiş kural ile yeni hedefi ayırır; çelişkiyi örtük biçimde çözmez:

1. **ALFA ortak Data Havuzu:** Kullanıcı tarafından paylaşılan üst iş haritasında kontrollü ortak havuz erişimi yazıyor; ADR-004, iş kuralları, middleware/policy ve testler ALFA erişimini kapatıyor. Karar sahibi yeni ADR ile değiştirmedikçe mevcut kural geçerlidir.
2. **Ticari ilişki/franchise dili:** Katılım/franchise, polymorphic agreement ilişki türü ve ofis yönetim modeli birbirinden ayrılmalıdır. Hangi relationship type'ın hangi hukuki/operasyonel anlama geldiği ürün/hukuk kararıdır.
3. **Sabit ücret ve işlem geliri:** Sabit ofis/danışman bedelinin dönemi, nihai müşteri hizmet bedeli ve transaction share ayrı politika/borç kalemleridir. Hangi olayın hangisini başlattığı finans kararlarıyla netleşmelidir.
4. **Mülk sahibi hizmet şartları:** ADR-056 kontrat, harici yetkilendirme ve taşınmaz numarasını Portföy/İlan ön şartı sayıyor; kayıt modelleri ve Listing guard'ı var, toplama/onay kullanıcı lifecycle'ı yok.
5. **Broker final approval:** Mevcut listing draft oluşumu broker onayı beklemez; listing publish ve transaction close motoru yok. Gelecekteki onay politikası ADR ve test olmadan varsayılmamalıdır.

## 5. Kod ve test envanterine dayalı kapsama özeti

| Alan | Kod durumu | Başlıca kanıt | Sınır |
|---|---|---|---|
| Brand/admin, role, permission, audit | Mevcut | Admin controllers, registry/actions, settings/user feature tests | Harici IAM yok |
| Office/broker/consultant lifecycle | Mevcut, tarihçeli | Office/Professional actions, lifecycle tests | Aday broker/consultant application domaini yok |
| Commercial policy/subscription | Mevcut | Agreement/plan/charge/entitlement/revenue policy actions ve governance testleri | Invoice/payment/distribution yok |
| Customer/DataPool/Request/Service | Mevcut | Operations routes, domain actions, PhaseTwo/Three feature tests | Public lead routing ve external contact integrations yok |
| Property/Portfolio/Listing draft | Kısmi fakat çalışan yazma akışı var | CreatePortfolio/CreateListing, `PortfolioListingFlowTest` | Marketplace publish/lead eşleştirme yok; contract/auth toplama UI'sı doğrulanmadı |
| Transaction | Bulunamadı | `app/Domains/Transaction` yalnız `.gitkeep`; route/model/migration/test bulunamadı | Tamamlanan satış/kiralama işlemi yok |
| Final Finance/RevenuePool | Bulunamadı | `app/Domains/Finance` yalnız `.gitkeep`; yalnız ticari accrual/policy var | Fatura, cari, tahsilat, earning, contribution/distribution yok |

## 6. Bir sonraki somut çalışma sırası

1. Ürün sahibi **ALFA Data Havuzu erişimini** mevcut ADR-004'teki kapalı davranış olarak mı tutuyor, yoksa yeni kural mı istiyor, kararını kayda geçir.
2. 04–06 kabul kapıları ve handoff'taki kurumsal patch tamamlanma/onay durumunu güncelle; mevcut handoff 03C.4 / Faz 4 giriş şartlarını referanslıyor. Route'ta Property/Portfolio/Listing kodu bulunması tek başına sonraki faz kabulü değildir.
3. Property/Portfolio/Listing/Marketplace için ayrı faz talimatı ve kabul matrisi oluştur; önce contract/authorization toplama lifecycle'ı, sonra draft/publish ve external marketplace sınırını tek kaynağa bağla.
4. Ardından Transaction domaini, sonrasında Finance/RevenuePool karar ve faz kapıları izlenmeli. Bu alanları tek patch'te kodlamayın.


# Panel, talep ve ofis tutarlılığı v1.0

Bu belge, 27 Ekim 2026 tarihli panel tutarlılığı düzeltmesinin bağlayıcı uygulama kuralıdır.

- Üyenin alım, kiralama ve devralma ihtiyacı tek bir `RequestFile` talep kaydı üretir. Kayıt, atama yapılana kadar merkezi marka havuzunda kalır ve `Atama bekliyor` olarak gösterilir.
- Atama, yeni bir dosya oluşturmaz. Aynı `RequestFile` kaydının `office_id` ve `consultant_id` ilişkilerini günceller; dosya numarası ve oluşturulma kaydı korunur.
- Marka yöneticisi tüm marka talep kayıtlarını görür. Broker ve danışman sorguları yalnız güncel aktif ofis üyeliği kapsamındaki ofis kayıtları ile aynı markanın atanmamış ortak talep havuzunu kullanır. Danışmanın kendisine atanmış kaydı da aktif üyelik kapsamındaki ofiste olmalıdır.
- Marka başvuru kararı, profesyonel aktivasyonu ve `OfficeMembership` farklı kaynaklardır. `ProfessionalApplication.status = ONBOARDING`, marka onayının tamamlandığını ve onboarding'in açık olduğunu gösterir; tek başına operasyon veya ofis erişimi vermez.
- Broker'ın `Benim Ofisim` alanı aktif broker `OfficeMembership` ilişkisinden doğar. Ayrı ticari ücret/komisyon kaydı, ofis operasyon erişiminin ön koşulu değildir.
- Broker franchise kuruluşu yalnız `Office.office_type = MAXIMUM` ile başlatılır. `ALFA` ofisi marka oluşturur ve broker erişimi açık marka atamasıyla doğar.
- Mülk sahibi/satıcı hizmet akışı ile alıcı/kiracı talep akışı ayrı kaynaklardır. Hizmet Dosyası ancak mevcut hizmet teklifi ve kabul kapılarından sonra açılır; atanmamış üye başvurusu sahte bir Hizmet Dosyasına dönüştürülmez.

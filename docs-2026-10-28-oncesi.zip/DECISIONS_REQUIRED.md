# Marka yaşam döngüsü — karar bekleyen konular

Bu kayıt, marka/ofis/broker ilk akışı uygulanırken kaynak belgelerde tanımlanmayan davranışları ayırır. Bu maddeler çözülene kadar yalnızca doğrudan bağlı aksiyonlar tamamlanmış kabul edilmez; bağımsız ve mevcut kuralları izleyen işler devam edebilir.

## DQ-001 — Kurumsal belge doğrulama

- **Etkilenen aksiyonlar:** Ofis belgelerini yükleme ve inceleme (I02), doğrulama sonrası aktivasyon (I04).
- **Mevcut davranış:** Ofis yasal unvan, şirket türü, vergi numarası, vergi dairesi, yetkili kişi ve adres alanlarını alıyor. Ofis detayındaki `Belgeler` sekmesi boş durum gösteriyor; belge modeli, yükleme rotası ve belge inceleme kaydı yok.
- **Karar gerekli:** Hangi belge türleri gereklidir? Bir belge için hangi durumlar ve hangi marka rolü kararı geçerlidir? Yenileme/değiştirme, saklama süresi ve erişim/indirme sınırları nelerdir? Resmî doğrulama entegrasyonu var mı, yoksa yetkili kişinin manuel inceleme kaydı yeterli mi?
- **Güvenli sınır:** Belge yükleme, doğrulandı durumu veya aktivasyon checklist'inde belge koşulu varmış gibi gösterilmemeli; hukuken doğrulandığı iddia edilmemeli.
- **Bağımsız devam edebilen işler:** Mevcut ofis alanları, broker atama, mevcut ticari plan/sözleşme taslağı, READY ve mevcut yaşam döngüsünün otomatik testleri.

## DQ-002 — Marka–ofis sözleşmesinde imza ve yürürlük kanıtı

- **Etkilenen aksiyonlar:** Sözleşme inceleme/imzaya gönderme/imza kaydı (T02–T05), sözleşmeye bağlı ofis aktivasyonu (I04).
- **Mevcut davranış:** Ofis oluşturulunca `CommercialAgreement` DRAFT kaydı ve şart snapshot'ı oluşturuluyor. Doğrudan ofis aktivasyonu bu kaydı ACTIVE yapıyor. Sözleşme metni/sürümü, taraf imza kanıtı veya imza entegrasyonu modeli görünmüyor.
- **Karar gerekli:** DRAFT/ACTIVE hangi ticari onayları ifade eder? ACTIVE olabilmesi için taraf imzaları şart mı? Kimler hangi taraf adına imza/kanıt kaydı girebilir? Yürürlük tarihi imzaya mı, marka onayına mı, yoksa açıkça belirlenen başka bir olaya mı bağlı? Metin değişikliğinde sürüm ve eski kanıt ilişkisi nasıl korunur?
- **Güvenli sınır:** Plan ve şart snapshot'ı kaydetmek imzalanmış hukuki sözleşme olarak sunulmamalı. Karar verilmeden imza kaydı veya imza onayı uydurulmamalı; mevcut ACTIVE semantiği ayrıca ürün sahibi tarafından gözden geçirilmelidir.
- **Bağımsız devam edebilen işler:** DRAFT ticari şart kaydı, broker ataması ve kurulum/erişim testleri; imzalı sözleşme kanıtına bağlı aktivasyon kararı hariç.

## DQ-003 — Broker franchise ilişkisinin kapsamı

- **Etkilenen aksiyonlar:** Kuruluş/ilişki türü seçimi (I01, T01) ve brokerın ticari sorumlulukları.
- **Mevcut davranış:** Ofis yönetim modeli ve ticari anlaşmadaki `relationship_type` ayrı alanlarda tutuluyor; formda franchise ve diğer ilişki seçenekleri sunuluyor.
- **Karar gerekli:** Franchise, ofisin yönetim modeli mi, brokerla hukuki/ticari ilişki türü mü, yoksa ikisi birden mi? Brokerın kendi adına oluşturduğu başvuru bu seçeneklerden hangisini varsayılan alır ve kim onaylar?
- **Güvenli sınır:** Mevcut seçim saklanabilir; yeni ücret, franchise yükümlülüğü veya otomatik ilişki kuralı eklenmemeli.
- **Bağımsız devam edebilen işler:** Mevcut alanları ve seçilen değeri görüntülemek, doğrulamak ve tarihçeli kaydetmek.

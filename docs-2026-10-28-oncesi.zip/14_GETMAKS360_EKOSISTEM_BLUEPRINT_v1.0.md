# Getmaks360 Ekosistem Blueprint v1.0

## 1. Amaç ve çerçeve

Getmaks360, tek bir kullanıcı ve tek bir platform altında çalışan, çok katmanlı bir gayrimenkul ekosistemidir.

Ana hedef:
- Her kullanıcı standart üye olarak başlar.
- Her profesyonel önce gayrimenkul danışmanıdır.
- Danışmanlar ofise bağlıdır.
- Ofisler marka altında operasyonel ve ticari birimlerdir.
- Brokerler ofisin yöneticisi ve yetkili temsilcisidir.
- Stratejik iş ortakları belirli işlem ve hizmet dosyalarına katkı sağlar.
- Marka yatırımcıları ofis/marka gelir görünümü görür.
- Nihai müşteri standart üye paneliyle başlar; işlem ve dosya akışına dahil olur.

Bu yapı, marka, ofis, danışman, ticari sözleşme ve operasyon katmanlarını tek bir ekosistem içinde birleştirir. Operasyonel sırayla bakıldığında mantık şudur:

- Standart üye → profesyonel statüsü → aktif ofis üyeliği → talep dosyası → hizmet dosyası → işlem dosyası → kapanış → gelir dağıtımı

## 2. Rol ve katman modeli

### 2.1 Standart üye (Member)
- Tüm kullanıcılar standart üye ile başlar.
- Profil, iletişim, iletişim tercihleri, kullanım izinleri ve temel müşteri profili vardır.
- Arama, favori, işlem takibi ve standart üye görünümünü kullanır.

### 2.2 Profesyonel / Gayrimenkul Danışmanı
- Her profesyonel önce gayrimenkul danışmanıdır.
- Ofis üyeliği zorunludur.
- Müşteri ve dosya akışını yönetir.
- Danışman paneline erişir.
- Kendi müşterileri, talep dosyaları, hizmet dosyaları ve işlemlerini yönetir.

### 2.3 Broker
- Ofis yöneticisi / yetkili temsilcisi.
- Danışmanları yönetir.
- Ofis performansını ve operasyonel akışı denetler.
- Yetkili olduğu ofis ve dosyalar üzerinde onay, atama ve yönlendirme yapar.
- Broker rolü, danışmanlık rolünden farklıdır; her ikisi aynı kullanıcıda birlikte bulunabilir ama ayrı yetki katmanlarıyla yönetilir.

### 2.4 Ofis
- Operasyonel ve ticari birimdir.
- Marka altında çalışır.
- Tek aktif brokerı vardır.
- Danışmanlar ofise bağlıdır.
- Ofis, operasyonel yetki ve görünüm alanıdır.

### 2.5 Brand / Marka
- Marka ana ekosistem kurucu ve bağlayıcı katmandır.
- Ofisler, brokerlar, danışmanlar ve politik yapıların bağlandığı ana organ durumundadır.
- Ticari sözleşmeler, marka politikaları ve merkezi doğrulama burada işler.

### 2.6 Stratejik İş Ortağı
- Belirli işlem ve dosya akışlarına katkı sağlar.
- Yalnızca dahil olduğu hedeflerde görünür.
- Ana operasyonu yönetmez; katkı ve görev katmanında çalışır.
- Kendi alanı haricinde işlemleri göremez.

### 2.7 Brand Investor
- Markaya veya ofise yatırım yapan taraf.
- Gelir, yatırım görünümü ve portföy/performans bilgilerini izler.
- Operasyonel iş akışına doğrudan müdahale etmez.

### 2.8 Brand Admin
- Marka düzeyinde sistem yönetimini yürütür.
- Ofis, broker, danışman, üyelik, politika ve ticari yapı üzerinde yönetici yetkisi vardır.
- Merkezi yetki ve izin gözetimini sağlar.

## 3. Temel iş kuralı

Sistem için en kritik karar şudur:
- Tek kullanıcı, çok katmanlı rollere sahiptir.
- Aynı kullanıcı aynı anda üye, profesyonel, broker, yatırımcı veya stratejik ortak olabilir.
- Ancak her katman ayrı izlenir ve ayrı yetkiyle çalışır.

Bu nedenle sistemin veri ve güvenlik modeli aşağıdaki gibi ayrıştırılmalıdır:
- User tablosu tek merkezli olmalıdır.
- Role ve ilişki tablosu ayrı olmalıdır.
- Scope ve permission ayrı olmalıdır.
- Gelir payı ayrı olmalıdır.

## 4. Core veri modeli

Temel entity listesi:
- User
- Member
- Brand
- Office
- OfficeMembership
- Professional
- WorkModel
- BrokerCommercialAuthority
- Customer
- RequestFile
- ServiceOffer
- ServiceFile
- Property
- Transaction
- StrategicPartnerAssignment
- RevenuePolicy
- ChargePolicy
- PlanEntitlement
- UsageEvent
- Invoice
- Payout
- AuditLog
- StatusHistory

İlişki zinciri:
- User → Member → Professional → OfficeMembership → Office
- User → Customer → RequestFile → ServiceOffer → ServiceFile → Transaction
- Professional → ServiceOffer → ServiceFile
- Office → BrokerCommercialAuthority → RevenuePolicy
- Transaction → RevenueShare → Brand / Office / Professional / Strategic Partner

Bu yapı, sistemin operasyonel ve finansal taraflarını birlikte taşıyacak şekilde kurulur.

## 5. İş akışı: başlatma → süreç → kapanış

### 5.1 Kayıt ve üyelik
- Kullanıcı kayıt olur.
- Standart üye hesabı açılır.
- Profil, iletişim ve temel tercih bilgileri kaydedilir.
- Üye aktif olur.

### 5.2 Profesyonel olma ve ofis bağlanma
- Kullanıcı profesyonel statüsü alır.
- Gayrimenkul danışmanı olur.
- Aktif ofise bağlanır.
- OfficeMembership kaydı açılır.
- Çalışma modeli atanır.
- Danışman panel yetkileri açılır.

### 5.3 Ofis kurulumu
- Marka altında ofis açılır.
- Ofis lifecycle akışı: DRAFT → SETUP → READY → ACTIVE
- Ofis için aktif broker atanır.
- Broker yetki kaydı oluşturulur.
- Ofis sahipliği ve operasyonel sınırı netleşir.

### 5.4 Talep dosyası
- Müşteri ihtiyacı kaydedilir.
- İhtiyaç türü, lokasyon, bütçe, zaman aralığı ve taraf bilgisi tutulur.
- Talep dosyası açılır.
- Talep dosyası müşteri tarafının başlangıç kaydı olur.

### 5.5 Hizmet dosyası
- Danışman talep dosyasını alır.
- Hizmet dosyası açılır.
- Müşteri tarafı, mülk sahibi tarafı ve yatırım tarafı ayrı yönetilir.
- Gerekli belgeler, yetkilendirmeler ve görevler tanımlanır.

### 5.6 İşlem dosyası
- Satış, kiralama, devir, yatırım veya ortaklık işlemlerinde işlem dosyası açılır.
- Teklif, gösterim, randevu, eşleşme ve masa üstü süreç buradan yönetilir.
- İşlem dosyası, talep ve hizmet dosyasına bağlanır.

### 5.7 Kapanış
- Sözleşme / karar / teslim / kapanış evresi tamamlanır.
- Fatura, hakediş, gelir paylaşımı ve payout süreci çalıştırılır.
- Audit ve status history kaydı tutulur.

### 5.8 Kritik akış kuralı
Bu sistemin ana akış kuralı şudur:
- Talep dosyası başlatır.
- Hizmet dosyası operasyonu yürütür.
- İşlem dosyası kapanışı taşır.

Bu üç katman ayrıdır:
- RequestFile: müşteri başlangıcı
- ServiceFile: operasyonel hizmet ve taraf yönetimi
- Transaction: işlem ve gelir kapanışı

## 6. Panel yapısı

### 6.1 Standart üye paneli
- Profil
- İş arama / ekleme / favori
- İşlem takibi
- Müşteri bakiyesi veya özel takip
- Bildirimler
- İletişim ve güvenlik

### 6.2 Danışman paneli
- Müşteriler
- Talep dosyaları
- Hizmet dosyaları
- Randevular
- Gösterimler
- Teklifler
- İşlem akışı
- Gelir ve hakediş görünümü
- Ofis içi yetkiler

### 6.3 Broker paneli
- Danışman yönetimi
- Ofis performansı
- Dosya takibi
- Onay ve yetki
- Gelir görünümü
- Ofis genel akışı

### 6.4 Ofis paneli
- Ofis genel görünüm
- Aktif broker
- Danışman listesi
- Tüm dosya ve işlem akışı
- Operasyonel performans
- Gelir ve iş hacmi

### 6.5 Stratejik ortak paneli
- Yalnızca dahil olduğu dosya ve işlem akışı
- Kendi katkı ve iş yükü görünümü
- Sadece izin verilen alanlara erişim
- Ana işlemin diğer taraflarını görmez

### 6.6 Marka yatırımcı paneli
- Yatırılan ofis / marka görünümü
- Gelir ve performans
- Yatırım takibi
- Odaklı iş ve satır bazlı görünüm

### 6.7 Marka admin paneli
- Tüm ofisler
- Tüm brokerlar
- Tüm danışmanlar
- Politik ve finans görünümü
- Audit ve denetim

## 7. Yetki ve erişim modeli

### 7.1 Rol bazlı yetki
- üye
- profesyonel
- broker
- ofis yöneticisi
- marka admin
- stratejik ortak
- yatırımcı

### 7.2 Scope bazlı yetki
- kendi müşteri dosyası
- kendi ofis dosyaları
- kendi markadaki ofisler
- ilgili işlem dosyaları
- ilgili stratejik ortak katkı alanı

### 7.3 Data bazlı yetki
- kendi dosyalarını görür
- kendi ofisinin verisini görür
- başkasının ofis verisine erişemez
- yalnızca izin verilen bilgileri görür

Kural:
- Kimin dokunabildiği net olmalı.
- Kimin görebildiği net olmalı.
- Kimin ücret/gelir bilgisine erişebildiği net olmalı.
- Kimin işlem dosyasına müdahil olabildiği net olmalı.

## 8. Finans modeli

### 8.1 Ana gelir kaynağı
- müşteriden alınan hizmet bedeli
- ek hizmetler
- ofis katkıları
- işlem bazlı komisyon

### 8.2 Pay dağıtım alanları
- marka
- ofis
- broker
- danışman
- stratejik ortak
- yatırımcı

### 8.3 Finans akışı
- Transaction
- RevenuePolicy
- ChargePolicy
- UsageEvent
- RevenueShare
- Invoice
- Payout

Kural:
- Fiyat sabit kod değil, politika tabanlı olmalıdır.
- Hakediş ile ödeme ayrıdır.
- Tahakkuk ile fatura ayrıdır.
- Her gelir payı işlem ve taraf ile ilişkilendirilmelidir.
- Gelir dağıtımı yalnız yetkili katmanlar tarafından görülür.

## 9. MVP öncelik sırası

### Aşama 1 — Kimlik ve temel üyelik
- kullanıcı kaydı
- login
- profil
- standart üye
- user/member ayrımı

### Aşama 2 — Profesyonel ve ofis bağlama
- professional model
- office model
- office-membership
- broker yetki
- work model

### Aşama 3 — Talep ve hizmet dosyası
- customer
- request file
- service file
- service offer
- lead / randevu / gösterim

### Aşama 4 — İşlem ve kapanış
- transaction
- teklif
- sözleşme
- kapanış
- süreç logları

### Aşama 5 — Finans ve gelir paylaşımı
- revenue policy
- payout
- commission
- invoice
- gelir dağıtımı

### Aşama 6 — Stratejik ortak ve yatırımcı paneli
- ilgili alanlara görünüm
- finans ve operasyon ayrımı
- yetki sınırı

### Aşama 7 — Test ve denetim
- yetki kontrolü
- geçiş kontrolü
- finans doğrulama
- audit
- performance

## 10. Başarı kriterleri

Bu ekosistem başarılı sayılabilmesi için aşağıdaki 8 şey aynı anda sağlanmalıdır:
- Her kullanıcı standart üye olarak başlar.
- Her profesyonel ofise bağlıdır.
- Her ofis tek aktif broker ile yönetilir.
- Her dosya talep / hizmet / işlem olarak ayrılmıştır.
- Her kullanıcı kendi panelinde sadece kendi yetki alanını görür.
- Kâr paylaşımı politika tabanlıdır.
- Stratejik ortak ve yatırımcı paneli, operasyonel veriyi değil ilgili alanlarını görür.
- Tüm süreçler audit ve status history ile izlenir.

## 11. Son tanım

Getmaks360, standart üyelerden başlayan, profesyonel gayrimenkul danışmanları üzerinden ofislere bağlanan, marka ve broker yönetimiyle süreci yöneten, talep dosyası ve hizmet dosyası ile operasyon geliştiren, işlem dosyası üzerinden kapanış yapan ve marka/ofis/danışman/stratejik ortak gelir paylaşımını politik tabanlı yöneten bir gayrimenkul ekosistemidir.

## 12. Uygulama notu

Bu belge, mevcut proje kararları, faz planı ve iş kurallarıyla tutarlı bir çözüm çerçevesi sunar. Tek başına canlı bir ekran veya migration değildir; ürün, veri modeli, roller, iş akışı ve finans katmanlarının birlikte çalıştırılabilecek planını tanımlar.

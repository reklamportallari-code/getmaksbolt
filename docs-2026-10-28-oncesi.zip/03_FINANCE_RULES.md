# Finans Kuralları

## Ticari politika ile finans kaydının sınırı

- `SubscriptionPlan` ticari ürün/kapsam tanımıdır.
- `ChargePolicy` sabit, kullanım, tek sefer veya işlem payı tahakkuk kuralıdır.
- `PlanEntitlement` boolean, kota veya sınırsız kullanım hakkıdır.
- `UsageEvent` ölçülen kullanımdır; `ChargeAccrual` yürürlükteki ücret kuralının snapshot'ıyla oluşan bekleyen tahakkuktur.
- Plan, ücret, hak ve tahakkuk kaydı final fatura, tahsilat veya gelir dağıtımı değildir.
- Ücretsiz/hediye/indirim/waiver/özel koşul ana fiyatı değiştirmez; standart koşul snapshot'ı saklanır.

## Üyelik gelirleri

- Ofis–broker franchise ilişkisi; beş yıllık sözleşmedeki franchise bedeli ile varsa aylık ve yıllık ek ödeme yükümlülüklerini Getmaks'a karşı taşır. Danışman için ticari plan ayrı kavramdır.
- Franchise bedeli, aylık ve yıllık ek ödeme koşulları sözleşme snapshot'ında tutulur; bu ekran ödeme veya tahsilat kaydı oluşturmaz.
- Plan, dönem, fiyat, vergi, kullanım hakkı, tahakkuk ve tahsilat durumu ayrı kayıtlardır; oran ve tutarlar kod içine gömülmez.
- Broker ana fiyatı değiştiremez; yalnız aktif yetki kaydının izin verdiği plan, indirim ve hak istisnalarını uygulayabilir.

## Nihai müşteri hizmet bedeli

Alıcı, satıcı, mülk sahibi veya kiracıdan doğan hizmet bedelinin faturasını **Getmaks nihai müşteriye** keser. Hizmet bedeli, politika ve işlem sonucundan hesaplanır; tahsilat faturadan ayrı izlenir. Bu akış Finans fazına aittir.

## Danışman hakedişi

```text
İşlem
→ ConsultantEarning
→ Danışman, Getmaks'a hakediş faturası keser
→ Getmaks ödeme yapar
```

Hakediş, ödeme değildir. Fatura kabulü ve ödeme ayrı yaşam döngüleridir. Geçmiş hakediş hesabı, sonraki politika veya çalışma modeli değişikliğinden etkilenmez.

## Marka, ofis ve havuz dağılımı

- `RevenuePolicy` marka, ofis, danışman ve varsa Kazanç Havuzu paylarını basis-point olarak, çalışma modeli ve yürürlük tarihleriyle saklar.
- Oranların toplamı 10.000 baz puandır. ALFA Kazanç Havuzu payı sıfırdır; MAXIMUM payı politika verisinden okunur.
- Faz 3 yalnız politika kaydını kurar; finansal hesaplama, katkı, dağıtım veya ödeme üretmez.
- Gelecekte gelir dağılımı işlem anındaki politika snapshot'ından hesaplanır.
- Ofis hakedişi ve danışman hakedişi ayrı kayıtlardır.
- Yuvarlama, vergi, iptal/iade ve düzeltme hareketleri izlenebilir hesap kayıtları üretir.

## Kazanç Havuzu

Yalnız MAXIMUM çalışma modelinde uygulanır:

`İşlem Geliri → PoolContribution → PoolPeriod → PoolDistribution → PoolEarning`

Katkı, dağıtım ve hakediş birbirinden ayrı olaylardır. Oranlar hard-code edilmez; yürürlük tarihli politika ile belirlenir. Bu finansal hareketler Faz 6 kapsamındadır.

## Muhasebe ilkeleri

- Para tutarları minor-unit integer ve ISO para birimiyle saklanır.
- Oranlar basis-point integer olarak saklanır.
- Finansal kayıtlar geriye dönük değiştirilmez; ters kayıt/düzeltme hareketi üretilir.
- Kullanım, tahsilat, dağıtım ve ödeme idempotent olmalıdır.
- Sağlayıcı cevabı olmadan başarılı ödeme veya fatura sonucu üretilmez.

## İşlem kaynaklı hak ediş ve panel görünümü (2026-10-25)

- Franchise bedeli ile aylık/yıllık ofis ek ödeme yükümlülükleri, işlem hizmet bedeli paylaşımının parçası değildir. Bunlar ofis–marka franchise sözleşmesinden doğan ayrı cari/fatura konularıdır.
- İşlem kaynaklı hak ediş, ancak kanıt koşulları tamamlanmış bir Satış, Kiralama veya Devir İşlem Dosyasında müşteriden doğan hizmet bedeli kesinleştiğinde; işlem, hizmet dosyası, ofis, taraflar ve o anda bağlanmış hizmet/paylaşım sözleşmesi sürümleri üzerinden oluşturulur.
- Her işlemde müşteriden doğan ana hizmet bedelinin pay sahipleri marka, broker/ofis ve danışmandır. Stratejik iş ortağı ana hizmet bedelinden varsayılan pay almaz. Beklenen hak, kesinleşmiş alacak, fatura, müşteri tahsilatı ve hak sahibine ödeme birbirinden ayrı durum ve kayıtlardır.
- MAXIMUM/ALFA ofis modellerinde işlem hizmet bedelinin paylaşım yüzdeleri, matrahı, uygunluğu ve ofisler arası paylaşımı marka tarafından yapılandırılır. Kod sabit oran, ücret veya otomatik formül içermez.
- Bir işlem birden fazla ofisi kapsıyorsa, her pay satırı kaynak işlem, ilgili ofis ve sözleşme kuralı ile ilişkilendirilir; taraflar başka ofisin kapsam dışı finans verisini göremez.
- Stratejik iş ortağı atanmışsa finans modeli açıkça seçilir: (a) müşteriden, ana işlem hizmet bedelinden ayrı peşin uzman hizmet bedeli tahsilatı veya (b) stratejik iş ortağının kendi işinden markaya komisyon. Her ikisi marka yapılandırması ve somut hizmet/görev kaydı olmadan oluşmaz. İşlem özeti; marka panelinde yetkili ağ görünümü, broker/ofis panelinde kendi ofis yükümlülükleri, danışman panelinde yalnız kendi hak edişi, stratejik ortak panelinde yalnız kendi görev ve seçilmiş mali modele ait kayıt olarak yansır. Nihai müşteri iç profesyonel paylaşım dağılımını görmez.
- İptal, itiraz, iade veya bedel düzeltmesi eski hak edişi silmez; ilişkilendirilmiş karşı/düzeltme kaydıyla izlenir. Aynı kapanış olayı ikinci hak ediş üretmez.